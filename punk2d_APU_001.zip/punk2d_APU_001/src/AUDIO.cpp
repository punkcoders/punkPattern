#include "AUDIO.h"

#include "ROOT_Heart.h"

unsigned int AUDIO::SAMPLE_RATE;

SDL_AudioSpec AUDIO::STREAM_SPEC;


bool AUDIO::Init()
{
    SAMPLE_RATE = 48000;

    // stream buffer

    SDL_memset(&STREAM_SPEC,0,sizeof(STREAM_SPEC));
    STREAM_SPEC.freq = SAMPLE_RATE;
    STREAM_SPEC.channels = 2;
    STREAM_SPEC.samples = ROOT_Heart::GetNumSamplesByBuffer();
    STREAM_SPEC.format = AUDIO_F32;
    STREAM_SPEC.callback = AUDIO::StreamRoutine;

    return !( SDL_OpenAudio(&STREAM_SPEC, NULL) < 0 );
}

void AUDIO::ShutDown()
{
    SDL_CloseAudio();
}

void AUDIO::StreamRoutine( void* userdata, Uint8* stream, int length )
{
    ROOT_Heart::AudioRoutine();

    float* left = ROOT_Heart::GetLeftBufferAddress();
    float* right = ROOT_Heart::GetRightBufferAddress();
    float* dest = (float*)stream;

    int numSamples = ROOT_Heart::GetNumSamplesByBuffer();

    for (int i=0; i<numSamples; i++)
    {
        *dest = left[i];
        dest++;
        *dest = right[i];
        dest++;
    }
}
