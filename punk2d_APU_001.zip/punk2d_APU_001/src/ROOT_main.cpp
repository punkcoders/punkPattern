#include <iostream>
using namespace std;
#include <string.h>
#include <stdio.h>

#include <winuser.h> // cannot find User32.lib
#include <GL/glew.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>

#include "ROOT_Heart.h"
#include "GL_Entry.h"
#include "AUDIO.h"

/*
SDL 2.0 IMPLEMENTATION OF THE PUNK PATTERN
you're free to implement in other environments like Qt
*/

bool FULLSCREEN = 0;

// routine vars
bool QUIT = false;
SDL_Event E;

// pixel table and render TEXTURE dimensions
int SW = ROOT_Heart::GetScreenWidth(), SH = ROOT_Heart::GetScreenHeight();
float STRETCH=1.5;

// VIDEO STRUCTS
SDL_Window* WINDOW = NULL; // create WINDOW
SDL_Renderer* RENDERER = NULL; // create RENDERER
SDL_Texture* TEXTURE = NULL; // create TEXTURE

// AUDIO
bool AUDIO_WORKS = false;

// FILE BUFFERS
char* FILE_NAME = ROOT_Heart::GetFileNameAddress();
char* FILE_BUFFER = ROOT_Heart::GetFileBufferAddress();

// LOAD FILE EVENT
void LoadFile( FILE* f )
{
    // open stream
    fseek (f, 0, SEEK_END);
    int sz = ftell(f);
    cout << "file size :" << sz << endl;
    // simulate fake download
    SDL_Delay(200);
    // read file
    fseek (f, 0, SEEK_SET);
    fread (FILE_BUFFER, sz, 1, f );
    fclose(f);
}

// KEYBOARD AND MOUSE

// converts sdl key codes to windows standard key codes:
// https://docs.microsoft.com/fr-fr/windows/desktop/inputdev/virtual-key-codes
int KeyCode( SDL_Keycode code )
{
    switch(code)
    {
    // numbers
    case SDLK_KP_0 :
        return 96; // ! careful, win can return 45 35 40 etc
    case SDLK_KP_1:
        return 97;
    case SDLK_KP_2:
        return 98;
    case SDLK_KP_3:
        return 99;
    case SDLK_KP_4:
        return 100;
    case SDLK_KP_5:
        return 101;
    case SDLK_KP_6:
        return 102;
    case SDLK_KP_7:
        return 103;
    case SDLK_KP_8:
        return 104;
    case SDLK_KP_9:
        return 105;
    // letters and numbers
    case SDLK_a:
        return 65;
    case SDLK_b:
        return 66;
    case SDLK_c:
        return 67;
    case SDLK_d:
        return 68;
    case SDLK_e:
        return 69;
    case SDLK_f:
        return 70;
    case SDLK_g:
        return 71;
    case SDLK_h:
        return 72;
    case SDLK_i:
        return 73;
    case SDLK_j:
        return 74;
    case SDLK_k:
        return 75;
    case SDLK_l:
        return 76;
    case SDLK_m:
        return 77;
    case SDLK_n:
        return 78;
    case SDLK_o:
        return 79;
    case SDLK_p:
        return 80;
    case SDLK_q:
        return 81;
    case SDLK_r:
        return 82;
    case SDLK_s:
        return 83;
    case SDLK_t:
        return 84;
    case SDLK_u:
        return 85;
    case SDLK_v:
        return 86;
    case SDLK_w:
        return 87;
    case SDLK_x:
        return 88;
    case SDLK_y:
        return 89;
    case SDLK_z:
        return 90;
    case SDLK_0:
        return 48;
    case SDLK_1:
        return 49;
    case SDLK_2:
        return 50;
    case SDLK_3:
        return 51;
    case SDLK_4:
        return 52;
    case SDLK_5:
        return 53;
    case SDLK_6:
        return 54;
    case SDLK_7:
        return 55;
    case SDLK_8:
        return 56;
    case SDLK_9:
        return 57;
    // arrows
    case SDLK_LEFT:
        return 37;
    case SDLK_UP:
        return 38;
    case SDLK_RIGHT:
        return 39;
    case SDLK_DOWN:
        return 40;
    // special keys
    case SDLK_LCTRL:
        return 17;
    case SDLK_RCTRL:
        return 17;
    case SDLK_LSHIFT:
        return 16;
    case SDLK_RSHIFT:
        return 16;
    case SDLK_LALT:
        return 18;
    case SDLK_RALT:
        return 18;
    case SDLK_SPACE:
        return 32;
    case SDLK_RETURN:
        return 13;
    case SDLK_ESCAPE:
        return 27;
    }
    return 0; // no keyCode found
}
//events
void KeyDown(int sdlKeycode)
{
    /*if ( sdlKeycode == SDLK_LSHIFT || sdlKeycode == SDLK_RSHIFT )
    {
        if ( ! FULLSCREEN )
        {
            SDL_SetWindowFullscreen(WINDOW, SDL_WINDOW_FULLSCREEN);
            FULLSCREEN = 1;
        }
        else
        {
            SDL_SetWindowFullscreen(WINDOW, 0);
            FULLSCREEN = 0;
        }
    }*/ // won't work correctly witout User32.lib
    *ROOT_Heart::GetLastKeyPressedAddress() = KeyCode(sdlKeycode);
    ROOT_Heart::OnKeyDown();
}
void KeyUp(int sdlKeycode)
{
    *ROOT_Heart::GetLastKeyPressedAddress() = KeyCode(sdlKeycode);
    ROOT_Heart::OnKeyUp();
}
void LeftMouseUp()
{
    ROOT_Heart::OnMouseUp();
}
void LeftMouseDown()
{
    ROOT_Heart::OnMouseDown();
}
void MouseMove(int x, int y)
{
    int w, h;
    SDL_GetWindowSize(WINDOW,&w,&h);
    *ROOT_Heart::GetMouseXAddress() = x / ( (double)w/(double)SW );
    *ROOT_Heart::GetMouseYAddress() = y / ( (double)h/(double)SH );
}

// Let's go
int main(int argc, char** argv)
{
    if ( SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO) < 0 )
    {
        return 1;
    }

    // audio
    AUDIO_WORKS = AUDIO::Init();
    if (!AUDIO_WORKS)
    {
        cout << "Error cannot open audio: " << SDL_GetError() << endl;
    }

    // video
    // SetProcessDPIAware(); // cannot install User32.lib
    WINDOW = SDL_CreateWindow("punk window",128,128,SW*STRETCH,SH*STRETCH, SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_SHOWN );
    //WINDOW = SDL_CreateWindow("punk window",0,0,SW,SH, SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN | SDL_WINDOW_FULLSCREEN );
    if( WINDOW )
    {
        SDL_GLContext GLctx = SDL_GL_CreateContext( WINDOW );
        if (GLctx)
        {
            // INIT MODULE
            ROOT_Heart::Init();
            cout << "HEART HAS BEEN INIT------------------------" << endl;

            bool GL_Entry_Init = GL_Entry::Init();
            if ( GL_Entry_Init )
            {
                // INIT VIDEO
                SDL_GL_SetSwapInterval(1);
                glViewport(0,0,SW*STRETCH,SH*STRETCH);

                if ( AUDIO_WORKS )
                {
                    SDL_PauseAudio(0);
                }

                cout << "LOOP START ----------------------------------------" << endl;

                // main loop
                while(!QUIT)
                {
                    // check controls
                    while( SDL_PollEvent( &E ) != 0 ) //Handle events on queue
                    {
                        switch (E.type)
                        {
                        case SDL_QUIT:
                            QUIT=true;
                            break;
                        case SDL_KEYDOWN:
                            KeyDown(E.key.keysym.sym);
                            break;
                        case SDL_KEYUP:
                            KeyUp(E.key.keysym.sym);
                            break;

                        case SDL_MOUSEBUTTONDOWN:
                            if(E.button.button == SDL_BUTTON_LEFT)
                            {
                                LeftMouseDown();
                            } ;
                            break;
                        case SDL_MOUSEBUTTONUP:
                            if(E.button.button == SDL_BUTTON_LEFT)
                            {
                                LeftMouseUp();
                            };
                            break;
                        case SDL_MOUSEMOTION:
                            MouseMove(E.motion.x, E.motion.y);
                            break;

                        case SDL_WINDOWEVENT:
                            if(E.window.event == SDL_WINDOWEVENT_SIZE_CHANGED)
                            {
                                glViewport(0,0,(GLsizei)E.window.data1,E.window.data2);
                            }
                            break;
                        }
                    }

                    // video routine

                    ROOT_Heart::VideoRoutine(); // logic routine
                    GL_Entry::VideoRoutine(); // graphic routine
                    SDL_GL_SwapWindow(WINDOW); // gl refresh

                    // check for file load
                    if (FILE_NAME[0])
                    {
                        cout << "LOADING FILE: " << FILE_NAME << endl;
                        // load file
                        FILE* f = fopen(FILE_NAME,"r");
                        FILE_NAME[0] = 0; // discard name first byte
                        if (f)
                        {
                            LoadFile(f);
                            ROOT_Heart::OnLoaded(); // loaded event
                        }
                        else
                        {
                            cout << "CANNOT LOAD FILE" << endl;
                            ROOT_Heart::OnLoadError();
                        }
                    }

                    // check program end
                    if (ROOT_Heart::Exit())
                    {
                        cout << "ROOT_Heart::Exit()" << endl;
                        QUIT = true;
                    }
                }

                GL_Entry::ShutDown();
            }
            else
            {
                cout << "cannot init openGL components" << endl;;
            }
            SDL_GL_DeleteContext(GLctx);
            // shutDown module
            ROOT_Heart::ShutDown();
        }
        else
        {
            cout << "cannot create GL context";
        }

        if ( AUDIO_WORKS )
        {
            cout << "Close Audio" << endl;
            AUDIO::ShutDown();
        }

        SDL_DestroyWindow(WINDOW);
    }
    else
    {
        cout << "Error creating WINDOW: " << SDL_GetError() << endl;
    }
    SDL_Quit();
    cout << "END PROGRAM" << endl;

    return 0;
}
