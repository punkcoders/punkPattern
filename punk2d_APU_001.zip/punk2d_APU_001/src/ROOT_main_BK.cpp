#include <iostream>
using namespace std;
#include <string.h>
#include <SDL2/SDL.h>
#include <stdio.h>

/*
SDL 2.0 IMPLEMENTATION OF THE PUNK PATTERN
you're free to implement in other environments like Qt
*/

#include "ROOT_Heart.h"

bool FULLSCREEN = 0;
bool DEBUG = 1;

// routine vars
bool QUIT = false;
SDL_Event E;

// pixel table and render TEXTURE dimensions
int SW = ROOT_Heart::GetScreenWidth(), SH = ROOT_Heart::GetScreenHeight(), TW = ROOT_Heart::GetTextureWidth(), TH = ROOT_Heart::GetTextureHeight();
unsigned long * SCREEN = ROOT_Heart::GetScreenAddress();
int STRETCH=3;

// VIDEO STRUCTS
SDL_Window* WINDOW = NULL; // create WINDOW
SDL_Renderer* RENDERER = NULL; // create RENDERER
SDL_Texture* TEXTURE = NULL; // create TEXTURE

// VIDEO ROUTINE FUNCTION
int VideoRoutine(SDL_Renderer* RENDERER, SDL_Texture* TEXTURE)
{
    ROOT_Heart::VideoRoutine();

    char* scr = (char*)SCREEN,* Vscr; // RAM & VRAM pixels address
    int pitch = SW*4, Vpitch = 0; // RAM & VRAM pixels pitch

    SDL_Rect pixelRect; // screen rectangle
    pixelRect.x = pixelRect.y = 0;
    pixelRect.w = SW;
    pixelRect.h = SH;

    SDL_Rect renderRect; // stretching rectangle
    renderRect.x = renderRect.y = 0;

    int w, h;
    SDL_GetWindowSize(WINDOW,&w,&h);
    // cout << w << "x" << h << endl;
    renderRect.w = w;
    renderRect.h = h;

    SDL_LockTexture(TEXTURE,&pixelRect,(void**)&Vscr,&Vpitch); // streaming TEXTURE ram->vram
    for(int j=0; j<SH; j++) // copy each scanline of the 320*240 pixel table in 512*256 pixel table
    {
        memcpy(Vscr+Vpitch*j,scr+pitch*j,pitch); // memcpy automatically converts char* to void*
    }
    SDL_UnlockTexture(TEXTURE);

    SDL_RenderCopy(RENDERER,TEXTURE,&pixelRect,&renderRect); // render TEXTURE

    return 0;
}

// AUDIO STRUCTS
int SAMPLE_RATE = 48000, CUR_SAMPLE = 0;
SDL_AudioSpec AUDIO_SPEC; // the specs of sound
bool AUDIO_WORKS = false;

// AUDIO ROUTINE FUNCTION
void AudioRoutine(void* userdata, Uint8* stream, int length)
{
    ROOT_Heart::AudioRoutine();

    float* left = ROOT_Heart::GetLeftBufferAddress();
    float* right = ROOT_Heart::GetRightBufferAddress();
    float* dest = (float*)stream;

    int numSamples = ROOT_Heart::GetNumSamplesByBuffer();

    for (int i=0; i<numSamples; i++)
    {
        *dest = left[i];
        dest++;
        *dest = right[i];
        dest++;
    }
}

// FILE BUFFERS
char* FILE_NAME = ROOT_Heart::GetFileNameAddress();
char* FILE_BUFFER = ROOT_Heart::GetFileBufferAddress();

// LOAD FILE EVENT
void LoadFile( FILE* f )
{
    // open stream
    fseek (f, 0, SEEK_END);
    int sz = ftell(f);
    if(DEBUG) cout << "file size :" << sz << endl;
    // simulate fake download
    SDL_Delay(200);
    // read file
    fseek (f, 0, SEEK_SET);
    fread (FILE_BUFFER, sz, 1, f );
    fclose(f);
}

// KEYBOARD AND MOUSE

// converts sdl key codes to windows standard key codes:
// https://docs.microsoft.com/fr-fr/windows/desktop/inputdev/virtual-key-codes
int KeyCode( SDL_Keycode code )
{
    switch(code)
    {
        // numbers
        case SDLK_KP_0 : return 96; // ! careful, win can return 45 35 40 etc
        case SDLK_KP_1: return 97;
        case SDLK_KP_2: return 98;
        case SDLK_KP_3: return 99;
        case SDLK_KP_4: return 100;
        case SDLK_KP_5: return 101;
        case SDLK_KP_6: return 102;
        case SDLK_KP_7: return 103;
        case SDLK_KP_8: return 104;
        case SDLK_KP_9: return 105;
        // letters and numbers
        case SDLK_a: return 65;
        case SDLK_b: return 66;
        case SDLK_c: return 67;
        case SDLK_d: return 68;
        case SDLK_e: return 69;
        case SDLK_f: return 70;
        case SDLK_g: return 71;
        case SDLK_h: return 72;
        case SDLK_i: return 73;
        case SDLK_j: return 74;
        case SDLK_k: return 75;
        case SDLK_l: return 76;
        case SDLK_m: return 77;
        case SDLK_n: return 78;
        case SDLK_o: return 79;
        case SDLK_p: return 80;
        case SDLK_q: return 81;
        case SDLK_r: return 82;
        case SDLK_s: return 83;
        case SDLK_t: return 84;
        case SDLK_u: return 85;
        case SDLK_v: return 86;
        case SDLK_w: return 87;
        case SDLK_x: return 88;
        case SDLK_y: return 89;
        case SDLK_z: return 90;
        case SDLK_0: return 48;
        case SDLK_1: return 49;
        case SDLK_2: return 50;
        case SDLK_3: return 51;
        case SDLK_4: return 52;
        case SDLK_5: return 53;
        case SDLK_6: return 54;
        case SDLK_7: return 55;
        case SDLK_8: return 56;
        case SDLK_9: return 57;
        // arrows
        case SDLK_LEFT: return 37;
        case SDLK_UP: return 38;
        case SDLK_RIGHT: return 39;
        case SDLK_DOWN: return 40;
        // special keys
        case SDLK_LCTRL: return 17;
        case SDLK_RCTRL: return 17;
        case SDLK_LALT: return 18;
        case SDLK_RALT: return 18;
        case SDLK_SPACE: return 32;
        case SDLK_RETURN: return 13;
        case SDLK_ESCAPE: return 27;
    }
    return 0; // no keyCode found
}
//events
void KeyDown(int sdlKeycode) {
    if ( sdlKeycode == SDLK_ESCAPE )
    {
        QUIT = 1;
    }
    if ( sdlKeycode == SDLK_RETURN )
    {
        if ( ! FULLSCREEN )
        {
            SDL_SetWindowFullscreen(WINDOW, SDL_WINDOW_FULLSCREEN);
            FULLSCREEN = 1;
        }
        else
        {
            SDL_SetWindowFullscreen(WINDOW, 0);
            FULLSCREEN = 0;
        }
    }
    *ROOT_Heart::GetLastKeyPressedAddress() = KeyCode(sdlKeycode);
    ROOT_Heart::OnKeyDown();
}
void KeyUp(int sdlKeycode) {
    *ROOT_Heart::GetLastKeyPressedAddress() = KeyCode(sdlKeycode);
    ROOT_Heart::OnKeyUp();
}
void LeftMouseUp(){
    ROOT_Heart::OnMouseUp();
}
void LeftMouseDown(){
    ROOT_Heart::OnMouseDown();
}
void MouseMove(int x, int y){
    int w, h;
    SDL_GetWindowSize(WINDOW,&w,&h);
    *ROOT_Heart::GetMouseXAddress() = x / ( (double)w/(double)SW );
    *ROOT_Heart::GetMouseYAddress() = y / ( (double)h/(double)SH );
}

// Let's go
int main(int argc, char** argv)
{
    if ( SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO) < 0 )
    {
        return 1;
    }
    // audio
    SDL_memset(&AUDIO_SPEC,0,sizeof(AUDIO_SPEC));
    AUDIO_SPEC.freq = SAMPLE_RATE;
    AUDIO_SPEC.channels = 2;
    AUDIO_SPEC.samples = ROOT_Heart::GetNumSamplesByBuffer();
    AUDIO_SPEC.format = AUDIO_F32;
    AUDIO_SPEC.callback = AudioRoutine;
    AUDIO_WORKS = !( SDL_OpenAudio(&AUDIO_SPEC, NULL) < 0 );
    if (!AUDIO_WORKS)
    {
        if(DEBUG) cout << "Error cannot open audio: " << SDL_GetError() << endl;
    }
    // video
    WINDOW = SDL_CreateWindow("press ENTER for fullscreen",SDL_WINDOWPOS_UNDEFINED,SDL_WINDOWPOS_UNDEFINED,SW*STRETCH,SH*STRETCH,SDL_WINDOW_RESIZABLE | SDL_WINDOW_SHOWN );
    if( WINDOW )
    {

        RENDERER = SDL_CreateRenderer(WINDOW,1,SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);
        SDL_SetRenderDrawColor(RENDERER, 0, 0, 255, 255);
        SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1");
        if (RENDERER)
        {

            TEXTURE = SDL_CreateTexture(RENDERER,SDL_PIXELFORMAT_ABGR8888,SDL_TEXTUREACCESS_STREAMING,TW,TH);

            if (TEXTURE)
            {
                if ( AUDIO_WORKS )
                {
                    SDL_PauseAudio(0);
                }
                //INIT ROOT_Heart
                ROOT_Heart::Init();
                // main loop
                while(!QUIT)
                {
                    // check controls
                    while( SDL_PollEvent( &E ) != 0 ) //Handle events on queue
                    {
                        switch (E.type)
                        {
                            case SDL_QUIT: QUIT=true; break;
                            case SDL_KEYDOWN: KeyDown(E.key.keysym.sym); break;
                            case SDL_KEYUP: KeyUp(E.key.keysym.sym); break;

                            case SDL_MOUSEBUTTONDOWN:
                                if(E.button.button == SDL_BUTTON_LEFT){ LeftMouseDown();} ; break;
                            case SDL_MOUSEBUTTONUP:
                                if(E.button.button == SDL_BUTTON_LEFT){ LeftMouseUp(); }; break;
                            case SDL_MOUSEMOTION: MouseMove(E.motion.x, E.motion.y); break;
                        }
                    }
                    // video routine
                    VideoRoutine(RENDERER,TEXTURE); //Compute + Rendering here
                    SDL_RenderPresent(RENDERER); // swap buffers and wait vsync
                    // check for file load
                    if (FILE_NAME[0])
                    {
                        if(DEBUG) cout << "LOADING FILE: " << FILE_NAME << endl;
                        // load file
                        FILE* f = fopen(FILE_NAME,"r");
                        FILE_NAME[0] = 0; // discard name first byte
                        if (f)
                        {
                            LoadFile(f);
                            ROOT_Heart::OnLoaded(); // loaded event
                        }
                        else
                        {
                            if(DEBUG) cout << "CANNOT LOAD FILE" << endl;
                            ROOT_Heart::OnLoadError();
                        }
                    }

                    // check program end
                    if (ROOT_Heart::Exit())
                    {
                        QUIT = true;
                    }
                }

                // close ROOT_Heart
                ROOT_Heart::ShutDown();

                SDL_DestroyTexture(TEXTURE);
                if ( AUDIO_WORKS )
                {
                    SDL_CloseAudio();
                }
            }
            else
            {
                if(DEBUG) cout << "Error creating TEXTURE: " << SDL_GetError() << endl;
            }
            SDL_DestroyRenderer(RENDERER);
        }
        else
        {
            if(DEBUG) cout << "Error creating RENDERER: " << SDL_GetError() << endl;
        }
        SDL_DestroyWindow(WINDOW);
    }
    else
    {
        if(DEBUG) cout << "Error creating WINDOW: " << SDL_GetError() << endl;
    }
    SDL_Quit();

    return 0;
}
