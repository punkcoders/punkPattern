/*
ENTRY POINT FOR ALL OPENGL OBJECTS
MUST BY PORTED MANUALLY TO ES & WEBGL
http://punkcoders.free.fr
pukcoders@gmail.com
Code under P.U.N.K. license: Poor Useless Newbie Kidcoding
*/

#include "GL_Entry.h"
#include "GAME_DATA_Sheets.h"
#include "PPU.h" // for tests only
#include "RGB.h"

#include <cmath>
#include <iostream>
using namespace std;

/*
    Cette classe est le plus long travail du projet.

    Elle sert pr�lablement de test aux objets graphiques,
    Ensuite elle servira � lire le buffer "ppu" pour l'afficher.

    Merci emscripten, la bonne �cole pour apprendre une s�paration parfaite CPU-GPU,
    Ca servira si Dieu me pr�te vie et force jusqu'au moteur 3d,
    Qui en th�orie devrait �tre plus facile � r�aliser
    car les GPU ne sont pas faits pour la 2d
*/

// -----------------------------------------------------------------------------
// MAIN STATIC PROPS -----------------------------------------------------------
// -----------------------------------------------------------------------------

// failed ( not sure it's still useful )

bool GL_Entry::CRASHED = false;

// dimensions

unsigned int GL_Entry::MAIN_TARGET_WIDTH = 1, GL_Entry::MAIN_TARGET_HEIGHT = 1, GL_Entry::TILESHEET_SIZE = 1;

// main target render frame buffer

GLuint GL_Entry::MAIN_TARGET_BUFFER_ID;

// vertices

float GL_Entry::MAIN_TARGET_XY[] = {  -1.0, -1.0, 1.0, -1.0,  1.0, 1.0,  -1.0, 1.0 };
GLuint GL_Entry::MAIN_TARGET_XY_BUFFER_ID;

float GL_Entry::MAIN_TARGET_UV[] = { 0, 0,  1, 0,  1, 1,  0, 1 };
GLuint GL_Entry::MAIN_TARGET_UV_BUFFER_ID;

unsigned short GL_Entry::MAIN_TARGET_IDS[] = {0,1,2,2,3,0};
GLuint GL_Entry::MAIN_TARGET_IDS_BUFFER_ID;

// textures

GLuint GL_Entry::MAIN_TARGET_TEXTURE_ID;

GLuint GL_Entry::PALETTE_TEXTURE_ID;

// shaders and locations

const char * GL_Entry::VERTEX_SHADER[] =
{
    "attribute highp vec4 aVertexXY;                                \n"
    "attribute highp vec2 aVertexUV;                                \n"
    "                                                               \n"
    "varying highp vec2 UV;                                         \n"
    "                                                               \n"
    "void main()                                                    \n"
    "{                                                              \n"
    "   UV = aVertexUV;                                             \n"
    "   gl_Position =  aVertexXY;                                   \n"
    "}                                                              \n"
};

const char * GL_Entry::FRAGMENT_SHADER[] =
{
    "varying highp vec2 UV;                                         \n"
    "                                                               \n"
    "uniform sampler2D uScreenTexture;                              \n"
    "                                                               \n"
    "void main()                                                    \n"
    "{                                                              \n"
    "    gl_FragColor = texture2D( uScreenTexture, UV ).rgba;       \n"
    "}                                                              \n"
};

GLuint GL_Entry::VERTEX_SHADER_ID, GL_Entry::FRAGMENT_SHADER_ID, GL_Entry::SHADER_PROGRAM_ID;

GLuint GL_Entry::XY_ATTRIB_LOCATION, GL_Entry::UV_ATTRIB_LOCATION;
GLuint GL_Entry::TEXTURE_UNIFORM_LOCATION;


// -----------------------------------------------------------------------------
// MAIN STATIC METHODS ---------------------------------------------------------
// -----------------------------------------------------------------------------

// getters

unsigned short GL_Entry::GetMainTargetWidth()
{
    return MAIN_TARGET_WIDTH;
}
unsigned short GL_Entry::GetMainTargetHeight()
{
    return MAIN_TARGET_HEIGHT;
}

double GL_Entry::GetScaleWidth()
{
    return 2.0 / (double)MAIN_TARGET_WIDTH;
}
double GL_Entry::GetScaleHeight()
{
    return 2.0 / (double)MAIN_TARGET_HEIGHT;
}

unsigned short GL_Entry::GetTileSheetSize()
{
    return TILESHEET_SIZE;
}

GLuint GL_Entry::GetMainTargetBuffer()
{
    return MAIN_TARGET_BUFFER_ID;
}

GLuint GL_Entry::GetPaletteTexture()
{
    return PALETTE_TEXTURE_ID;
}

// setters

void GL_Entry::UpdatePalette( unsigned char * data )
{
    glBindTexture(GL_TEXTURE_2D, PALETTE_TEXTURE_ID );
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 16, 16, 0, GL_RGBA, GL_UNSIGNED_BYTE, data );
}

// THE SHADER HELPER

bool GL_Entry::MakeShader( GLuint * vertShaderId, GLuint * fragShaderId, GLuint * shaderProgId, const char * const* vertShader, const char * const* fragShader, const char * shaderName )
{
    // store ids in locals first

    GLuint vSid, fSid, sPid;

    // create the vertex shader

    vSid = glCreateShader( GL_VERTEX_SHADER );
    glShaderSource( vSid, 1, vertShader, nullptr );
    glCompileShader( vSid );
    GLint result;
    glGetShaderiv( vSid, GL_COMPILE_STATUS, &result );
    if ( result )
    {
        cout << shaderName << " vertex shader compiled" << endl;
    }
    else
    {
        cout << shaderName << " cannot compile vertex shader" << endl;
        glDeleteShader(vSid);
        return false;
    }

    // create the fragment shader

    fSid = glCreateShader( GL_FRAGMENT_SHADER );
    glShaderSource( fSid, 1, fragShader, nullptr);
    glCompileShader( fSid );
    glGetShaderiv( fSid, GL_COMPILE_STATUS, &result );
    if ( result )
    {
        cout << shaderName << " fragment shader compiled" << endl;
    }
    else
    {
        cout << shaderName << " cannot compile fragment shader" << endl;
        glDeleteShader(fSid);
        return false;
    }

    // link the program shader

    sPid = glCreateProgram();
    glAttachShader( sPid, vSid );
    glAttachShader( sPid, fSid );
    glLinkProgram( sPid );
    glGetProgramiv( sPid, GL_LINK_STATUS, &result );
    if ( result )
    {
        cout << shaderName << " shaders program linked" << endl;
    }
    else
    {
        glDetachShader(sPid,vSid);
        glDetachShader(sPid,fSid);
        cout << shaderName << " cannot link shaders program" << endl;
        return false;
    }

    // if ok, store locals in pointers
    *vertShaderId = vSid;
    *fragShaderId = fSid;
    *shaderProgId = sPid;

    return true;
}


// INIT / SHUTDOWN / VIDEO ROUTINE

bool GL_Entry::Init()
{
    cout << "init GLEW" << endl;

    // init glew

    GLenum err = glewInit();


    if (GLEW_OK != err)
    {
        cout << "unable to init glew" << endl;
        return 0;
    }
    cout << "OpenGL Version: " << glGetString(GL_VERSION) << endl;


    // CREATE SHADER ---------------------------------------------------------

    bool result = MakeShader(&VERTEX_SHADER_ID,&FRAGMENT_SHADER_ID,&SHADER_PROGRAM_ID,VERTEX_SHADER,FRAGMENT_SHADER,"Main RenderTarget");
    if ( ! result )
    {
        CRASHED = true;
        return false;
    }

    // get locations

    TEXTURE_UNIFORM_LOCATION = glGetUniformLocation( SHADER_PROGRAM_ID, "uScreenTexture" );
    XY_ATTRIB_LOCATION = glGetAttribLocation( SHADER_PROGRAM_ID, "aVertexXY" );
    UV_ATTRIB_LOCATION = glGetAttribLocation( SHADER_PROGRAM_ID, "aVertexUV" );

    cout << "main target Tex unif loc: " << TEXTURE_UNIFORM_LOCATION << endl;
    cout << "main target XY attr loc: " << XY_ATTRIB_LOCATION << endl;
    cout << "main target UV attr loc: " << UV_ATTRIB_LOCATION << endl;


    // CREATE DATA -------------------------------------------------------------

    // dimensions

    cout << "MAIN BUFFER RESOLUTION: " << RGB::GetScreenWidth() << " x " << RGB::GetScreenHeight() << endl;
    cout << "TILESHEET RESOLUTION: " << RGB::GetSheetResolution() << " x " << RGB::GetSheetResolution() << endl;

    MAIN_TARGET_WIDTH = RGB::GetScreenWidth();
    MAIN_TARGET_HEIGHT = RGB::GetScreenHeight();
    TILESHEET_SIZE = RGB::GetSheetResolution();


    // CREATE OPENGL OBJECTS ---------------------------------------------------

    // create the renderTarget framebuffer and its texture

    glGenFramebuffers( 1, &MAIN_TARGET_BUFFER_ID );

    glGenTextures( 1, &MAIN_TARGET_TEXTURE_ID );
    glBindTexture( GL_TEXTURE_2D, MAIN_TARGET_TEXTURE_ID );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, MAIN_TARGET_WIDTH, MAIN_TARGET_HEIGHT, 0, GL_RGBA, GL_UNSIGNED_BYTE, 0 );

    glBindFramebuffer( GL_FRAMEBUFFER, MAIN_TARGET_BUFFER_ID );
    glFramebufferTexture( GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, MAIN_TARGET_TEXTURE_ID, 0 );

    //unused for the moment
    //GLenum DrawBuffers[1] = {GL_COLOR_ATTACHMENT0};
    //glDrawBuffers(1, DrawBuffers);

    if( glCheckFramebufferStatus( GL_FRAMEBUFFER ) != GL_FRAMEBUFFER_COMPLETE )
    {
        cout << "main target RENDERTARGET FRAMEBUFFER CONFIGURATION ERROR" << endl;
        CRASHED = true;
        return false;
    }

    // back to main buffer
    glBindFramebuffer( GL_FRAMEBUFFER, 0 );

    // create the vertices

    glGenBuffers( 1, &MAIN_TARGET_XY_BUFFER_ID );
    glBindBuffer( GL_ARRAY_BUFFER, MAIN_TARGET_XY_BUFFER_ID );
    glBufferData( GL_ARRAY_BUFFER, sizeof(MAIN_TARGET_XY), MAIN_TARGET_XY, GL_STATIC_DRAW );

    glGenBuffers( 1, &MAIN_TARGET_UV_BUFFER_ID );
    glBindBuffer( GL_ARRAY_BUFFER, MAIN_TARGET_UV_BUFFER_ID );
    glBufferData( GL_ARRAY_BUFFER, sizeof(MAIN_TARGET_UV), MAIN_TARGET_UV, GL_STATIC_DRAW );

    glGenBuffers( 1, &MAIN_TARGET_IDS_BUFFER_ID );
    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, MAIN_TARGET_IDS_BUFFER_ID );
    glBufferData( GL_ELEMENT_ARRAY_BUFFER, sizeof(MAIN_TARGET_IDS), MAIN_TARGET_IDS, GL_STATIC_DRAW );


    // create the palette texture

    glGenTextures(1,&PALETTE_TEXTURE_ID);
    glBindTexture(GL_TEXTURE_2D,PALETTE_TEXTURE_ID);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

    cout << "PALETTE TEXTURE ID: " << PALETTE_TEXTURE_ID << endl;


    // CREATE GRAPHIC OBJECTS ------------------------------------------------

    bool ok = CreateObjects();
    if (!ok )
    {
        CRASHED = true;
        return false;
    }

    return true;
}

void GL_Entry::ShutDown()
{
    if ( CRASHED )
    {
        return;
    }

    // delete graphics objects

    DeleteObjects();

    // delete palette

    glDeleteTextures( 1, &PALETTE_TEXTURE_ID );
    cout << "palette texture deleted" << endl;

    // delete the vertices buffers

    glDeleteBuffers( 1, &MAIN_TARGET_IDS_BUFFER_ID );
    glDeleteBuffers( 1, &MAIN_TARGET_UV_BUFFER_ID );
    glDeleteBuffers( 1, &MAIN_TARGET_XY_BUFFER_ID );
    cout << "main target vertices deleted" << endl;

    // delete the texture

    glDeleteTextures( 1, &MAIN_TARGET_TEXTURE_ID );
    cout << "main target texture deleted" << endl;

    // delete rendertarget buffer

    glDeleteFramebuffers( 1, &MAIN_TARGET_BUFFER_ID );
    cout << "main target renderTarget frame buffer deleted" << endl;

    // delete the shader

    glDetachShader( SHADER_PROGRAM_ID, VERTEX_SHADER_ID );
    glDetachShader( SHADER_PROGRAM_ID, FRAGMENT_SHADER_ID );
    glDeleteShader( VERTEX_SHADER_ID );
    glDeleteShader( FRAGMENT_SHADER_ID );
    cout << "main target shaders deleted" << endl;

}

void GL_Entry::VideoRoutine()
{
    if ( CRASHED )
    {
        return;
    }

    // SAVE VIEWPORT BEFORE ALL RENDERTARGET OPERATIONS ----------------------------------------------

    GLint aiViewport[4];
    glGetIntegerv(GL_VIEWPORT, aiViewport);

    //glRenderMode(GL_1PASS_EXT); // i don't know if this is useful

    // black clear window buffer

    glClearColor(0,0,0,1);
    glClear( GL_COLOR_BUFFER_BIT );

    // STEP ONE: RENDER OBJECTS IN RENDERTARGET BUFFER -----------------------------------------------

    ObjectsRoutine();

    // STEP TWO: RENDER IN MAIN BUFFER -------------------------------------------------------------------

    // back to main buffer

    glBindFramebuffer( GL_FRAMEBUFFER, 0 );
    glViewport( aiViewport[0], aiViewport[1], (GLsizei)aiViewport[2], (GLsizei)aiViewport[3] );

    glDisable( GL_BLEND );

    // select shader program

    glUseProgram( SHADER_PROGRAM_ID );

    // select texture

    glActiveTexture( GL_TEXTURE0 );
    glUniform1i( TEXTURE_UNIFORM_LOCATION, 0 );
    glBindTexture( GL_TEXTURE_2D, MAIN_TARGET_TEXTURE_ID );

    // select vertbuffers

    glBindBuffer( GL_ARRAY_BUFFER, MAIN_TARGET_XY_BUFFER_ID );
    glVertexAttribPointer( XY_ATTRIB_LOCATION, 2, GL_FLOAT, GL_FALSE, 0, (void*)0 );
    glEnableVertexAttribArray( XY_ATTRIB_LOCATION );

    glBindBuffer( GL_ARRAY_BUFFER, MAIN_TARGET_UV_BUFFER_ID );
    glVertexAttribPointer( UV_ATTRIB_LOCATION, 2, GL_FLOAT, GL_FALSE, 0, (void*)0 );
    glEnableVertexAttribArray( UV_ATTRIB_LOCATION );

    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, MAIN_TARGET_IDS_BUFFER_ID );

    // draw

    glDrawElements( GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0 );

    // free attrib arrays (not sure it's usefule here)

    glDisableVertexAttribArray( XY_ATTRIB_LOCATION );
    glDisableVertexAttribArray( UV_ATTRIB_LOCATION );

    // end
}


// -----------------------------------------------------------------------------
// OBJECTS STATIC PROPS --------------------------------------------------------
// -----------------------------------------------------------------------------

int GL_Entry::TICK = 0;

GL_Sheet ** GL_Entry::SHEETS;

GL_Sprites ** GL_Entry::SPRITES; // the sprites batches objects table

GL_Tilemap ** GL_Entry::TILEMAPS;

// -----------------------------------------------------------------------------
// OBJECTS STATIC METHODS ------------------------------------------------------
// -----------------------------------------------------------------------------

// create/delete/routine

bool GL_Entry::CreateObjects()
{

    // init classes static space

    bool ok;

    ok = GL_Sheet::Init( RGB::GetNumTextures() );
    if (!ok)
    {
        cout << "CANNOT INIT GL_Sheet" << endl;
        return false;
    }

    ok = GL_Sprites::Init();
    if (!ok)
    {
        cout << "CANNOT INIT GL_Sprites" << endl;
        return false;
    }

    ok = GL_Tilemap::Init();
    if (!ok)
    {
        cout << "CANNOT INIT GL_Tilemap" << endl;
        return false;
    }


    // create instances

    SHEETS = new GL_Sheet*[ RGB::GetNumTargetSheets() ];
    for ( int i=0; i < RGB::GetNumTargetSheets(); i++ )
    {
        SHEETS[i] = new GL_Sheet();
    }

    SPRITES = new GL_Sprites*[ RGB::GetNumSpritesBatches() ];
    for ( int i = 0; i < RGB::GetNumSpritesBatches(); i++ )
    {
        SpriteBatch * sb = RGB::GetSpritesBatchesAddr() + i;
        SPRITES[i] = new GL_Sprites( sb->numSprites, sb->XY, sb->UV, sb->PX );
    }

    TILEMAPS = new GL_Tilemap*[RGB::GetNumTilemaps()];
    for ( int i = 0; i < RGB::GetNumTilemaps(); i++ )
    {
        TileMap * tm = RGB::GetTilemapsAddr() + i;
        TILEMAPS[i] = new GL_Tilemap( tm->numCol, tm->numRow, tm->tiles, tm->scanlines );
    }

    // first render
    GL_Entry::ObjectsRoutine();

    return true;
}

void GL_Entry::DeleteObjects()
{
    // delete instances

    for ( int i=0; i < RGB::GetNumTilemaps(); i++ )
    {
        delete TILEMAPS[i];
    }
    delete [] TILEMAPS;

    for ( int i=0; i < RGB::GetNumSpritesBatches(); i++ )
    {
        delete SPRITES[i];
    }
    delete [] SPRITES;

    for ( int i=0; i < RGB::GetNumTargetSheets(); i++ )
    {
        delete SHEETS[i];
    }
    delete [] SHEETS;

    // shutdown classes static space

    GL_Tilemap::ShutDown();
    GL_Sprites::ShutDown();
    GL_Sheet::ShutDown();

}

// ROUTINES

void GL_Entry::ObjectsRoutine()
{
    // stream phase

    ObjectsStreamRoutine();
    UpdatePalette( RGB::GetPaletteAddress() ); // palette will be stored in module

    // clear main target buffer (will be removed because background does not blend)

    glBindFramebuffer(GL_FRAMEBUFFER, MAIN_TARGET_BUFFER_ID);
    glClearColor(0,0,1,1);
    glClear(GL_COLOR_BUFFER_BIT);

    // draw phase

    ObjectsDrawRoutine();
}

void GL_Entry::ObjectsStreamRoutine()
{
    for ( int i = 0; i < RGB::GetNumTextures(); i++ )
    {
        SheetTexture * st = RGB::GetSheetTexturesAddr() + i;
        if ( st->update )
        {
            cout << "STREAM SHEET TEXTURE " << i << endl;
            GL_Sheet::UpdateTexture(i, st->pixels );
            st->update = false;
        }
    }

    for ( int i = 0; i < RGB::GetNumTilemaps(); i++ )
    {
        TileMap * tm = RGB::GetTilemapsAddr() + i;
        TILEMAPS[i]->Stream( tm->updateMap, tm->updateScanlines );
        tm->updateMap = false;
        tm->updateScanlines = false;
    }

    for ( int i = 0; i < RGB::GetNumSpritesBatches(); i++)
    {
        SPRITES[i]->Stream();
    }
}

void GL_Entry::ObjectsDrawRoutine()
{
    // pre-render target sheets ----------------------------------------------

    for( int i=0; i<*RGB::GetNumSheetDrawsAddr(); i++ )
    {
        SheetDraw * d = RGB::GetSheetDrawInfoAddr() + i ;
        SHEETS[ d->dstTarget ]->Draw( d->srcTex, d->srcCol, d->srcRow, d->dstCol, d->dstRow, d->numCol, d->numRow );
    }

    // render maps and sprites -----------------------------------------------

    // background

    TileMap * tm = RGB::GetTilemapsAddr() + 0;
    TILEMAPS[0]->Draw( SHEETS[0]->GetRenderTexture(), tm->x, tm->y, false );

    SPRITES[0]->Draw( SHEETS[1]->GetRenderTexture() ); // background sprites

    // foreground

    tm = RGB::GetTilemapsAddr() + 1;
    TILEMAPS[1]->Draw( SHEETS[2]->GetRenderTexture(), tm->x, tm->y, true );

    SPRITES[1]->Draw( SHEETS[3]->GetRenderTexture() ); // should be used for player
    SPRITES[2]->Draw( SHEETS[4]->GetRenderTexture() ); // should be used for non-player

    SPRITES[3]->Draw( SHEETS[5]->GetRenderTexture() ); // lolypops, buttons
}
