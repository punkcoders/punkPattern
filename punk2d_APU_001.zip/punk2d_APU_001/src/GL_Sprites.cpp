#include "GL_Sprites.h"
#include "GL_Entry.h"
#include "RGB.h"

#include <mem.h>
#include <iostream>
using namespace std;

// -----------------------------------------------------------------------------
// STATIC SPACE ----------------------------------------------------------------
// -----------------------------------------------------------------------------

bool GL_Sprites::INIT = false;
unsigned int GL_Sprites::NUM_INSTANCES = 0;

// shaders and locations

const char * GL_Sprites::VERTEX_SHADER[] =
{
    "attribute highp vec4 aVertexXY;                                \n"
    "attribute highp vec2 aVertexUV, aVertexUVinfo;                 \n"
    "                                                               \n"
    "varying highp vec2 UV, UVinfo;                                 \n"
    "                                                               \n"
    "void main()                                                    \n"
    "{                                                              \n"
    "   UV = aVertexUV;                                             \n"
    "   UVinfo = aVertexUVinfo;                                     \n"
    "   gl_Position = aVertexXY;                                    \n"
    "}                                                              \n"
};

const char * GL_Sprites::FRAGMENT_SHADER[] =
{
    "varying highp vec2 UV, UVinfo;                                 \n"
    "                                                               \n"
    "uniform sampler2D uSheetTexture;                               \n"
    "uniform sampler2D uPaletteTexture;                             \n"
    "uniform sampler2D uInfoTexture;                                \n"
    "                                                               \n"
    "const highp float a = 255.0/256.0, b = 1.0/32.0;               \n"
    "                                                               \n"
    "highp float palU, palV;                                        \n"
    "highp vec2 UVpal;                                              \n"
    "                                                               \n"
    "void main()                                                    \n"
    "{                                                              \n"
    "   palU = texture2D( uSheetTexture, UV ).a;                    \n"
    "   palV = texture2D( uInfoTexture, UVinfo ).a;                 \n"
    "   UVpal = a*vec2( palU, palV )+b;                             \n"
    "   gl_FragColor = texture2D( uPaletteTexture, UVpal );         \n"
    "}                                                              \n"
};

GLuint GL_Sprites::VERTEX_SHADER_ID, GL_Sprites::FRAGMENT_SHADER_ID, GL_Sprites::SHADER_PROGRAM_ID;

GLuint GL_Sprites::XY_ATTRIB_LOCATION, GL_Sprites::UV_SHEET_ATTRIB_LOCATION, GL_Sprites::UV_INFO_ATTRIB_LOCATION;
GLuint GL_Sprites::SHEET_TEXTURE_UNIFORM_LOCATION, GL_Sprites::PALETTE_TEXTURE_UNIFORM_LOCATION, GL_Sprites::INFO_TEXTURE_UNIFORM_LOCATION;


// init / shutdown

bool GL_Sprites::Init()
{
    // CREATE SHADER ------------------------------------------------------------

    bool result = GL_Entry::MakeShader(&VERTEX_SHADER_ID,&FRAGMENT_SHADER_ID,&SHADER_PROGRAM_ID,VERTEX_SHADER,FRAGMENT_SHADER,"GL_Sprites");
    if ( ! result )
    {
        cout << "GL_Sprites CANNOT COMPILE SHADER" << endl;
        return false;
    }

    // get locations

    XY_ATTRIB_LOCATION = glGetAttribLocation(SHADER_PROGRAM_ID,"aVertexXY");
    UV_SHEET_ATTRIB_LOCATION = glGetAttribLocation(SHADER_PROGRAM_ID,"aVertexUV");
    UV_INFO_ATTRIB_LOCATION = glGetAttribLocation(SHADER_PROGRAM_ID,"aVertexUVinfo");

    cout << "GL_Sprites XY attr loc: " << XY_ATTRIB_LOCATION << endl;
    cout << "GL_Sprites sheetUV attr loc: " << UV_SHEET_ATTRIB_LOCATION << endl;
    cout << "GL_Sprites infoUV attr loc: " << UV_INFO_ATTRIB_LOCATION << endl;

    SHEET_TEXTURE_UNIFORM_LOCATION = glGetUniformLocation(SHADER_PROGRAM_ID,"uSheetTexture");
    PALETTE_TEXTURE_UNIFORM_LOCATION = glGetUniformLocation(SHADER_PROGRAM_ID,"uPaletteTexture");
    INFO_TEXTURE_UNIFORM_LOCATION = glGetUniformLocation(SHADER_PROGRAM_ID,"uInfoTexture");

    cout << "GL_Sprites Sheet Tex unif loc: " << SHEET_TEXTURE_UNIFORM_LOCATION << endl;
    cout << "GL_Sprites Info Tex unif loc: " << INFO_TEXTURE_UNIFORM_LOCATION << endl;
    cout << "GL_Sprites Palette Tex unif loc: " << PALETTE_TEXTURE_UNIFORM_LOCATION << endl;

    // if not return error
    INIT = true;

    return true;
}

void GL_Sprites::ShutDown()
{
    if ( !INIT )
    {
        return;
    }

    // delete the shaders

    glDetachShader( SHADER_PROGRAM_ID, VERTEX_SHADER_ID );
    glDetachShader( SHADER_PROGRAM_ID, FRAGMENT_SHADER_ID );
    glDeleteShader( VERTEX_SHADER_ID );
    glDeleteShader( FRAGMENT_SHADER_ID );

    cout << "GL_Sprites shader deleted" << endl;
}

// -----------------------------------------------------------------------------
// INSTANCE SPACE --------------------------------------------------------------
// -----------------------------------------------------------------------------

// constructor & destructor

GL_Sprites::GL_Sprites( unsigned short numSprites, float * bufXY, float * bufUV, unsigned char * bufPX )
{
    if (!INIT)
    {
        cout << "   GL_Sprites not INIT, cannot instance !" << endl;
        return;
    }

    // instance index

    m_instanceIndex = NUM_INSTANCES;
    NUM_INSTANCES++;

    // round num sprites to next power 2

    m_numSprites = 1;
    while ( m_numSprites < numSprites )
    {
        m_numSprites <<= 1;
    }

    // create vertex buffers

    m_XY = bufXY ;
    memset( m_XY, 0, m_numSprites * 8 * 4 );
    glGenBuffers( 1, &m_XYbufferId );

    m_UVsheet = bufUV ;
    memset( m_UVsheet, 0, m_numSprites * 8 * 4 );
    glGenBuffers( 1, &m_UVsheetBufferId );

    float * UVinfo = new float[ m_numSprites * 8 ];
    double pixW = 1.0 / (double)m_numSprites; // width of a pixel in u coord
    for ( unsigned int i = 0; i < m_numSprites; i++ )
    {
        for ( int j=0; j<4; j++ )
        {
            UVinfo[ i*8 + j*2 + 0 ] = pixW * ( .5 + i );
            UVinfo[ i*8 + j*2 + 1 ] = .5;
        }
    }
    glGenBuffers( 1, &m_UVinfoBufferId );
    glBindBuffer(GL_ARRAY_BUFFER, m_UVinfoBufferId);
    glBufferData(GL_ARRAY_BUFFER, m_numSprites * 8 * 4, UVinfo, GL_STATIC_DRAW );
    delete [] UVinfo;

    unsigned short * IDS = new unsigned short[ m_numSprites * 6 ];
    for ( unsigned int i = 0; i < m_numSprites; i++ )
    {
        IDS[ i*6 + 0 ] = i*4 + 0;
        IDS[ i*6 + 1 ] = i*4 + 1;
        IDS[ i*6 + 2 ] = i*4 + 2;
        IDS[ i*6 + 3 ] = i*4 + 2;
        IDS[ i*6 + 4 ] = i*4 + 3;
        IDS[ i*6 + 5 ] = i*4 + 0;
    }
    glGenBuffers( 1, &m_IDSbufferId );
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_IDSbufferId);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, m_numSprites * 6 * 2, IDS, GL_STATIC_DRAW);
    delete [] IDS;

    // create info texture

    m_infoTable = bufPX;
    glGenTextures(1,&m_infoTextureId);
    glBindTexture(GL_TEXTURE_2D,m_infoTextureId);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

    //optimize later
    /*glBindTexture(GL_TEXTURE_1D,m_infoTextureId);
    glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);*/

    cout << "   GL_Sprites instance " << m_instanceIndex << " with " << numSprites << " sprites created." << endl;
}

GL_Sprites::~GL_Sprites()
{
    // delete info texture

    glDeleteTextures(1, &m_infoTextureId);
    m_infoTable = nullptr;

    // delete vertex buffers

    glDeleteBuffers(1, &m_XYbufferId);
    m_XY = nullptr;

    glDeleteBuffers(1, &m_UVsheetBufferId);
    m_UVsheet = nullptr;

    glDeleteBuffers(1, &m_UVinfoBufferId);

    glDeleteBuffers(1, &m_IDSbufferId);


    cout << "   GL_Sprites instance " << m_instanceIndex << " deleted." << endl;
}

// video routine methods

void GL_Sprites::Stream()
{
    // stream sprite info texture

    glBindTexture( GL_TEXTURE_2D, m_infoTextureId );
    glTexImage2D( GL_TEXTURE_2D, 0, GL_ALPHA, m_numSprites, 1, 0, GL_ALPHA, GL_UNSIGNED_BYTE, m_infoTable );
    // optimize later
    // glTexImage1D( GL_TEXTURE_1D, 0, GL_ALPHA, m_numSprites, 1, GL_ALPHA, GL_UNSIGNED_BYTE, m_infoTable );

    // stream vertexBuffers

    glBindBuffer( GL_ARRAY_BUFFER, m_XYbufferId);
    glBufferData( GL_ARRAY_BUFFER, m_numSprites * 8 * 4, m_XY, GL_DYNAMIC_DRAW );

    glBindBuffer( GL_ARRAY_BUFFER, m_UVsheetBufferId );
    glBufferData( GL_ARRAY_BUFFER, m_numSprites * 8 * 4, m_UVsheet, GL_DYNAMIC_DRAW );

}

void GL_Sprites::Draw( GLuint idTexture )
{
    // draw in main target buffer

    glBindFramebuffer( GL_FRAMEBUFFER, GL_Entry::GetMainTargetBuffer() );
    glViewport( 0, 0, GL_Entry::GetMainTargetWidth(), GL_Entry::GetMainTargetHeight() );

    glEnable( GL_BLEND );
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

    // select shader

    glUseProgram( SHADER_PROGRAM_ID );

    // select vertbuffers

    glBindBuffer( GL_ARRAY_BUFFER, m_XYbufferId );
    glVertexAttribPointer( XY_ATTRIB_LOCATION, 2, GL_FLOAT, GL_FALSE, 0, (void*)0 );
    glEnableVertexAttribArray( XY_ATTRIB_LOCATION );

    glBindBuffer( GL_ARRAY_BUFFER, m_UVsheetBufferId );
    glVertexAttribPointer( UV_SHEET_ATTRIB_LOCATION, 2, GL_FLOAT, GL_FALSE, 0, (void*)0 );
    glEnableVertexAttribArray( UV_SHEET_ATTRIB_LOCATION );

    glBindBuffer( GL_ARRAY_BUFFER, m_UVinfoBufferId );
    glVertexAttribPointer( UV_INFO_ATTRIB_LOCATION, 2, GL_FLOAT, GL_FALSE, 0, (void*)0 );
    glEnableVertexAttribArray( UV_INFO_ATTRIB_LOCATION );

    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, m_IDSbufferId );

    // select textures

    glActiveTexture( GL_TEXTURE0 );
    glUniform1i( SHEET_TEXTURE_UNIFORM_LOCATION, 0 );
    glBindTexture( GL_TEXTURE_2D, idTexture );

    glActiveTexture( GL_TEXTURE1 );
    glUniform1i( INFO_TEXTURE_UNIFORM_LOCATION, 1 );
    glBindTexture( GL_TEXTURE_2D, m_infoTextureId );
    // optimize later
    //glBindTexture( GL_TEXTURE_1D, m_infoTextureId );

    glActiveTexture( GL_TEXTURE2 );
    glUniform1i( PALETTE_TEXTURE_UNIFORM_LOCATION, 2 );
    glBindTexture( GL_TEXTURE_2D, GL_Entry::GetPaletteTexture() );

    // draw

    glDrawElements( GL_TRIANGLES, m_numSprites*6, GL_UNSIGNED_SHORT, (void*)0 );

    // free attrib arrays (not sure it's useful here)

    glDisableVertexAttribArray(XY_ATTRIB_LOCATION);
    glDisableVertexAttribArray(UV_SHEET_ATTRIB_LOCATION);
    glDisableVertexAttribArray(UV_INFO_ATTRIB_LOCATION);

}
