#include "GL_Sheet.h"
#include "GL_Entry.h"

#include <iostream>
using namespace std;

// --------------------------------------------------------------------
// STATIC SPACE -------------------------------------------------------
// --------------------------------------------------------------------

bool GL_Sheet::INIT = false;
unsigned int GL_Sheet::NUM_INSTANCES = 0;

// shaders and locations

const char * GL_Sheet::VERTEX_SHADER[] =
{
    "attribute highp vec4 aVertexXY;                                \n"
    "attribute highp vec2 aVertexUV;                                \n"
    "                                                               \n"
    "varying highp vec2 UV;                                         \n"
    "                                                               \n"
    "void main()                                                    \n"
    "{                                                              \n"
    "   UV = aVertexUV;                                             \n"
    "   gl_Position =  aVertexXY;                                   \n"
    "}                                                              \n"
};

const char * GL_Sheet::FRAGMENT_SHADER[] =
{
    "varying highp vec2 UV;                                         \n"
    "                                                               \n"
    "uniform sampler2D uSheetTexture;                               \n"
    "                                                               \n"
    "void main()                                                    \n"
    "{                                                              \n"
    "    gl_FragColor = texture2D( uSheetTexture, UV ).rgba;        \n"
    "}                                                              \n"
};

GLuint GL_Sheet::VERTEX_SHADER_ID, GL_Sheet::FRAGMENT_SHADER_ID, GL_Sheet::SHADER_PROGRAM_ID;

GLuint GL_Sheet::XY_ATTRIB_LOCATION, GL_Sheet::UV_ATTRIB_LOCATION;
GLuint GL_Sheet::TEXTURE_UNIFORM_LOCATION;

// vertices

float GL_Sheet::XY[] = {  -1.0, -1.0, 1.0, -1.0,  1.0, 1.0,  -1.0, 1.0 };
GLuint GL_Sheet::XY_BUFFER_ID;
float GL_Sheet::UV[] = {   0, 0,  1, 0,  1, 1,  0, 1 };
GLuint GL_Sheet::UV_BUFFER_ID;
unsigned short GL_Sheet::IDS[] = {0,1,2,2,3,0};
GLuint GL_Sheet::IDS_BUFFER_ID;

// textures

unsigned char GL_Sheet::NUM_TEXTURES;
GLuint * GL_Sheet::TEXTURES;

// INIT / SHUTDOWN ----------------------------------------------------

bool GL_Sheet::Init( unsigned char numTextures )
{
    if ( numTextures == 0 )
    {
        cout << "GL_Sheet ERROR, at least one texture required !" << endl;
        return false;
    }

    // CREATE SHADER ------------------------------------------------------------

    bool result = GL_Entry::MakeShader(&VERTEX_SHADER_ID,&FRAGMENT_SHADER_ID,&SHADER_PROGRAM_ID,VERTEX_SHADER,FRAGMENT_SHADER,"GL_Sheet");
    if ( ! result )
    {
        return false;
    }

    // get locations

    TEXTURE_UNIFORM_LOCATION = glGetUniformLocation( SHADER_PROGRAM_ID, "uSheetTexture" );
    XY_ATTRIB_LOCATION = glGetAttribLocation( SHADER_PROGRAM_ID, "aVertexXY" );
    UV_ATTRIB_LOCATION = glGetAttribLocation( SHADER_PROGRAM_ID, "aVertexUV" );

    cout << "GL_Sheet Tex unif loc: " << TEXTURE_UNIFORM_LOCATION << endl;
    cout << "GL_Sheet XY attr loc: " << XY_ATTRIB_LOCATION << endl;
    cout << "GL_Sheet UV attr loc: " << UV_ATTRIB_LOCATION << endl;

    // create the vertices

    glGenBuffers( 1, &XY_BUFFER_ID );
    glBindBuffer( GL_ARRAY_BUFFER, XY_BUFFER_ID );
    glBufferData( GL_ARRAY_BUFFER, sizeof(XY), XY, GL_STATIC_DRAW );

    glGenBuffers( 1, &UV_BUFFER_ID );
    glBindBuffer( GL_ARRAY_BUFFER, UV_BUFFER_ID );
    glBufferData( GL_ARRAY_BUFFER, sizeof(UV), UV, GL_STATIC_DRAW );

    glGenBuffers( 1, &IDS_BUFFER_ID );
    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, IDS_BUFFER_ID );
    glBufferData( GL_ELEMENT_ARRAY_BUFFER, sizeof(IDS), IDS, GL_STATIC_DRAW );

    // create the textures table

    NUM_TEXTURES = numTextures;
    TEXTURES = new GLuint[ NUM_TEXTURES ];

    for ( int i = 0; i < NUM_TEXTURES; i++ )
    {
        GLuint textureId;

        glGenTextures( 1, &textureId );
        glBindTexture( GL_TEXTURE_2D, textureId );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );

        TEXTURES[i] = textureId;
    }

    cout << "GL_Sheet " << (int)NUM_TEXTURES << " textures created" << endl;

    // if not return error
    INIT = true;

    return true;
}

void GL_Sheet::ShutDown()
{
    if (!INIT)
    {
        return;
    }

    // delete the textures table

    for ( int i = 0; i < NUM_TEXTURES; i++ )
    {
        GLuint textureId = TEXTURES[i];
        glDeleteTextures(1, &textureId);
    }
    delete [] TEXTURES;

    cout << "GL_Sheet " << (int)NUM_TEXTURES << " textures deleted" << endl;

    // delete the vertices

    glDeleteBuffers( 1, &IDS_BUFFER_ID );
    glDeleteBuffers( 1, &UV_BUFFER_ID );
    glDeleteBuffers( 1, &XY_BUFFER_ID );

    cout << "GL_Sheet vertices deleted" << endl;

    // delete the shaders

    glDetachShader( SHADER_PROGRAM_ID, VERTEX_SHADER_ID );
    glDetachShader( SHADER_PROGRAM_ID, FRAGMENT_SHADER_ID );
    glDeleteShader( VERTEX_SHADER_ID );
    glDeleteShader( FRAGMENT_SHADER_ID );

    cout << "GL_Sheet shader deleted" << endl;
}

// textures setter / getter

void GL_Sheet::UpdateTexture( unsigned char indexTexture, void * data )
{
    if ( indexTexture >= NUM_TEXTURES )
    {
        indexTexture = NUM_TEXTURES - 1;
    }

    glBindTexture( GL_TEXTURE_2D, TEXTURES[indexTexture] );
    glTexImage2D( GL_TEXTURE_2D, 0, GL_ALPHA, GL_Entry::GetTileSheetSize(), GL_Entry::GetTileSheetSize(), 0, GL_ALPHA, GL_UNSIGNED_BYTE, data );

    cout << "GL_Sheet texture " << (int)indexTexture << " updated !" << endl;
}

GLuint GL_Sheet::GetTexture( unsigned char indexTexture ) // used for debugging only
{
    if ( indexTexture >= NUM_TEXTURES )
    {
        cout << "GL_Sheet::GetTexture INDEX OUT OF LIMITS !" << endl;
        return 0;
    }
    return TEXTURES[indexTexture];
}

// --------------------------------------------------------------------
// INSTANCE SPACE -----------------------------------------------------
// --------------------------------------------------------------------

// getters

GLuint GL_Sheet::GetRenderTexture()
{
    return m_targetTextureId;
}

// build and delete

GL_Sheet::GL_Sheet()
{
    if (!INIT)
    {
        cout << "   GL_Sheet not INIT, cannot instance !" << endl;
        return;
    }

    // instance index

    m_instanceIndex = NUM_INSTANCES;
    NUM_INSTANCES++;

    // create the renderTarget framebuffer and its texture

    glGenFramebuffers(1, &m_targetBufferId);

    glGenTextures( 1, &m_targetTextureId );
    glBindTexture( GL_TEXTURE_2D, m_targetTextureId );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, GL_Entry::GetTileSheetSize(), GL_Entry::GetTileSheetSize(), 0, GL_RGBA, GL_UNSIGNED_BYTE, 0 );

    glBindFramebuffer( GL_FRAMEBUFFER, m_targetBufferId );
    glFramebufferTexture( GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, m_targetTextureId, 0 );

    //unused for the moment
    //GLenum DrawBuffers[1] = {GL_COLOR_ATTACHMENT0};
    //glDrawBuffers(1, DrawBuffers);

    if(glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
    {
        cout << "   GL_Sheet instance " << m_instanceIndex << " RENDERTARGET FRAMEBUFFER CONFIGURATION ERROR" << endl;
        return;
    }

    cout << "   GL_Sheet instance " << m_instanceIndex << " frameBuffer " << m_targetBufferId << " created for texture " << m_targetTextureId << endl;
}

GL_Sheet::~GL_Sheet()
{
    // delete texture and buffer

    glDeleteTextures(1, &m_targetTextureId);
    glDeleteFramebuffers(1,&m_targetBufferId);

    cout << "   GL_Sheet instance " << m_instanceIndex << " deleted." << endl;
}

// rendering

void GL_Sheet::Draw( unsigned char indexTexture, unsigned char srcCol, unsigned char srcRow, unsigned char dstCol, unsigned char dstRow, unsigned char nCol, unsigned char nRow )
{
    if ( indexTexture >= NUM_TEXTURES )
    {
        indexTexture = NUM_TEXTURES - 1;
    }

    // update vertices -------------------------------------------------------

    const double sz = 1.0 / 16.0, W = nCol * sz, H = nRow * sz, x = 2 * sz * dstCol + W - 1, y = 2 * sz * dstRow + H - 1;

    XY[0] = x - W;
    XY[1] = y - H;

    XY[2] = x + W;
    XY[3] = y - H;

    XY[4] = x + W;
    XY[5] = y + H;

    XY[6] = x - W;
    XY[7] = y + H;

    const double u = srcCol * sz, v = srcRow * sz;

    UV[0] = u + 0;
    UV[1] = v + 0;

    UV[2] = u + W;
    UV[3] = v + 0;

    UV[4] = u + W;
    UV[5] = v + H;

    UV[6] = u + 0;
    UV[7] = v + H;

    // drawcall --------------------------------------------------------------

    // bind renderTarget frame buffer

    glBindFramebuffer( GL_FRAMEBUFFER, m_targetBufferId );
    glViewport( 0, 0, GL_Entry::GetTileSheetSize(), GL_Entry::GetTileSheetSize() );

    // no blend, alpha must erase alpha

    glDisable( GL_BLEND );

    // select shader program

    glUseProgram( SHADER_PROGRAM_ID );

    // bind texture

    //cout << (int)indexTexture << endl;

    glActiveTexture( GL_TEXTURE0 );
    glUniform1i( TEXTURE_UNIFORM_LOCATION, 0 );
    glBindTexture( GL_TEXTURE_2D, TEXTURES[indexTexture] );

    // bind vertices & stream

    glBindBuffer( GL_ARRAY_BUFFER, XY_BUFFER_ID );
    glBufferData( GL_ARRAY_BUFFER, sizeof(XY), XY, GL_DYNAMIC_DRAW );
    glVertexAttribPointer( XY_ATTRIB_LOCATION, 2, GL_FLOAT, GL_FALSE, 0, (void*)0 );
    glEnableVertexAttribArray( XY_ATTRIB_LOCATION );

    glBindBuffer( GL_ARRAY_BUFFER, UV_BUFFER_ID );
    glBufferData( GL_ARRAY_BUFFER, sizeof(UV), UV, GL_DYNAMIC_DRAW );
    glVertexAttribPointer( UV_ATTRIB_LOCATION, 2, GL_FLOAT, GL_FALSE, 0, (void*)0 );
    glEnableVertexAttribArray( UV_ATTRIB_LOCATION );

    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, IDS_BUFFER_ID );

    // draw

    glDrawElements( GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0 );

    // free attrib arrays (not sure it's usefule here)

    glDisableVertexAttribArray( XY_ATTRIB_LOCATION );
    glDisableVertexAttribArray( UV_ATTRIB_LOCATION );

}
