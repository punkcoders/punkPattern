#include "GL_Tilemap.h"
#include "GL_Entry.h"

#include <iostream>
using namespace std;

// --------------------------------------------------------------------
// STATIC SPACE -------------------------------------------------------
// --------------------------------------------------------------------

bool GL_Tilemap::INIT = false;
unsigned int GL_Tilemap::NUM_INSTANCES;

// shaders and locations

const char * GL_Tilemap::VERTEX_SHADER[] =
{
    "attribute highp vec4 aVertexXY;                                \n"
    "attribute highp vec2 aVertexUVmap;                             \n"
    "                                                               \n"
    "varying highp vec2 UVmap;                                      \n"
    "                                                               \n"
    "void main()                                                    \n"
    "{                                                              \n"
    "   UVmap = aVertexUVmap;                                       \n"
    "   gl_Position =  aVertexXY;                                   \n"
    "}                                                              \n"
};

const char * GL_Tilemap::FRAGMENT_SHADER[] =
{
    "varying highp vec2 UVmap;                                      \n"
    "                                                               \n"
    "uniform sampler2D uScanlineTexture;                            \n"
    "uniform sampler2D uMapTexture;                                 \n"
    "uniform sampler2D uSheetTexture;                               \n"
    "uniform sampler2D uPaletteTexture;                             \n"
    "uniform highp vec2 UVratio;                                    \n"
    "                                                               \n"
    "highp vec2 INVratio = vec2(1.0,1.0) / UVratio;                 \n"
    "highp vec4 scanline, tile;                                     \n"
    "highp vec2 UV, UVsheet, UVtile;                                \n"
    "highp float palX, palY;                                        \n"
    "const highp float a=255.0/256.0, b=1.0/32.0, _1=1.0, _2=2.0;   \n"
    "                                                               \n"
    "void main()                                                    \n"
    "{                                                              \n"
    "   scanline = texture2D( uScanlineTexture, UVmap );            \n"
    "   UV = UVmap + a*vec2( scanline.r, scanline.g ) * INVratio;   \n"
    "                                                               \n"
    "   tile = texture2D( uMapTexture, UV );                        \n"
    "                                                               \n"
    "   UVsheet = UVratio * vec2( (_1-tile.b*_2)*UV.x , UV.y );     \n"
    "   UVtile = a*vec2( tile.r, tile.g );                          \n"
    "                                                               \n"
    "   palX = a*texture2D( uSheetTexture, UVsheet+UVtile ).a+b;    \n"
    "   palY = a*tile.a+b;                                          \n"
    "   gl_FragColor = texture2D(uPaletteTexture,vec2(palX,palY));  \n"
    "}                                                              \n"
};

GLuint GL_Tilemap::VERTEX_SHADER_ID, GL_Tilemap::FRAGMENT_SHADER_ID, GL_Tilemap::SHADER_PROGRAM_ID;

GLuint GL_Tilemap::XY_ATTRIB_LOCATION, GL_Tilemap::UV_MAP_ATTRIB_LOCATION;
GLuint GL_Tilemap::UV_RATIO_UNIFORM_LOCATION;
GLuint GL_Tilemap::SCANLINES_TEXTURE_UNIFORM_LOCATION, GL_Tilemap::MAP_TEXTURE_UNIFORM_LOCATION, GL_Tilemap::SHEET_TEXTURE_UNIFORM_LOCATION, GL_Tilemap::PALETTE_TEXTURE_UNIFORM_LOCATION;


// XY & IDS vertex buffers

float GL_Tilemap::XY[] = {  -1.0, -1.0, 1.0, -1.0,  1.0, 1.0,  -1.0, 1.0 };
GLuint GL_Tilemap::XY_BUFFER_ID;

unsigned short GL_Tilemap::IDS[] = {0,1,2,2,3,0};
GLuint GL_Tilemap::IDS_BUFFER_ID;


// init / shutdown

bool GL_Tilemap::Init()
{
    // CREATE SHADER ------------------------------------------------------------

    bool result = GL_Entry::MakeShader(&VERTEX_SHADER_ID,&FRAGMENT_SHADER_ID,&SHADER_PROGRAM_ID,VERTEX_SHADER,FRAGMENT_SHADER,"GL_Tilemap");
    if ( ! result )
    {
        cout << "GL_Tilemap CANNOT COMPILE SHADER" << endl;
        return false;
    }

    // get locations

    XY_ATTRIB_LOCATION = glGetAttribLocation( SHADER_PROGRAM_ID, "aVertexXY" );
    UV_MAP_ATTRIB_LOCATION = glGetAttribLocation( SHADER_PROGRAM_ID, "aVertexUVmap" );

    UV_RATIO_UNIFORM_LOCATION = glGetUniformLocation( SHADER_PROGRAM_ID, "UVratio" );

    SCANLINES_TEXTURE_UNIFORM_LOCATION = glGetUniformLocation( SHADER_PROGRAM_ID, "uScanlineTexture" );
    MAP_TEXTURE_UNIFORM_LOCATION = glGetUniformLocation( SHADER_PROGRAM_ID, "uMapTexture" );
    SHEET_TEXTURE_UNIFORM_LOCATION = glGetUniformLocation( SHADER_PROGRAM_ID, "uSheetTexture" );
    PALETTE_TEXTURE_UNIFORM_LOCATION = glGetUniformLocation( SHADER_PROGRAM_ID, "uPaletteTexture" );

    cout << "GL_Tilemap UV ratio unif loc: " << UV_RATIO_UNIFORM_LOCATION << endl;

    cout << "GL_Tilemap Scanlines Tex unif loc: " << SCANLINES_TEXTURE_UNIFORM_LOCATION << endl;
    cout << "GL_Tilemap Map Tex unif loc: " << MAP_TEXTURE_UNIFORM_LOCATION << endl;
    cout << "GL_Tilemap Sheet Tex unif loc: " << SHEET_TEXTURE_UNIFORM_LOCATION << endl;
    cout << "GL_Tilemap Palette Tex unif loc: " << PALETTE_TEXTURE_UNIFORM_LOCATION << endl;

    cout << "GL_Tilemap XY attr loc: " << XY_ATTRIB_LOCATION << endl;;
    cout << "GL_Tilemap mapUV attr loc:" << UV_MAP_ATTRIB_LOCATION << endl;


    // create vertices

    glGenBuffers( 1, &XY_BUFFER_ID );
    glBindBuffer( GL_ARRAY_BUFFER, XY_BUFFER_ID );
    glBufferData( GL_ARRAY_BUFFER, sizeof(XY), XY, GL_STATIC_DRAW );

    glGenBuffers( 1, &IDS_BUFFER_ID );
    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, IDS_BUFFER_ID );
    glBufferData( GL_ELEMENT_ARRAY_BUFFER, sizeof(IDS), IDS, GL_STATIC_DRAW );


    // if not return error
    INIT = true;

    return true;
}

void GL_Tilemap::ShutDown()
{
    if (!INIT)
    {
        return;
    }

    // delete vertex buffers

    glDeleteBuffers( 1, &IDS_BUFFER_ID );
    glDeleteBuffers( 1, &XY_BUFFER_ID);

    cout << "GL_Tilemap vertices deleted" << endl;

    // delete the shaders

    glDetachShader( SHADER_PROGRAM_ID, VERTEX_SHADER_ID );
    glDetachShader( SHADER_PROGRAM_ID, FRAGMENT_SHADER_ID );
    glDeleteShader( VERTEX_SHADER_ID );
    glDeleteShader( FRAGMENT_SHADER_ID );

    cout << "GL_Tilemap shader deleted" << endl;
}

// --------------------------------------------------------------------
// INSTANCE SPACE -----------------------------------------------------
// --------------------------------------------------------------------

GL_Tilemap::GL_Tilemap( unsigned char numCol, unsigned char numRow, unsigned char * tiles, unsigned char * scanlines )
{
    if (!INIT)
    {
        cout << "   GL_Tilemap not INIT, cannot instance !" << endl;
        return;
    }

    // instance index

    m_instanceIndex = NUM_INSTANCES;
    NUM_INSTANCES++;

    // round map dimensions to power 2

    m_numCol = 1;
    while ( m_numCol < numCol )
    {
        m_numCol <<= 1;
    }
    m_numRow = 1;
    while ( m_numRow < numRow )
    {
        m_numRow <<= 1;
    }

    // xy dimensions

    m_mapHW = (double)GL_Entry::GetTileSheetSize() * GL_Entry::GetScaleWidth() / 16.0 * m_numCol; // pixel-perfect
    m_mapHH = (double)GL_Entry::GetTileSheetSize() * GL_Entry::GetScaleHeight() / 16.0 * m_numRow;

    // create uv buffer

    glGenBuffers( 1, &m_uvMapBufferId );
    glBindBuffer( GL_ARRAY_BUFFER, m_uvMapBufferId );
    glBufferData( GL_ARRAY_BUFFER, 4 * 2 * 4, m_uvMap, GL_STATIC_DRAW );

    // create scanlines texture

    m_numScanlines = GL_Entry::GetTileSheetSize() * m_numRow / 16;
    m_scanlines = scanlines;

    glGenTextures( 1, &m_scanlinesTextureid );
    glBindTexture( GL_TEXTURE_2D, m_scanlinesTextureid );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );

    // create tilemap texture

    m_map = tiles;

    glGenTextures( 1, &m_mapTextureId );
    glBindTexture( GL_TEXTURE_2D, m_mapTextureId );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );

    cout << "   GL_Tilemap instance " << m_instanceIndex << " " << (int)m_numCol << " x " << (int)m_numRow << " tiles" << endl;
}

GL_Tilemap::~GL_Tilemap()
{
    // delete textures

    glDeleteTextures( 1, &m_mapTextureId );
    glDeleteTextures( 1, &m_scanlinesTextureid );

    // delete UV buffer

    glDeleteBuffers( 1, &m_uvMapBufferId );

    cout << "   GL_Tilemap instance " << m_instanceIndex << " deleted." << endl;
}

// routines stream/draw

void GL_Tilemap::Stream( bool tilemap, bool scanlines )
{
    // stream scanlines texture

    if ( scanlines )
    {
        glBindTexture( GL_TEXTURE_2D, m_scanlinesTextureid );
        glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, 1, m_numScanlines, 0, GL_RGBA, GL_UNSIGNED_BYTE, m_scanlines );
    }

    // stream tilemap texture

    if ( tilemap )
    {
        glBindTexture( GL_TEXTURE_2D, m_mapTextureId );
        glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, m_numCol, m_numRow, 0, GL_RGBA, GL_UNSIGNED_BYTE, m_map );
    }
}

void GL_Tilemap::Draw( GLuint idTexture, int x, int y, bool blend )
{
    // CPU->GPU STREAM PHASE ---------------------------------------------------

    // stream XY, center coordinates and half width & heigh
    {
        // with and height of tilemap in pixels
        const int tileSize = GL_Entry::GetTileSheetSize()/16;
        const int mapW = tileSize * m_numCol ;
        const int mapH = tileSize * m_numRow ;

        // center x,y
        x = ( (x+mapW/2) & (mapW-1) ) - mapW/2;
        y = ( (y+mapH/2) & (mapH-1) ) - mapH/2;

        const double cx = x * GL_Entry::GetScaleWidth();
        const double cy = y * GL_Entry::GetScaleHeight();

        // cache half width and height
        const double hW = m_mapHW, hH = m_mapHH;

        // cache vertex table
        float * t = XY;

        t[ 0 ] = cx - hW;
        t[ 1 ] = cy - hH;

        t[ 2 ] = cx + hW;
        t[ 3 ] = cy - hH;

        t[ 4 ] = cx + hW;
        t[ 5 ] = cy + hH;

        t[ 6 ] = cx - hW;
        t[ 7 ] = cy + hH;
    }
    glBindBuffer( GL_ARRAY_BUFFER, XY_BUFFER_ID);
    glBufferData( GL_ARRAY_BUFFER, 8 * 4, XY, GL_DYNAMIC_DRAW);

    // DRAW PHASE --------------------------------------------------------------

    // draw in main target buffer

    glBindFramebuffer( GL_FRAMEBUFFER, GL_Entry::GetMainTargetBuffer() );
    glViewport( 0, 0, GL_Entry::GetMainTargetWidth(), GL_Entry::GetMainTargetHeight() );

    // blend or not

    if ( blend )
    {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    }
    else
    {
        glDisable(GL_BLEND);
    }

    // select shader

    glUseProgram(SHADER_PROGRAM_ID);

    // select vertbuffers

    glBindBuffer( GL_ARRAY_BUFFER, XY_BUFFER_ID);
    glVertexAttribPointer( XY_ATTRIB_LOCATION, 2, GL_FLOAT, GL_FALSE, 0,( void*)0 );
    glEnableVertexAttribArray( XY_ATTRIB_LOCATION );

    glBindBuffer( GL_ARRAY_BUFFER, m_uvMapBufferId );
    glVertexAttribPointer( UV_MAP_ATTRIB_LOCATION, 2, GL_FLOAT, GL_FALSE, 0, (void*)0 );
    glEnableVertexAttribArray( UV_MAP_ATTRIB_LOCATION );

    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, IDS_BUFFER_ID );

    // select textures

    glActiveTexture( GL_TEXTURE0 );
    glUniform1i( SCANLINES_TEXTURE_UNIFORM_LOCATION, 0 );
    glBindTexture( GL_TEXTURE_2D, m_scanlinesTextureid );

    glActiveTexture( GL_TEXTURE1 );
    glUniform1i( MAP_TEXTURE_UNIFORM_LOCATION, 1 );
    glBindTexture( GL_TEXTURE_2D, m_mapTextureId );

    glActiveTexture( GL_TEXTURE2 );
    glUniform1i( SHEET_TEXTURE_UNIFORM_LOCATION, 2 );
    glBindTexture( GL_TEXTURE_2D, idTexture );

    glActiveTexture( GL_TEXTURE3 );
    glUniform1i( PALETTE_TEXTURE_UNIFORM_LOCATION, 3 );
    glBindTexture( GL_TEXTURE_2D, GL_Entry::GetPaletteTexture() );

    // ratio UV map/texture uniform location

    glUniform2f( UV_RATIO_UNIFORM_LOCATION, (double)m_numCol / 16.0, (double)m_numRow / 16.0 );

    // draw

    glDrawElements( GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0 );

    // free attrib arrays (not sure it's useful here)

    glDisableVertexAttribArray( XY_ATTRIB_LOCATION );
    glDisableVertexAttribArray( UV_MAP_ATTRIB_LOCATION );
}
