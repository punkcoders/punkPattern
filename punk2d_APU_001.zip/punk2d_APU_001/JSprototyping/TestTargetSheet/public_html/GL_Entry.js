function GL_Entry()
{
    // static class
}


// on attaque par un bête shader de test qui va afficher les textures puis la target

GL_Entry.CRASHED = false;

// textures

GL_Entry.SCREEN_WIDTH = 240, GL_Entry.SCREEN_HEIGHT = 160;
GL_Entry.TEXTURE_WIDTH = 128, GL_Entry.TEXTURE_HEIGHT = 128;

// screen vertices

GL_Entry.SCREEN_XY = new Float32Array([ -1, -1, 1, -1,  1, 1,  -1, 1  ]);
GL_Entry.SCREEN_XY_ID = 0; GL_Entry.SCREEN_XY_BUFFER_ID = 0;
GL_Entry.SCREEN_UV =  new Float32Array([  0,  1,  1,  1,  1, 0,   0, 0 ]);
GL_Entry.SCREEN_UV_ID = 0; GL_Entry.SCREEN_UV_BUFFER_ID = 0;

GL_Entry.SCREEN_VERTS_IDS = new Uint16Array([0,1,2,2,3,0]);
GL_Entry.SCREEN_VERTS_IDS_ID = 0;

// shaders and locations

GL_Entry.GLSL_VS = `

    attribute vec4 aVertexXY;
    attribute vec2 aVertexUV;   
    
    varying highp vec2 vUV;
        
    void main(void)
    { 
        vUV = aVertexUV;
        gl_Position = aVertexXY;
    }

`;

GL_Entry.GLSL_FS = `

    varying highp vec2 vUV;

    uniform sampler2D uScreenTexture;

    highp float a;

    void main()
    {
        a = texture2D( uScreenTexture, vUV ).a * 15.0;
        gl_FragColor = vec4(a,a,0,1) ;
    }
`;

GL_Entry.VERTEX_SHADER_ID = 0; GL_Entry.FRAGMENT_SHADER_ID = 0; GL_Entry.SHADER_PROGRAM_ID = 0;

GL_Entry.XY_ATTRIB_LOCATION=0; GL_Entry.UV_ATTRIB_LOCATION=0;
GL_Entry.TEXTURE_UNIFORM_LOCATION = 0;


// sheets and layers

GL_Entry.BG_SHEET = null;


GL_Entry.init = function ( gl )
{
    console.log("   create GL objects");
   
    // create the vertex shader²
    GL_Entry.VERTEX_SHADER_ID = gl.createShader(gl.VERTEX_SHADER);
    console.log("   compile vertex shader: ");
    gl.shaderSource(GL_Entry.VERTEX_SHADER_ID,GL_Entry.GLSL_VS);
    gl.compileShader(GL_Entry.VERTEX_SHADER_ID);        
    // See if it compiled successfully
    if (!gl.getShaderParameter(GL_Entry.VERTEX_SHADER_ID, gl.COMPILE_STATUS)) {
        alert(' An error occurred compiling vertex shader: ' + gl.getShaderInfoLog(GL_Entry.VERTEX_SHADER_ID));
        gl.deleteShader(GL_Entry.VERTEX_SHADER_ID); // AJOUTER CA DANS LE CPP !!!
        GL_Entry.CRASHED = true;
        return false;
    }
    else
    {
        console.log("   vertex shader compiled");
    }

    // create the fragment shader
    GL_Entry.FRAGMENT_SHADER_ID = gl.createShader(gl.FRAGMENT_SHADER);
    console.log("   compile fragment shader: ");
    gl.shaderSource(GL_Entry.FRAGMENT_SHADER_ID,GL_Entry.GLSL_FS);
    gl.compileShader(GL_Entry.FRAGMENT_SHADER_ID);
    // See if it compiled successfully
    if (!gl.getShaderParameter(GL_Entry.FRAGMENT_SHADER_ID, gl.COMPILE_STATUS)) {
        alert(' An error occurred compiling fragment shader: ' + gl.getShaderInfoLog(GL_Entry.FRAGMENT_SHADER_ID));
        gl.deleteShader(GL_Entry.FRAGMENT_SHADER_ID); // AJOUTER CA DANS LE CPP !!!
        GL_Entry.CRASHED = true;
        return false;
    }
    else
    {
        console.log("   fragment shader compiled");
    }

    // link the program shader

    console.log("   link shaders program");
    GL_Entry.SHADER_PROGRAM_ID = gl.createProgram();
    gl.attachShader(GL_Entry.SHADER_PROGRAM_ID,GL_Entry.VERTEX_SHADER_ID);
    gl.attachShader(GL_Entry.SHADER_PROGRAM_ID,GL_Entry.FRAGMENT_SHADER_ID);
    gl.linkProgram(GL_Entry.SHADER_PROGRAM_ID);
    // If creating the shader program failed, alert
    if (!gl.getProgramParameter(GL_Entry.SHADER_PROGRAM_ID, gl.LINK_STATUS)) {
        alert(' Unable to link the shader program: ' + gl.getProgramInfoLog(GL_Entry.SHADER_PROGRAM_ID));
        gl.deleteShader(GL_Entry.VERTEX_SHADER_ID); // AJOUTER CA DANS LE CPP !!!
        gl.deleteShader(GL_Entry.FRAGMENT_SHADER_ID); // AJOUTER CA DANS LE CPP !!!
        GL_Entry.CRASHED = true;
        return false;
    }
    else
    {
        console.log("   programs linked");
    }

    // get locations

    GL_Entry.XY_ATTRIB_LOCATION = gl.getAttribLocation(GL_Entry.SHADER_PROGRAM_ID,"aVertexXY");
    GL_Entry.UV_ATTRIB_LOCATION = gl.getAttribLocation(GL_Entry.SHADER_PROGRAM_ID,"aVertexUV");
    GL_Entry.TEXTURE_UNIFORM_LOCATION = gl.getUniformLocation(GL_Entry.SHADER_PROGRAM_ID,"uScreenTexture");

   
    // create the vertices
       
    GL_Entry.SCREEN_XY_BUFFER_ID = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, GL_Entry.SCREEN_XY_BUFFER_ID);
    gl.bufferData(gl.ARRAY_BUFFER, GL_Entry.SCREEN_XY, gl.STATIC_DRAW);

    GL_Entry.SCREEN_UV_BUFFER_ID = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, GL_Entry.SCREEN_UV_BUFFER_ID);
    gl.bufferData(gl.ARRAY_BUFFER, GL_Entry.SCREEN_UV, gl.STATIC_DRAW);

    GL_Entry.SCREEN_VERTS_IDS_ID = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, GL_Entry.SCREEN_VERTS_IDS_ID);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, GL_Entry.SCREEN_VERTS_IDS, gl.STATIC_DRAW);
   
   
    // create renderTarget sheets
   
    GL_Entry.BG_SHEET = new GL_TargetSheet( gl, 2, [UGB.addrTex0,UGB.addrTex1], "BGtileSheet" );  
    if ( GL_Entry.BG_SHEET.compiled === false )
    {
        console.log("cannot create target sheet");
        return false;
    }

   
    return true;
};

GL_Entry.shutDown = function ( gl )
{
    console.log("   delete GL objects");
    
    // delete renderTarget sheet
    
    GL_Entry.BG_SHEET.Delete( gl );
    
    
    // delete the shaders

    if (!GL_Entry.CRASHED)
    {
        gl.detachShader(GL_Entry.SHADER_PROGRAM_ID,GL_Entry.VERTEX_SHADER_ID);
        gl.detachShader(GL_Entry.SHADER_PROGRAM_ID,GL_Entry.FRAGMENT_SHADER_ID);
        gl.deleteShader(GL_Entry.VERTEX_SHADER_ID);
        gl.deleteShader(GL_Entry.FRAGMENT_SHADER_ID);
        console.log("   shaders deleted");
        return 0;
    }

    // delete the vertices

    gl.deleteBuffer(GL_Entry.SCREEN_VERTS_IDS_ID);
    gl.deleteBuffer(GL_Entry.SCREEN_XY_BUFFER_ID);
    console.log("   vertices deleted");

    // delete the sheets
    
    GL_Entry.BG_SHEET.Delete();

    // delete table
    GL_Entry.SCREEN_TEXTURE_BUFFER = null;
    console.log("   textures data deleted");    
    
};

GL_Entry.FRAME_COUNTER = 0;

GL_Entry.videoRoutine = function ( gl )
{
    if ( GL_Entry.CRASHED )
    {
        return;
    }      

    // UPDATE TEXTURES IF BOOL TRUE --------------------------------------------

    if ( UGB.addrTexUpdate[0] )
    {
        GL_Entry.BG_SHEET.UpdateTexture( gl, 0 );
        GL_Entry.BG_SHEET.DrawTilesInSheet( gl, 0, 16, 16, 0, 0 );
        UGB.addrTexUpdate[0] = 0;
    }
    
    if ( UGB.addrTexUpdate[1] )
    {
        GL_Entry.BG_SHEET.UpdateTexture( gl, 1 );
        UGB.addrTexUpdate[1] = 0;
    }
    
    // DRAW SECOND TEXTURE IF ANIMATION RECT -----------------------------------
   
    let copyTexRect = UGB.addrBgMapSheetCopy;
    GL_Entry.BG_SHEET.DrawTilesInSheet( gl, 1, copyTexRect[0], copyTexRect[1] , copyTexRect[2], copyTexRect[3] );


    // NOW DRAW ON SCREEN ------------------------------------------------------
    
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, GL_Entry.SCREEN_WIDTH, GL_Entry.SCREEN_HEIGHT); // aller chercher ces dimensions ailleurs


    // select shader program
    
    gl.useProgram(GL_Entry.SHADER_PROGRAM_ID);

    // bind textures

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D,GL_Entry.BG_SHEET.GetSheetID());
    gl.uniform1i(GL_Entry.TEXTURE_UNIFORM_LOCATION,0);

    // bind vertices

    gl.bindBuffer(gl.ARRAY_BUFFER, GL_Entry.SCREEN_XY_BUFFER_ID );
    gl.vertexAttribPointer(GL_Entry.XY_ATTRIB_LOCATION,2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(GL_Entry.XY_ATTRIB_LOCATION);

    gl.bindBuffer(gl.ARRAY_BUFFER, GL_Entry.SCREEN_UV_BUFFER_ID );
    gl.vertexAttribPointer(GL_Entry.UV_ATTRIB_LOCATION,2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(GL_Entry.UV_ATTRIB_LOCATION);

    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,GL_Entry.SCREEN_VERTS_IDS_ID); 
    
    // draw test (will be replaced by objects)
    
    gl.disable(gl.BLEND);
    
    gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0);

    // free attrib arrays

    gl.disableVertexAttribArray(GL_Entry.XY_ATTRIB_LOCATION);
    gl.disableVertexAttribArray(GL_Entry.UV_ATTRIB_LOCATION);
    
    GL_Entry.FRAME_COUNTER++;
};