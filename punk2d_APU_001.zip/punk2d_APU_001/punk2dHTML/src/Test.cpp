#include "Test.h"
#include "GAME_DATA_Sheets.h"
#include "PPU.h"

#include <cmath>
#include <iostream>
using namespace std;

// build & delete ----------------------------------------------------------------

void Test::Init()
{
    // events callbacks

    ROOT_DeviceManager::SetVideoRoutine(TestVideoRoutine);
    ROOT_DeviceManager::SetAudioRoutine(OnAudioRoutine);
    ROOT_DeviceManager::SetKeyDownEvent(OnKeyDown);
    ROOT_DeviceManager::SetKeyUpEvent(OnKeyUp);
    ROOT_DeviceManager::SetMouseDownEvent(OnClick);
    ROOT_DeviceManager::SetMouseUpEvent(OnClick);
    ROOT_DeviceManager::SetFileErrorEvent(OnFileError);
    ROOT_DeviceManager::SetFileLoadedEvent(OnFileLoaded);

    // start tests

    CURSOR = 19;
    CUR_SAMPLE = 0;
    VOL = 0.0f;
    FREQ = 132.0f;
    PAN = 0.0f;

    cout << "TEST INIT" << endl;

    // init textures

    PPU::UncompressSheet( GAME_DATA_Sheets::SHEET_1, 0 );
    PPU::UncompressSheet( GAME_DATA_Sheets::SHEET_2, 1 );

    // init targets

    // 0: background tilemap
    PPU::DrawInTargetSheet(0,0,0,0,0,0,16,16);
    // 1: background sprites
    PPU::DrawInTargetSheet(1,1,0,0,0,0,16,16);
    // 2: foreground tilemap
    PPU::DrawInTargetSheet(1,2,0,0,0,0,16,16);
    // 3,4,5: foreground sprites
    PPU::DrawInTargetSheet(1,3,0,0,0,0,16,16);
    PPU::DrawInTargetSheet(1,4,0,0,0,0,16,16);
    PPU::DrawInTargetSheet(1,5,0,0,0,0,16,16);

    // defaut palette (blue color, alpha gradient)

    double defPal[16*4];

    for ( int i=0; i<16; i++ )
    {
        defPal[ 4*i + 0 ] = 0;
        defPal[ 4*i + 1 ] = 0;
        defPal[ 4*i + 2 ] = 1;
        defPal[ 4*i + 3 ] = (double)i/16.0;
    }

    for ( int j=0; j<16; j++ )
    {
        PPU::SetPalette16x(j,defPal);
    }

    // test tilemap

    for ( int j=0; j<32; j++ )
    {
        for ( int i=0; i<32; i++ )
        {
            PPU::SetTile( 0, i, j, i, j, (i+j)&1, false );
            PPU::SetTile( 1, i, j, 0, 0, 2, 0 );
        }
    }

    Write( "Press 1/2/3 to load a file.", 0 );

    NUMCOL = 480/16;
    NUMROW = 480/16;
    NUMCELL = NUMCOL * NUMROW;
}

// TEST VIDEO -------------------------------------------------------------

int Test::NUMCOL, Test::NUMROW, Test::NUMCELL;

double Test::GREY_PALETTE[16*4];
double Test::ROSE_PALETTE[16*4];

int Test::TICK = 0;
int Test::CURSOR = 0;


void Test::Write(const char* text, int cell)
{
    for (int i=0; text[i]; i++)
    {
        PPU::SetTile(1,(cell+i)%30,(cell+i)/30,text[i]&15,text[i]>>4,2,false);
    }
}

void Test::ClearText()
{
    for ( int j=0; j<32; j++)
    {
        for ( int i=0; i<32; i++ )
        {
            PPU::SetTile( 1, i, j, 0, 0, 2, false );
        }
    }
}

void Test::TestVideoRoutine()
{

    // -------------------------------------------------------------------------
    // test draws in render target sheets --------------------------------------
    // -------------------------------------------------------------------------

    PPU::DrawInTargetSheet(1, 5, 0, (TICK>>4)&15, 0, 0, 16, 16 );
    //PPU::DrawInTargetSheet( 0, 0, TICK&15, TICK&15, 3, 3, 1, 1 );

    // -------------------------------------------------------------------------
    // test tilemap scanlines and scroll ---------------------------------------
    // -------------------------------------------------------------------------

    for ( int y=0; y<512; y++ )
    {
        unsigned char offsetX = 255.0 * .5 * ( 1.0 + cos( (double)(TICK+y/2) / 64.0 * M_PI * 2 ) );
        unsigned char offsetY = 255.0 * .5 * ( 1.0 + sin( (double)(TICK+y/2) / 64.0 * M_PI * 2 ) );
        PPU::SetScanline( 0, y, offsetX/32, offsetY/32 );
    }

    PPU::Scroll(1, -240, 160);

    // -------------------------------------------------------------------------
    // test sprites ------------------------------------------------------------
    // -------------------------------------------------------------------------

    //const int mX = ROOT_DeviceManager::GetMouseX(), mY = ROOT_DeviceManager::GetMouseY();
    //PPU::SetSprite( 0, 1, mX-240, 160-mY, 1, 1, 3, 3, true, true, 0);
    //PPU::SetSprite( 0, 2, 0, 0, 8, 8, 3, 3, true, true, 1);
/*
    for ( int ib = 0; ib < RGB::GetNumSpritesBatches(); ib++ )
    {
        SpriteBatch * sb = RGB::GetSpritesBatchesAddr() + ib;

        for ( int i=0; i<sb->numSprites/2; i++ )
        {
            double arad = ( (double)TICK / 240.0 + (double)i / (double)sb->numSprites )* M_PI * 2;
            PPU::DrawSprite( ib, cos(arad)*(16+64*ib), sin(arad)*(16+16*ib), ib+1, ib+1, i&15, i>>4, i&1, (i*2)&1, i&1 );
        }
    }
*/

    // -------------------------------------------------------------------------
    // PALETTE ANIMATION -------------------------------------------------------
    // -------------------------------------------------------------------------

    double lightSin = sin ( (double)TICK / 60.0 * M_PI * 2 );

    // STEP 1: compute 1.0 watercolor layers

    // compute 1.0 colors black & white palette

    double * b_w = GREY_PALETTE;
    double * co;

    double offsetX = 8.0 + 4.0 * lightSin;

    // transparent->black zone
    for ( double cX = 0.0; cX < 4.0; cX += 1.0 )
    {
        co = b_w + ( ((int)cX&0xf) << 2 ) ; // color adress
        co[ 0 ] = 0;
        co[ 1 ] = 0;
        co[ 2 ] = 0;
        co[ 3 ] = cX / 4.0; // alpha
    }
    // black zone
    for ( double cX = 4.0; cX < offsetX; cX += 1.0 )
    {
        co = b_w + ( ((int)cX&0xf) << 2 ) ;
        co[ 0 ] = 0;
        co[ 1 ] = 0;
        co[ 2 ] = 0;
        co[ 3 ] = 1.0; // alpha
    }
    // grey zone
    for ( double cX = offsetX; cX < offsetX + 4.0; cX += 1.0 )
    {
        double val =  (double)( (int)cX+1-offsetX ) / 4.0;
        co = b_w + ( ((int)cX&0xf) << 2 ) ;
        co[ 0 ] = val;
        co[ 1 ] = val;
        co[ 2 ] = val;
        co[ 3 ] = 1.0;
    }
    // white zone
    for ( double cX = offsetX + 4.0; cX < 16.0; cX += 1.0 )
    {
        co = b_w + ( ((int)cX&0xf) << 2 ) ;
        co[ 0 ] = 1.0;
        co[ 1 ] = 1.0;
        co[ 2 ] = 1.0;
        co[ 3 ] = 1.0;
    }

    // compute 1.0 colors red palette

    double * red = ROSE_PALETTE;
    double * c2;

    offsetX = 11.0 + 3.0 * lightSin;

    // transparent->red zone
    for ( double cX = 0.0; cX < 4.0; cX += 1.0 )
    {
        co = b_w + ( ((int)cX&0xf) << 2 ) ;
        c2 = red + ( ((int)cX&0xf) << 2 ) ;
        c2[ 0 ] = 1.0 * co[0]; // red chan
        c2[ 1 ] = 0;
        c2[ 2 ] = 0;
        c2[ 3 ] = 1.0 * co[3]; // alpha chan
    }
    // red zone
    for ( double cX = 4.0; cX < offsetX; cX += 1.0 )
    {
        co = b_w + ( ((int)cX&0xf) << 2 ) ;
        c2 = red + ( ((int)cX&0xf) << 2 ) ;
        c2[ 0 ] = 1.0 * co[0]; // red chan
        c2[ 1 ] = 0;
        c2[ 2 ] = 0;
        c2[ 3 ] = 1.0 * co[3]; // alpha chan
    }
    // rose zone
    for ( double cX = offsetX; cX < offsetX + 4.0; cX += 1.0 )
    {
        co = b_w + ( ((int)cX&0xf) << 2 ) ;
        c2 = red + ( ((int)cX&0xf) << 2 ) ;
        double val =  (double)( (int)cX+1-offsetX ) / 4.0;
        c2[ 0 ] = 1.0 * co[0];
        c2[ 1 ] = val * co[1];
        c2[ 2 ] = val * co[2];
        c2[ 3 ] = 1.0 * co[3];
    }
    // white zone
    for ( double cX = offsetX + 4.0; cX < 16.0; cX += 1.0 )
    {
        c2 = red + ( ((int)cX&0xf) << 2 ) ;
        c2[ 0 ] = 1.0;
        c2[ 1 ] = 1.0;
        c2[ 2 ] = 1.0;
        c2[ 3 ] = 1.0;
    }

    // STEP 2: convert to unsigned long texture palette data

    PPU::SetPalette16x(0,GREY_PALETTE);
    PPU::SetPalette16x(1,ROSE_PALETTE);

    // text cursor sprite

    if( (TICK>>4)&1 )
    {
        PPU::DrawSprite( 1, (CURSOR)%NUMCOL*16-240 + 8, 160-(CURSOR)/NUMCOL*16 - 8, 1, 1, 1, 0, false, false, 1 );
    }

    // mouse cursor sprite

    unsigned char tile = *"x";
    PPU::DrawSprite( 1, ROOT_DeviceManager::GetMouseX()-240, 160-ROOT_DeviceManager::GetMouseY(), 1, 1, tile&15, tile>>4, false, false, 1 );

    TICK++;
}

// TEST AUDIO -------------------------------------------------------------

int Test::CUR_SAMPLE = 0;
float Test::VOL, Test::PAN, Test::FREQ;

void Test::SFX(float freq, float vol, float pan)
{
    VOL = vol;
    FREQ = freq;
    PAN = pan;
}

void Test::OnAudioRoutine()
{
    // stereo buffers ponters
    float* leftBuffer = ROOT_DeviceManager::GetLeftBufferAddress();
    float* rightBuffer = ROOT_DeviceManager::GetRightBufferAddress();
    // compute frequency
    float halfPeriod = ROOT_DeviceManager::GetSampleRate()/FREQ/2;
    // compute panoramic
    float vol = VOL;
    float leftVol = 0.02f * (-.5f*PAN+.5f);
    float rightVol = 0.02f * (.5f*PAN+.5f);
    // square wav
    int nSamples = ROOT_EntryPoint::SAMPLES_BY_AUDIOBUFFER;
    int cs = CUR_SAMPLE;
    float curveY;
    for (int i = 0; i<nSamples; i++ )
    {
        // compute curve
        curveY = (((int)((i+cs)/halfPeriod)&1)*2+1)*vol;
        vol *= 0.9999f;
        // write in buffers
        leftBuffer[i] = curveY*leftVol;
        rightBuffer[i] = curveY*rightVol;
    }
    VOL = vol;
    CUR_SAMPLE += nSamples;
}

// TEST FILES -------------------------------------------------------------

void Test::OnFileError()
{
    Write("FILE ERROR !                    ",0);
}
void Test::OnFileLoaded()
{
    ClearText();
    char* buffer = (char *)( ROOT_DeviceManager::GetFileBufferAddress() );
    Write( buffer, 0 );
}

// TEST KEYBOARD AND MOUSE ------------------------------------------------

void Test::OnKeyDown()
{
    char c[2]; // make a null terminated string to copy in text buffer
    c[0] = ROOT_DeviceManager::GetLastKeyChanged();
    c[1] = 0;

    cout << (int)c[0] << endl;

    Write( c, CURSOR);
    CURSOR = (CURSOR + 1)% NUMCELL;
    SFX(132.0f,1,(float)(CURSOR%NUMCOL)/(float)NUMCOL*2.0-1.0); // play a C

    if (c[0]>=49 && c[0]<=51)
    {
        ClearText();
        Write("LOADING...",0);
    }
    switch (c[0])
    {
    case 49:
        ROOT_DeviceManager::LoadFile("files/Game1.txt");
        break;
    case 50:
        ROOT_DeviceManager::LoadFile("files/Game2.txt");
        break;
    case 51:
        ROOT_DeviceManager::LoadFile("files/Game3.txt");
        break;
    case 27:
        ROOT_DeviceManager::Exit();
        break;
    }
}
void Test::OnKeyUp()
{
    SFX(132.0f*2,1,(float)(CURSOR%NUMCOL)/(float)NUMCOL*2.0-1.0 ); // play a C
}
void Test::OnClick()
{
    int col = ( (ROOT_DeviceManager::GetMouseX()) >> 4)%NUMCOL;
    int row = ( (ROOT_DeviceManager::GetMouseY()) >> 4)%NUMROW;
    CURSOR = col + NUMCOL*row;
}

