#include "ROOT_DeviceManager.h"

// video device

#include "RGB.h"
#include "PPU.h"

// audio device

#include <string.h>
#include <iostream>
using namespace std;

// init callbacks to invalid
void (*ROOT_DeviceManager::VIDEOROUTINE_EVENT)(void) = 0;
void (*ROOT_DeviceManager::AUDIOROUTINE_EVENT)(void) = 0;
void (*ROOT_DeviceManager::FILEERROR_EVENT)(void) = 0;
void (*ROOT_DeviceManager::FILELOADED_EVENT)(void) = 0;
void (*ROOT_DeviceManager::KEYDOWN_EVENT)(void) = 0;
void (*ROOT_DeviceManager::KEYUP_EVENT)(void) = 0;
void (*ROOT_DeviceManager::MOUSEDOWN_EVENT)(void) = 0;
void (*ROOT_DeviceManager::MOUSEUP_EVENT)(void) = 0;

// init / shut
bool ROOT_DeviceManager::EXIT = 0;
void ROOT_DeviceManager::Init()
{
    RGB::InitPointers();
    PPU::Init();
    ROOT_EntryPoint::Main();
}
void ROOT_DeviceManager::Exit()
{
    EXIT = 1;
}
bool ROOT_DeviceManager::GetExit()
{
    return EXIT;
}
void ROOT_DeviceManager::ShutDown()
{
    ROOT_EntryPoint::Exit();
    PPU::ShutDown();
    RGB::ClearRAM();
}

// video
void ROOT_DeviceManager::VideoRoutine(){
    PPU::StartVideoRoutine();
    if (VIDEOROUTINE_EVENT) VIDEOROUTINE_EVENT();
    PPU::EndVideoRoutine();
}
void ROOT_DeviceManager::SetVideoRoutine(void(*callback)(void)){VIDEOROUTINE_EVENT = callback;}

// audio
float* ROOT_DeviceManager::GetLeftBufferAddress(){return ROOT_Heart::GetLeftBufferAddress();}
float* ROOT_DeviceManager::GetRightBufferAddress(){return ROOT_Heart::GetRightBufferAddress();}
float ROOT_DeviceManager::GetSampleRate(){return ROOT_Heart::GetSampleRate();}
void ROOT_DeviceManager::AudioRoutine(){ if (AUDIOROUTINE_EVENT) AUDIOROUTINE_EVENT();}
void ROOT_DeviceManager::SetAudioRoutine(void(*callback)(void)){AUDIOROUTINE_EVENT=callback;}

// files
void* ROOT_DeviceManager::GetFileBufferAddress(){return ROOT_Heart::GetFileBufferAddress();}
void ROOT_DeviceManager::LoadFile(const char* fileName){ // replace by memset & memcpy
    char* fnBuf = ROOT_Heart::GetFileNameAddress();
    for (int i = 0; i<256; i++)
    {
        if (fileName[i]) fnBuf[i] = fileName[i];
        else fnBuf[i] = 0;
    }
    memset( ROOT_Heart::GetFileBufferAddress(), 0, ROOT_Heart::GetMaxFileSize() );
}
void ROOT_DeviceManager::SetFileErrorEvent(void(*callback)(void)) {FILEERROR_EVENT = callback;}
void ROOT_DeviceManager::OnFileError() { if(FILEERROR_EVENT) FILEERROR_EVENT();}
void ROOT_DeviceManager::SetFileLoadedEvent(void(*callback)(void)){FILELOADED_EVENT = callback;}
void ROOT_DeviceManager::OnFileLoaded(){ if (FILELOADED_EVENT) FILELOADED_EVENT();}

// controls
char ROOT_DeviceManager::GetLastKeyChanged(){ return *ROOT_Heart::GetLastKeyPressedAddress(); }
void ROOT_DeviceManager::OnKeyDown(){ if (KEYDOWN_EVENT) KEYDOWN_EVENT();}
void ROOT_DeviceManager::SetKeyDownEvent(void(*callback)(void)){KEYDOWN_EVENT = callback;}
void ROOT_DeviceManager::OnKeyUp(){ if (KEYUP_EVENT) KEYUP_EVENT();}
void ROOT_DeviceManager::SetKeyUpEvent(void(*callback)(void)){KEYUP_EVENT = callback;}

long ROOT_DeviceManager::GetMouseX(){ long* ptr = ROOT_Heart::GetMouseXAddress();  return *ptr; }
long ROOT_DeviceManager::GetMouseY(){ long* ptr = ROOT_Heart::GetMouseYAddress();  return *ptr; }
void ROOT_DeviceManager::OnMouseDown(){ if (MOUSEDOWN_EVENT) MOUSEDOWN_EVENT(); }
void ROOT_DeviceManager::SetMouseDownEvent(void(*callback)(void)) { MOUSEDOWN_EVENT = callback; }
void ROOT_DeviceManager::OnMouseUp(){ if (MOUSEUP_EVENT) MOUSEUP_EVENT(); }
void ROOT_DeviceManager::SetMouseUpEvent(void(*callback)(void)) { MOUSEUP_EVENT = callback; }

