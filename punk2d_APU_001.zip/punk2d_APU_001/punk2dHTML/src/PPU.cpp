#include "PPU.h"

#include <iostream>
using namespace std;

//sprites data

unsigned char PPU::NUM_BATCHES;
unsigned short * PPU::NUM_SPRITES_OF_BATCH, * PPU::CUR_SPRITE_OF_BATCH;
SpriteBatch * PPU::SPRITES_BATCHES;
double PPU::SCALE_WIDTH, PPU::SCALE_HEIGHT, PPU::TILE_HALFWIDTH, PPU::TILE_HALFHEIGHT;

// tilemaps data

unsigned char PPU::NUM_TILEMAPS;
TileMap * PPU::TILEMAPS;
unsigned short PPU::NUM_SCANLINES;


// EVENTS

void PPU::Init()
{
    NUM_BATCHES = RGB::GetNumSpritesBatches();

    NUM_SPRITES_OF_BATCH = new unsigned short[ NUM_BATCHES ];
    for ( int i = 0; i < NUM_BATCHES; i++ )
    {
        SpriteBatch * sb = RGB::GetSpritesBatchesAddr() + i;
        NUM_SPRITES_OF_BATCH[ i ] = sb->numSprites;
    }
    CUR_SPRITE_OF_BATCH = new unsigned short[ NUM_BATCHES ];

    SPRITES_BATCHES = RGB::GetSpritesBatchesAddr();

    SCALE_WIDTH = 2.0 / (double)RGB::GetScreenWidth();
    SCALE_HEIGHT = 2.0 / (double)RGB::GetScreenHeight();
    TILE_HALFWIDTH = RGB::GetSheetResolution() * SCALE_WIDTH / 16.0 *.5;
    TILE_HALFHEIGHT = RGB::GetSheetResolution() * SCALE_HEIGHT / 16.0 *.5;

    NUM_TILEMAPS = RGB::GetNumTilemaps();
    TILEMAPS = RGB::GetTilemapsAddr();
    NUM_SCANLINES = RGB::GetSheetResolution()/16 * 32 ;
}

void PPU::ShutDown()
{
    delete [] CUR_SPRITE_OF_BATCH;
    delete [] NUM_SPRITES_OF_BATCH;
}

void PPU::StartVideoRoutine()
{
    // reset counters of draw operations

    *RGB::GetNumSheetDrawsAddr() = 0;

    for ( int i = 0; i < NUM_BATCHES; i++ )
    {
        CUR_SPRITE_OF_BATCH[i] = 0;
    }
}

void PPU::EndVideoRoutine()
{
    // hide unused sprites

    for ( int i = 0; i < NUM_BATCHES; i++ )
    {
        while ( CUR_SPRITE_OF_BATCH[i] < NUM_SPRITES_OF_BATCH[i] )
        {
            DrawSprite(i,-1024,-1024,0,0,0,0,0,0,0);
        }
    }

}

// INSTRUCTIONS

void PPU::SetPalette16x( unsigned char y, double * rgba )
{
    unsigned char * c = RGB::GetPaletteAddress() + ( (y&15)*16 * 4 );
    const double m = 255.0;

    for ( int i=0; i < 16; i++ )
    {
        c[0] = (unsigned char)( rgba[0]*m );
        c[1] = (unsigned char)( rgba[1]*m );
        c[2] = (unsigned char)( rgba[2]*m );
        c[3] = (unsigned char)( rgba[3]*m );
        rgba += 4;
        c += 4;
    }
}

// uncompress tile sheets

void PPU::UncompressSheet( unsigned long * compressed, unsigned char indexTexture )
{
    if ( indexTexture >= RGB::GetNumTextures() )
    {
        cout << "ERROR: index texture " << (int)indexTexture << " upper than" << (int)RGB::GetNumTextures() << endl;
        return;
    }

    cout << "uncompress 16 color sheet in texture " << indexTexture << endl;

    SheetTexture * st = RGB::GetSheetTexturesAddr() + indexTexture;
    unsigned char * uncompressed = st->pixels;
    long row;

    for ( int y=0; y < 256; y++ )
    {
        for ( int r=0; r < 32; r++ )
        {
            row = compressed[ y*32 + r ]; // 32 long per y line

            for ( int x = 8 * r ; x < 8 * (r+1) ; x++ )
            {
                // get 16 color index and multiply by 16 for 0-255 alpha channel
                *uncompressed = ( row & 15 ) * 16;
                row >>= 4;
                uncompressed++;
            }
        }
    }

    // say to GL_Entry texture needs to be updated

    st->update = true;
}

// draw in rendertarget sheets

void PPU::DrawInTargetSheet( unsigned char srcTexture, unsigned char dstTarget, unsigned char srcCol, unsigned char srcRow, unsigned char dstCol, unsigned char dstRow, unsigned char numCol, unsigned char numRow )
{
    if ( (*RGB::GetNumSheetDrawsAddr()) > RGB::GetMaxSheetDraws() )
    {
        cout << "ERROR, cannot draw more " << (int)RGB::GetMaxSheetDraws() << " times per frame in render target sheets" << endl;
    }

    SheetDraw * sd = RGB::GetSheetDrawInfoAddr() + (*RGB::GetNumSheetDrawsAddr()) ;

    sd->srcTex = srcTexture;
    sd->dstTarget = dstTarget;
    sd->srcCol = srcCol;
    sd->srcRow = srcRow;
    sd->dstCol = dstCol;
    sd->dstRow = dstRow;
    sd->numCol = numCol;
    sd->numRow = numRow;

    (*RGB::GetNumSheetDrawsAddr()) ++;
}


// UPDATE SPRITES VERTEX TABLES

// remplacer par une spriteRam ? je suis pas s�r que �a optimise quelque chose...

void PPU::DrawSprite( unsigned char indexBatch, int x, int y, char nCol, char nRow, char col, char row, bool flipX, bool flipY, unsigned char paletteY )
{
    if ( indexBatch >= NUM_BATCHES )
    {
        cout << "ERROR, indexBatch " << (int)indexBatch << " > " << (int)NUM_BATCHES << endl;
        return;
    }

    const unsigned short indexSprite = CUR_SPRITE_OF_BATCH[indexBatch];
    if ( indexSprite >= NUM_SPRITES_OF_BATCH[indexBatch] )
    {
        return;
    }

    // caching

    const double scaleWidth = SCALE_WIDTH, scaleHeight = SCALE_HEIGHT, tileHalfWidth = TILE_HALFWIDTH, tileHalfHeight = TILE_HALFHEIGHT;

    // precompute first index

    SpriteBatch * sb = SPRITES_BATCHES + indexBatch;
    const int fi = indexSprite * 8;

    // xy coords ------------------------------------------------------------------

    // center coordinates and half width & height

    const double cx = x * scaleWidth, cy = y * scaleHeight, hW = tileHalfWidth * nCol, hH = tileHalfHeight * nRow;

    float * t = sb->XY; // cache table

    t[ fi + 0 ] = cx - hW;
    t[ fi + 1 ] = cy - hH;

    t[ fi + 2 ] = cx + hW;
    t[ fi + 3 ] = cy - hH;

    t[ fi + 4 ] = cx + hW;
    t[ fi + 5 ] = cy + hH;

    t[ fi + 6 ] = cx - hW;
    t[ fi + 7 ] = cy + hH;

    // uv coords for top-left col-row ---------------------------------------------

    const double tS = 1.0 / 16.0 ;

    t = sb->UV; // cache table

    if ( !flipX )
    {
        t[ fi + 0 ] = tS * ( col + 0 );
        t[ fi + 2 ] = tS * ( col + nCol );
        t[ fi + 4 ] = tS * ( col + nCol );
        t[ fi + 6 ] = tS * ( col + 0 );
    }
    else
    {
        t[ fi + 2 ] = tS * ( col + 0 );
        t[ fi + 0 ] = tS * ( col + nCol );
        t[ fi + 6 ] = tS * ( col + nCol );
        t[ fi + 4 ] = tS * ( col + 0 );
    }

    if (!flipY)
    {
        t[ fi + 1 ] = tS * ( row + nRow );
        t[ fi + 3 ] = tS * ( row + nRow );
        t[ fi + 5 ] = tS * ( row + 0 );
        t[ fi + 7 ] = tS * ( row + 0 );
    }
    else
    {
        t[ fi + 5 ] = tS * ( row + nRow );
        t[ fi + 7 ] = tS * ( row + nRow );
        t[ fi + 1 ] = tS * ( row + 0 );
        t[ fi + 3 ] = tS * ( row + 0 );
    }

    // set palette y in info table

    sb->PX[ indexSprite ] = paletteY * 16;

    // next sprite
    CUR_SPRITE_OF_BATCH[ indexBatch ]++;
}

// update TileMap

void PPU::SetScanline( unsigned char indexTilemap, unsigned short indexScanline, unsigned char offsetX, unsigned char offsetY )
{
    TileMap * tm = TILEMAPS + indexTilemap;
    int slR = ( indexScanline & ( NUM_SCANLINES - 1 ) ) * 4;
    tm->scanlines[ slR + 0 ] = offsetX; // red
    tm->scanlines[ slR + 1 ] = offsetY; // greeen

    tm->updateScanlines = true;
}

void PPU::SetTile( unsigned char indexTilemap, unsigned char mapCol, unsigned char mapRow, unsigned char sheetCol, unsigned char sheetRow, unsigned char paletteY, bool flipX )
{
    TileMap * m = TILEMAPS + indexTilemap;

    unsigned char colOffset;
    if ( !flipX )
    {
        colOffset = ( ( sheetCol-mapCol ) & 15 ) * 16 ;
    }
    else
    {
        colOffset = ( ( sheetCol-( m->numCol -1 -mapCol ) ) & 15 ) * 16 ;
    }

    unsigned char rowOffset = ( (sheetRow-mapRow)&15 ) * 16 ;

    unsigned short iTileR = ( (mapRow&( m->numRow - 1 ) ) * m->numCol + ( mapCol&( m->numCol - 1 ) ) ) * 4;

    m->tiles[ iTileR + 0 ] = colOffset;    // red
    m->tiles[ iTileR + 1 ] = rowOffset;    // green
    m->tiles[ iTileR + 2 ] = flipX*255;    // blue
    m->tiles[ iTileR + 3 ] = paletteY*16;  // alpha

    m->updateMap = true;
}

void PPU::Scroll( unsigned char indexTilemap, short scrollX, short scrollY )
{
    TileMap * m = RGB::GetTilemapsAddr() + indexTilemap;

    m->x = scrollX;
    m->y = scrollY;
}
