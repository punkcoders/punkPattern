#ifndef DEVICEMANAGER_H
#define DEVICEMANAGER_H

#include "..\PunkMain.h"
#include "Heart.h"

// INTERFACE TO USE DEVICES BUFFERS AND EVENTS
// you're not supposed to change anything in this class

class DeviceManager
{
    public:
        // open close
        static void Init();
        static void ShutDown();

        // video
        static unsigned long*GetScreenAddress();
        static void VideoRoutine();
        static void SetVideoRoutine(void(*callback)(void));

        //Audio
        static float* GetLeftBufferAddress();
        static float* GetRightBufferAddress();
        static float GetSampleRate();
        static void AudioRoutine();
        static void SetAudioRoutine(void(*callback)(void));

        //Files
        static void* GetFileBufferAddress();
        static void LoadFile(const char* fileName);
        static void SetFileLoadedEvent(void(*callback)(void));
        static void OnFileLoaded();
        static void SetFileErrorEvent(void(*callback)(void));
        static void OnFileError();

        //Controls
        static char GetLastKeyChanged();
        static void OnKeyDown();
        static void SetKeyDownEvent(void(*callback)(void));
        static void OnKeyUp();
        static void SetKeyUpEvent(void(*callback)(void));
        static long GetMouseX();
        static long GetMouseY();
        static void OnMouseDown();
        static void SetMouseDownEvent(void(*callback)(void));
        static void OnMouseUp();
        static void SetMouseUpEvent(void(*callback)(void));

    private:
        static void* CALLBACK_OBJECT;
        // video
        static void (*VIDEOROUTINE_EVENT)(void);
        // audio
        static void (*AUDIOROUTINE_EVENT)(void);
        // files
        static void (*FILEERROR_EVENT)(void);
        static void (*FILELOADED_EVENT)(void);
        //Controls
        static void (*KEYDOWN_EVENT)(void);
        static void (*KEYUP_EVENT)(void);
        static void (*MOUSEDOWN_EVENT)(void);
        static void (*MOUSEUP_EVENT)(void);

};

#endif // DEVICEMANAGER_H
