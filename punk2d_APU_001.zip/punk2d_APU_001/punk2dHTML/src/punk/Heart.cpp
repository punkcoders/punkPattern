#include "Heart.h"

// video buffer
unsigned long Heart::SCREEN[PunkMain::SCREEN_WIDTH*PunkMain::SCREEN_HEIGHT];
// audio buffers
float Heart::LEFT[PunkMain::SAMPLES_BY_AUDIOBUFFER];
float Heart::RIGHT[PunkMain::SAMPLES_BY_AUDIOBUFFER];
long Heart::SAMPLE_RATE = 48000; // must be modified with GetSampleRateAddress()
// file buffers
char Heart::FILE_BUFFER[PunkMain::MAX_FILE_SIZE];
char Heart::FILE_NAME[256];
// controls buffers
char Heart::LAST_KEY;
long Heart::MOUSE_X = 0,Heart::MOUSE_Y = 0;

// EVENTS-----------------------------------------------------------
void Heart::Init(){DeviceManager::Init();}
void Heart::ShutDown(){DeviceManager::ShutDown();}

// graphics ---------------------------------------------------------
unsigned long * Heart::GetScreenAddress() {return SCREEN;}
int Heart::GetScreenWidth() {return PunkMain::SCREEN_WIDTH;}
int Heart::GetScreenHeight() {return PunkMain::SCREEN_HEIGHT;}
int Heart::GetTextureWidth() {return PunkMain::TEXTURE_WIDTH;}
int Heart::GetTextureHeight() {return PunkMain::TEXTURE_HEIGHT;}
void Heart::VideoRoutine() {DeviceManager::VideoRoutine();}

// audio ------------------------------------------------------------
int Heart::GetNumSamplesByBuffer() {return PunkMain::SAMPLES_BY_AUDIOBUFFER;}
long * Heart::GetSampleRateAddress() {return &SAMPLE_RATE;} // Address to set samplerate
long Heart::GetSampleRate() {return SAMPLE_RATE;}
float * Heart::GetLeftBufferAddress() {return LEFT;}
float * Heart::GetRightBufferAddress() {return RIGHT;}
void Heart::AudioRoutine() {DeviceManager::AudioRoutine();}

// files ------------------------------------------------------------
char* Heart::GetFileNameAddress() {return FILE_NAME;}
char* Heart::GetFileBufferAddress() {return FILE_BUFFER;}
int Heart::GetMaxFileSize() {return PunkMain::MAX_FILE_SIZE;}
void Heart::OnLoadError() {DeviceManager::OnFileError();}
void Heart::OnLoaded(){DeviceManager::OnFileLoaded();}

// controls ----------------------------------------------------------
char* Heart::GetLastKeyPressedAddress(){return &LAST_KEY;}
void Heart::OnKeyDown(){DeviceManager::OnKeyDown();}
void Heart::OnKeyUp(){DeviceManager::OnKeyUp();}
long* Heart::GetMouseXAddress(){return &MOUSE_X;}
long* Heart::GetMouseYAddress(){return &MOUSE_Y;}
void Heart::OnMouseDown(){DeviceManager::OnMouseDown();}
void Heart::OnMouseUp(){DeviceManager::OnMouseUp();}
