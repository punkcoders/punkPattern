#include "DeviceManager.h"
#include <iostream>
using namespace std;

// init callbacks to invalid
void* DeviceManager::CALLBACK_OBJECT = NULL;
void (*DeviceManager::VIDEOROUTINE_EVENT)(void) = NULL;
void (*DeviceManager::AUDIOROUTINE_EVENT)(void) = NULL;
void (*DeviceManager::FILEERROR_EVENT)(void) = NULL;
void (*DeviceManager::FILELOADED_EVENT)(void) = NULL;
void (*DeviceManager::KEYDOWN_EVENT)(void) = NULL;
void (*DeviceManager::KEYUP_EVENT)(void) = NULL;
void (*DeviceManager::MOUSEDOWN_EVENT)(void) = NULL;
void (*DeviceManager::MOUSEUP_EVENT)(void) = NULL;

// init / shut
void DeviceManager::Init()
{
    PunkMain::Main();
}
void DeviceManager::ShutDown()
{
    PunkMain::Exit();
}

// video
unsigned long* DeviceManager::GetScreenAddress(){return Heart::GetScreenAddress();}
void DeviceManager::VideoRoutine(){ if (VIDEOROUTINE_EVENT) VIDEOROUTINE_EVENT();}
void DeviceManager::SetVideoRoutine(void(*callback)(void)){VIDEOROUTINE_EVENT = callback;}

// audio
float* DeviceManager::GetLeftBufferAddress(){return Heart::GetLeftBufferAddress();}
float* DeviceManager::GetRightBufferAddress(){return Heart::GetRightBufferAddress();}
float DeviceManager::GetSampleRate(){return Heart::GetSampleRate();}
void DeviceManager::AudioRoutine(){ if (AUDIOROUTINE_EVENT) AUDIOROUTINE_EVENT();}
void DeviceManager::SetAudioRoutine(void(*callback)(void)){AUDIOROUTINE_EVENT=callback;}

// files
void* DeviceManager::GetFileBufferAddress(){return Heart::GetFileBufferAddress();}
void DeviceManager::LoadFile(const char* fileName){ // replace by memset & memcpy
    char* fnBuf = Heart::GetFileNameAddress();
    for (int i = 0; i<256; i++)
    {
        if (fileName[i]) fnBuf[i] = fileName[i];
        else fnBuf[i] = 0;
    }
}
void DeviceManager::SetFileErrorEvent(void(*callback)(void)) {FILEERROR_EVENT = callback;}
void DeviceManager::OnFileError() { if(FILEERROR_EVENT) FILEERROR_EVENT();}
void DeviceManager::SetFileLoadedEvent(void(*callback)(void)){FILELOADED_EVENT = callback;}
void DeviceManager::OnFileLoaded(){ if (FILELOADED_EVENT) FILELOADED_EVENT();}

// controls
char DeviceManager::GetLastKeyChanged(){ return *Heart::GetLastKeyPressedAddress(); }
void DeviceManager::OnKeyDown(){ if (KEYDOWN_EVENT) KEYDOWN_EVENT();}
void DeviceManager::SetKeyDownEvent(void(*callback)(void)){KEYDOWN_EVENT = callback;}
void DeviceManager::OnKeyUp(){ if (KEYUP_EVENT) KEYUP_EVENT();}
void DeviceManager::SetKeyUpEvent(void(*callback)(void)){KEYUP_EVENT = callback;}

long DeviceManager::GetMouseX(){ long* ptr = Heart::GetMouseXAddress();  return *ptr; }
long DeviceManager::GetMouseY(){ long* ptr = Heart::GetMouseYAddress();  return *ptr; }
void DeviceManager::OnMouseDown(){ if (MOUSEDOWN_EVENT) MOUSEDOWN_EVENT(); }
void DeviceManager::SetMouseDownEvent(void(*callback)(void)) { MOUSEDOWN_EVENT = callback; }
void DeviceManager::OnMouseUp(){ if (MOUSEUP_EVENT) MOUSEUP_EVENT(); }
void DeviceManager::SetMouseUpEvent(void(*callback)(void)) { MOUSEUP_EVENT = callback; }

