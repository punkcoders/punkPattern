#include "RGB.h"

#include <string.h>
#include <iostream>
using namespace std;

// DEFINE ALL GRAPHIC ENGINE CONSTANTS HERE

const int RGB::SCREEN_WIDTH = 480, RGB::SCREEN_HEIGHT = 320;

unsigned char RGB::T_PALETTE[ 16 * 16 * 4 ];

const unsigned short RGB::TILESHEET_SIZE = 256;
const unsigned char RGB::NUM_TEXTURES = 4;
SheetTexture RGB::TEXTURES[RGB::NUM_TEXTURES];

const unsigned char RGB::NUM_TARGET_SHEETS = 6;
unsigned char RGB::NUM_SHEET_DRAWS;
const unsigned short RGB::MAX_TARGET_DRAWS = 256; // buffer of drawing instructions size
SheetDraw RGB::SHEET_DRAWS[RGB::MAX_TARGET_DRAWS];

const unsigned char RGB::NUM_SPRITES_BATCHES = 4;
unsigned char RGB::SPRITES_PER_BATCH[RGB::NUM_SPRITES_BATCHES] = {32,64,64,32};
SpriteBatch RGB::SPRITES_BATCHES[RGB::NUM_SPRITES_BATCHES];

const unsigned char RGB::NUM_TILE_MAPS = 2;
TileMap RGB::TILE_MAPS[RGB::NUM_TILE_MAPS];


// GETTERS

unsigned short RGB::GetScreenWidth()
{
    return SCREEN_WIDTH;
}
unsigned short RGB::GetScreenHeight()
{
    return SCREEN_HEIGHT;
}

unsigned char * RGB::GetPaletteAddress()
{
    return T_PALETTE;
}

unsigned short RGB::GetSheetResolution()
{
    return (unsigned short)TILESHEET_SIZE;
}
unsigned char  RGB::GetNumTextures()
{
    return (unsigned char)NUM_TEXTURES;
}
SheetTexture * RGB::GetSheetTexturesAddr()
{
    return TEXTURES;
}


unsigned char RGB::GetNumTargetSheets()
{
    return (unsigned char)NUM_TARGET_SHEETS;
}
unsigned short RGB::GetMaxSheetDraws()
{
    return (unsigned short)MAX_TARGET_DRAWS;
}
unsigned char * RGB::GetNumSheetDrawsAddr()
{
    return &NUM_SHEET_DRAWS;
}
SheetDraw * RGB::GetSheetDrawInfoAddr()
{
    return SHEET_DRAWS;
}

unsigned char RGB::GetNumSpritesBatches()
{
    return NUM_SPRITES_BATCHES;
}
SpriteBatch * RGB::GetSpritesBatchesAddr()
{
    return SPRITES_BATCHES;
}

unsigned char RGB::GetNumTilemaps()
{
    return NUM_TILE_MAPS;
}
TileMap * RGB::GetTilemapsAddr()
{
    return TILE_MAPS;
}


// INIT

void RGB::InitPointers()
{
    cout << "RENDER GRAPHICS BUFFER INIT POINTERS" << endl;

    memset( T_PALETTE, 0, 16 * 16 * 4 );

    for ( int i=0; i < NUM_TEXTURES; i++ )
    {
        SheetTexture * st = TEXTURES + i;
        st->update = false;
        st->pixels = new unsigned char[ TILESHEET_SIZE * TILESHEET_SIZE ]; // 8-bit alpha pixels
    }

    for ( int i=0; i < NUM_SPRITES_BATCHES; i++ )
    {
        SpriteBatch * sb = SPRITES_BATCHES + i;

        unsigned char ns = 1;
        while( ns < SPRITES_PER_BATCH[i] )
        {
            ns <<= 1;   // power 2 control
        }
        SPRITES_PER_BATCH[i] = ns;
        cout << "BATCH " << i << " has " << (int)ns << " sprites" << endl;

        sb->numSprites = ns;
        sb->XY = new float[ ns * 8 ];
        sb->UV = new float[ ns * 8 ];
        sb->PX = new unsigned char[ ns ];
    }

    cout << "TileMap struct size: " << sizeof(TileMap) << " bytes" << endl;

    for ( int i=0; i < NUM_TILE_MAPS ; i++ )
    {
        TileMap * tm = TILE_MAPS + i;
        tm->numCol = 32; // for the moment all maps are 32 x 32
        tm->numRow = 32;
        tm->x = 0;
        tm->y = 0;
        tm->updateMap = true;
        tm->updateScanlines = true;
        tm->tiles = new unsigned char[ tm->numCol * tm->numRow * 4 ]; // all tilemaps are 32 x 32 cell, 512 x 512 px
        memset(tm->tiles, 0, tm->numCol * tm->numRow * 4);
        tm->scanlines = new unsigned char[ TILESHEET_SIZE/16 * tm->numRow * 4 ]; // RGBA but only RG used for displacement mapping
        memset(tm->scanlines, 0, TILESHEET_SIZE/16 * tm->numRow * 4);
        const unsigned char * bytes = (unsigned char *)tm;
        cout << "bytes: ";
        for ( int j=0; j < 16; j++ )
        {
            cout << (int)bytes[j] << ",";
        }
        cout << endl;
    }

}

// destructor

void RGB::ClearRAM()
{
    cout << "CLEARING RGB RAM" << endl;

    for ( int i=0; i < NUM_TILE_MAPS; i++ )
    {
        TileMap * tm = TILE_MAPS + i;
        delete [] tm->tiles;
        delete [] tm->scanlines;
    }

    for ( int i=0; i < NUM_SPRITES_BATCHES; i++ )
    {
        SpriteBatch * sb = SPRITES_BATCHES + i;
        delete [] sb->XY;
        delete [] sb->UV;
        delete [] sb->PX;
    }

    for ( int i=0; i < NUM_TEXTURES; i++ )
    {
        SheetTexture * st = TEXTURES + i;
        delete [] st->pixels;
    }
}
