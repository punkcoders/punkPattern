#include "ROOT_Heart.h"

#include <iostream>
using namespace std;

// BOOLEAN FOR SMARTPHONE DETECTION
bool ROOT_Heart::SMARTPHONE = false;

// audio buffers
float ROOT_Heart::LEFT[ROOT_EntryPoint::SAMPLES_BY_AUDIOBUFFER];
float ROOT_Heart::RIGHT[ROOT_EntryPoint::SAMPLES_BY_AUDIOBUFFER];
long ROOT_Heart::SAMPLE_RATE = 48000; // must be modified with GetSampleRateAddress()

// file buffers
char ROOT_Heart::FILE_BUFFER[ROOT_EntryPoint::MAX_FILE_SIZE];
char ROOT_Heart::FILE_NAME[256];

// controls buffers
char ROOT_Heart::LAST_KEY;
long ROOT_Heart::MOUSE_X = 0,ROOT_Heart::MOUSE_Y = 0;

// EVENTS-----------------------------------------------------------
void ROOT_Heart::Init(){ROOT_DeviceManager::Init();}
bool ROOT_Heart::Exit(){return ROOT_DeviceManager::GetExit();}
void ROOT_Heart::ShutDown(){ROOT_DeviceManager::ShutDown();}

// graphics ---------------------------------------------------------
int ROOT_Heart::GetScreenWidth() {return RGB::GetScreenWidth();}
int ROOT_Heart::GetScreenHeight() {return RGB::GetScreenHeight();}
void ROOT_Heart::VideoRoutine() {ROOT_DeviceManager::VideoRoutine();}

// audio ------------------------------------------------------------
int ROOT_Heart::GetNumSamplesByBuffer() {return ROOT_EntryPoint::SAMPLES_BY_AUDIOBUFFER;}
long * ROOT_Heart::GetSampleRateAddress() {return &SAMPLE_RATE;} // Address to set samplerate
long ROOT_Heart::GetSampleRate() {return SAMPLE_RATE;}
float * ROOT_Heart::GetLeftBufferAddress() {return LEFT;}
float * ROOT_Heart::GetRightBufferAddress() {return RIGHT;}
void ROOT_Heart::AudioRoutine() {ROOT_DeviceManager::AudioRoutine();}

// files ------------------------------------------------------------
char* ROOT_Heart::GetFileNameAddress() {return FILE_NAME;}
char* ROOT_Heart::GetFileBufferAddress() {return FILE_BUFFER;}
int ROOT_Heart::GetMaxFileSize() {return ROOT_EntryPoint::MAX_FILE_SIZE;}
void ROOT_Heart::OnLoadError() {ROOT_DeviceManager::OnFileError();}
void ROOT_Heart::OnLoaded(){ROOT_DeviceManager::OnFileLoaded();}

// controls ----------------------------------------------------------
char* ROOT_Heart::GetLastKeyPressedAddress(){return &LAST_KEY;}
void ROOT_Heart::OnKeyDown(){ROOT_DeviceManager::OnKeyDown();}
void ROOT_Heart::OnKeyUp(){ROOT_DeviceManager::OnKeyUp();}
long* ROOT_Heart::GetMouseXAddress(){return &MOUSE_X;}
long* ROOT_Heart::GetMouseYAddress(){return &MOUSE_Y;}
void ROOT_Heart::OnMouseDown(){ROOT_DeviceManager::OnMouseDown();}
void ROOT_Heart::OnMouseUp(){ROOT_DeviceManager::OnMouseUp();}
