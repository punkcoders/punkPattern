/*
 Code under P.U.N.K. license: Poor Useless Newbie Kidcoding
 so you're free to do what you want with it
 http://punkcoders.free.fr
 pukcoders@gmail.com
 */
"use strict";

function GL_Tilemap(numCol, numRow, tiles, scanlines)
{
    this.build(numCol, numRow, tiles, scanlines);
}

// -------------------------------------------------------------------------
// STATIC SPACE ------------------------------------------------------------
// -------------------------------------------------------------------------

GL_Tilemap.INIT = false;
GL_Tilemap.NUM_INSTANCES = 0;

// shaders and locations

GL_Tilemap.VERTEX_SHADER = `

    attribute highp vec4 aVertexXY;
    attribute highp vec2 aVertexUVmap;

    varying highp vec2 UVmap;

    void main()
    {
        UVmap = aVertexUVmap;
        gl_Position =  aVertexXY;
    }

`;

GL_Tilemap.FRAGMENT_SHADER = `

    varying highp vec2 UVmap;

    uniform sampler2D uScanlineTexture;
    uniform sampler2D uMapTexture;
    uniform sampler2D uSheetTexture;
    uniform sampler2D uPaletteTexture;
    uniform highp vec2 UVratio;

    highp vec2 INVratio = vec2(1.0,1.0) / UVratio;
    highp vec4 scanline, tile; 
    highp vec2 UV, UVsheet, UVtile;
    highp float palX, palY;
    const highp float a=255.0/256.0 , b=1.0/32.0, _1=1.0, _2=2.0;

    void main()
    {
        scanline = texture2D( uScanlineTexture, UVmap );
        UV = UVmap + a*vec2( scanline.r, scanline.g ) * INVratio;

        tile = texture2D( uMapTexture, UV );

        UVsheet = UVratio * vec2( (_1-tile.b*_2)*UV.x , UV.y );
        UVtile = a*vec2( tile.r, tile.g );

        palX = a*texture2D( uSheetTexture, UVsheet+UVtile ).a+b;
        palY = a*tile.a+b;
        gl_FragColor = texture2D(uPaletteTexture,vec2(palX,palY));
    }

`;

GL_Tilemap.VERTEX_SHADER_ID = 0, GL_Tilemap.FRAGMENT_SHADER_ID = 0, GL_Tilemap.SHADER_PROGRAM_ID = 0;

GL_Tilemap.XY_ATTRIB_LOCATION = 0;
GL_Tilemap.UV_MAP_ATTRIB_LOCATION = 0;
GL_Tilemap.UV_RATIO_UNIFORM_LOCATION = 0;
GL_Tilemap.SCANLINES_TEXTURE_UNIFORM_LOCATION = 0;
GL_Tilemap.MAP_TEXTURE_UNIFORM_LOCATION = 0;
GL_Tilemap.SHEET_TEXTURE_UNIFORM_LOCATION = 0;
GL_Tilemap.PALETTE_TEXTURE_UNIFORM_LOCATION = 0;


// XY & IDS vertex buffers

GL_Tilemap.XY = new Float32Array([-1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0]);
GL_Tilemap.XY_BUFFER = null;

GL_Tilemap.IDS = new Uint16Array([0, 1, 2, 2, 3, 0]);
GL_Tilemap.IDS_BUFFER = null;


// init / shutdown

GL_Tilemap.Init = function ()
{
    const GL = GL_Entry.GL;

    // CREATE SHADER ------------------------------------------------------------

    const result = GL_Entry.MakeShader(GL_Tilemap, GL_Tilemap.VERTEX_SHADER, GL_Tilemap.FRAGMENT_SHADER, "GL_Tilemap");
    if (!result)
    {
        console.log("GL_Tilemap CANNOT COMPILE SHADER");
        return false;
    }

    // get locations

    GL_Tilemap.XY_ATTRIB_LOCATION = GL.getAttribLocation(GL_Tilemap.SHADER_PROGRAM_ID, "aVertexXY");
    GL_Tilemap.UV_MAP_ATTRIB_LOCATION = GL.getAttribLocation(GL_Tilemap.SHADER_PROGRAM_ID, "aVertexUVmap");

    GL_Tilemap.UV_RATIO_UNIFORM_LOCATION = GL.getUniformLocation(GL_Tilemap.SHADER_PROGRAM_ID, "UVratio");

    GL_Tilemap.SCANLINES_TEXTURE_UNIFORM_LOCATION = GL.getUniformLocation(GL_Tilemap.SHADER_PROGRAM_ID, "uScanlineTexture");
    GL_Tilemap.MAP_TEXTURE_UNIFORM_LOCATION = GL.getUniformLocation(GL_Tilemap.SHADER_PROGRAM_ID, "uMapTexture");
    GL_Tilemap.SHEET_TEXTURE_UNIFORM_LOCATION = GL.getUniformLocation(GL_Tilemap.SHADER_PROGRAM_ID, "uSheetTexture");
    GL_Tilemap.PALETTE_TEXTURE_UNIFORM_LOCATION = GL.getUniformLocation(GL_Tilemap.SHADER_PROGRAM_ID, "uPaletteTexture");

    console.log("GL_Tilemap UV ratio unif loc: " + GL_Tilemap.UV_RATIO_UNIFORM_LOCATION);

    console.log("GL_Tilemap Scanlines Tex unif loc: " + GL_Tilemap.SCANLINES_TEXTURE_UNIFORM_LOCATION);
    console.log("GL_Tilemap Map Tex unif loc: " + GL_Tilemap.MAP_TEXTURE_UNIFORM_LOCATION);
    console.log("GL_Tilemap Sheet Tex unif loc: " + GL_Tilemap.SHEET_TEXTURE_UNIFORM_LOCATION);
    console.log("GL_Tilemap Palette Tex unif loc: " + GL_Tilemap.PALETTE_TEXTURE_UNIFORM_LOCATION);

    console.log("GL_Tilemap XY attr loc: " + GL_Tilemap.XY_ATTRIB_LOCATION);
    console.log("GL_Tilemap mapUV attr loc:" + GL_Tilemap.UV_MAP_ATTRIB_LOCATION);


    // create vertices xy & indexes (uv is in instance)

    GL_Tilemap.XY_BUFFER = GL.createBuffer();
    GL.bindBuffer(GL.ARRAY_BUFFER, GL_Tilemap.XY_BUFFER);
    GL.bufferData(GL.ARRAY_BUFFER, GL_Tilemap.XY, GL.STATIC_DRAW);

    GL_Tilemap.IDS_BUFFER = GL.createBuffer();
    GL.bindBuffer(GL.ELEMENT_ARRAY_BUFFER, GL_Tilemap.IDS_BUFFER);
    GL.bufferData(GL.ELEMENT_ARRAY_BUFFER, GL_Tilemap.IDS, GL.STATIC_DRAW);


    // if not return error
    GL_Tilemap.INIT = true;

    return true;
};

GL_Tilemap.ShutDown = function ()
{
    const GL = GL_Entry.GL;

    // delete vertex buffers

    GL.deleteBuffer(GL_Tilemap.IDS_BUFFER);
    GL.deleteBuffer(GL_Tilemap.XY_BUFFER);

    console.log("GL_Tilemap vertices deleted");

    // delete the shaders

    GL.detachShader(GL_Tilemap.SHADER_PROGRAM_ID, GL_Tilemap.VERTEX_SHADER_ID);
    GL.detachShader(GL_Tilemap.SHADER_PROGRAM_ID, GL_Tilemap.FRAGMENT_SHADER_ID);
    GL.deleteShader(GL_Tilemap.VERTEX_SHADER_ID);
    GL.deleteShader(GL_Tilemap.FRAGMENT_SHADER_ID);

    console.log("GL_Tilemap shader deleted");
};

// --------------------------------------------------------------------
// INSTANCE SPACE -----------------------------------------------------
// --------------------------------------------------------------------

// build / delete

GL_Tilemap.prototype.build = function (numCol, numRow, tiles, scanlines)
{
    console.log("   GL_Tilemap instance build"); // remove

    if (!GL_Tilemap.INIT)
    {
        console.log("   GL_Tilemap not INIT, cannot instance !");
        return;
    }

    const GL = GL_Entry.GL;

    // instance index

    this.m_instanceIndex = GL_Tilemap.NUM_INSTANCES;
    GL_Tilemap.NUM_INSTANCES++;

    // round map dimensions to power 2

    this.m_numCol = 1;
    while (this.m_numCol < numCol)
    {
        this.m_numCol <<= 1;
    }
    this.m_numRow = 1;
    while (this.m_numRow < numRow)
    {
        this.m_numRow <<= 1;
    }

    // xy dimensions

    this.m_mapHW = GL_Entry.GetTileSheetSize() * GL_Entry.GetScaleWidth() / 16.0 * this.m_numCol; // pixel-perfect
    this.m_mapHH = GL_Entry.GetTileSheetSize() * GL_Entry.GetScaleHeight() / 16.0 * this.m_numRow;

    // create uv buffer

    this.m_uvMap = new Float32Array([0, 2, 2, 2, 2, 0, 0, 0]);
    this.m_uvMapBuffer = GL.createBuffer();
    GL.bindBuffer(GL.ARRAY_BUFFER, this.m_uvMapBuffer);
    GL.bufferData(GL.ARRAY_BUFFER, this.m_uvMap, GL.STATIC_DRAW);

    // create scanlines texture

    this.m_numScanlines = GL_Entry.GetTileSheetSize() * this.m_numRow / 16;
    this.m_scanlines = scanlines;

    this.m_scanlinesTexture = GL.createTexture();
    GL.bindTexture(GL.TEXTURE_2D, this.m_scanlinesTexture);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_MAG_FILTER, GL.LINEAR);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_MIN_FILTER, GL.LINEAR);

    // create tilemap texture

    this.m_map = tiles;

    this.m_mapTexture = GL.createTexture();
    GL.bindTexture(GL.TEXTURE_2D, this.m_mapTexture);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_MAG_FILTER, GL.NEAREST);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_MIN_FILTER, GL.NEAREST);

    console.log("   GL_Tilemap instance " + this.m_instanceIndex + " " + this.m_numCol + " x " + this.m_numRow + " tiles");
};

GL_Tilemap.prototype.delete = function ()
{
    console.log("   GL_Tilemap instance delete"); // remove

    const GL = GL_Entry.GL;

    // delete textures

    GL.deleteTexture(this.m_mapTexture);
    this.m_map = null;

    GL.deleteTexture(this.m_scanlinesTexture);
    this.m_scanlines = null;

    // delete UV buffer

    GL.deleteBuffer(this.m_uvMapBuffer);
    this.m_uvMap = null;

    console.log("   GL_Tilemap instance " + this.m_instanceIndex + " deleted.");
};


// update tilemap array

GL_Tilemap.prototype.SetTile = function (mapCol, mapRow, sheetCol, sheetRow, paletteY, flipX)
{
    let colOffset;
    if (!flipX)
    {
        colOffset = ((sheetCol - mapCol) & 15) * 16;
    } else
    {
        colOffset = ((sheetCol - (this.m_numCol - 1 - mapCol)) & 15) * 16;
    }

    let rowOffset = ((sheetRow - mapRow) & 15) * 16;

    const iTileR = ((mapRow & (this.m_numRow - 1)) * this.m_numCol + (mapCol & (this.m_numCol - 1))) * 4;

    this.m_map[ iTileR + 0 ] = colOffset;    // red
    this.m_map[ iTileR + 1 ] = rowOffset;    // green
    this.m_map[ iTileR + 2 ] = flipX * 255;    // blue
    this.m_map[ iTileR + 3 ] = paletteY * 16;  // alpha
};

// routines stream/draw

GL_Tilemap.prototype.Stream = function (tilemap, scanlines)
{
    const GL = GL_Entry.GL;

    // stream scanlines texture
    if (scanlines)
    {
        GL.bindTexture(GL.TEXTURE_2D, this.m_scanlinesTexture);
        GL.texImage2D(GL.TEXTURE_2D, 0, GL.RGBA, 1, this.m_numScanlines, 0, GL.RGBA, GL.UNSIGNED_BYTE, this.m_scanlines );
    }

    // stream tilemap texture
    if (tilemap)
    {
        GL.bindTexture(GL.TEXTURE_2D, this.m_mapTexture);
        GL.texImage2D(GL.TEXTURE_2D, 0, GL.RGBA, this.m_numCol, this.m_numRow, 0, GL.RGBA, GL.UNSIGNED_BYTE, this.m_map );
    }
    
};

GL_Tilemap.prototype.Draw = function (texture, x, y, blend)
{
    const GL = GL_Entry.GL;

    // CPU->GPU STREAM PHASE ---------------------------------------------------

    // stream XY, center coordinates and half width & heigh
    {
        // with and height of tilemap in pixels
        const tileSize = GL_Entry.GetTileSheetSize() / 16;
        const mapW = tileSize * this.m_numCol;
        const mapH = tileSize * this.m_numRow;

        // center x,y
        x = ((x + mapW / 2) & (mapW - 1)) - mapW / 2;
        y = ((y + mapH / 2) & (mapH - 1)) - mapH / 2;

        const cx = x * GL_Entry.GetScaleWidth();
        const cy = y * GL_Entry.GetScaleHeight();

        // cache half width and height
        const hW = this.m_mapHW, hH = this.m_mapHH;

        // cache vertex table
        const t = GL_Tilemap.XY;

        t[ 0 ] = cx - hW;
        t[ 1 ] = cy - hH;

        t[ 2 ] = cx + hW;
        t[ 3 ] = cy - hH;

        t[ 4 ] = cx + hW;
        t[ 5 ] = cy + hH;

        t[ 6 ] = cx - hW;
        t[ 7 ] = cy + hH;
    }
    GL.bindBuffer(GL.ARRAY_BUFFER, GL_Tilemap.XY_BUFFER);
    GL.bufferData(GL.ARRAY_BUFFER, GL_Tilemap.XY, GL.DYNAMIC_DRAW);

    // DRAW PHASE --------------------------------------------------------------

    // draw in main target buffer

    GL.bindFramebuffer(GL.FRAMEBUFFER, GL_Entry.GetMainTargetBuffer());
    GL.viewport(0, 0, GL_Entry.GetMainTargetWidth(), GL_Entry.GetMainTargetHeight());

    // blend or not

    if (blend)
    {
        GL.enable(GL.BLEND);
        GL.blendFunc(GL.SRC_ALPHA, GL.ONE_MINUS_SRC_ALPHA);
    } else
    {
        GL.disable(GL.BLEND);
    }

    // select shader

    GL.useProgram(GL_Tilemap.SHADER_PROGRAM_ID);

    // select vertbuffers

    GL.bindBuffer(GL.ARRAY_BUFFER, GL_Tilemap.XY_BUFFER);
    GL.vertexAttribPointer(GL_Tilemap.XY_ATTRIB_LOCATION, 2, GL.FLOAT, GL.FALSE, 0, 0);
    GL.enableVertexAttribArray(GL_Tilemap.XY_ATTRIB_LOCATION);

    GL.bindBuffer(GL.ARRAY_BUFFER, this.m_uvMapBuffer);
    GL.vertexAttribPointer(GL_Tilemap.UV_MAP_ATTRIB_LOCATION, 2, GL.FLOAT, GL.FALSE, 0, 0);
    GL.enableVertexAttribArray(GL_Tilemap.UV_MAP_ATTRIB_LOCATION);

    GL.bindBuffer(GL.ELEMENT_ARRAY_BUFFER, GL_Tilemap.IDS_BUFFER);

    // select textures

    GL.activeTexture(GL.TEXTURE0);
    GL.uniform1i(GL_Tilemap.SCANLINES_TEXTURE_UNIFORM_LOCATION, 0);
    GL.bindTexture(GL.TEXTURE_2D, this.m_scanlinesTexture);

    GL.activeTexture(GL.TEXTURE1);
    GL.uniform1i(GL_Tilemap.MAP_TEXTURE_UNIFORM_LOCATION, 1);
    GL.bindTexture(GL.TEXTURE_2D, this.m_mapTexture);

    GL.activeTexture(GL.TEXTURE2);
    GL.uniform1i(GL_Tilemap.SHEET_TEXTURE_UNIFORM_LOCATION, 2);
    GL.bindTexture(GL.TEXTURE_2D, texture);

    GL.activeTexture(GL.TEXTURE3);
    GL.uniform1i(GL_Tilemap.PALETTE_TEXTURE_UNIFORM_LOCATION, 3);
    GL.bindTexture(GL.TEXTURE_2D, GL_Entry.GetPaletteTexture());

    // ratio UV map/texture uniform location

    GL.uniform2f(GL_Tilemap.UV_RATIO_UNIFORM_LOCATION, this.m_numCol / 16.0, this.m_numRow / 16.0);

    // draw

    GL.drawElements(GL.TRIANGLES, 6, GL.UNSIGNED_SHORT, 0);

    // free attrib arrays (not sure it's useful here)

    GL.disableVertexAttribArray(GL_Tilemap.XY_ATTRIB_LOCATION);
    GL.disableVertexAttribArray(GL_Tilemap.UV_MAP_ATTRIB_LOCATION);
};