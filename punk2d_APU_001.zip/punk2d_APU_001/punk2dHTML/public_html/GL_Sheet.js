/*
Code under P.U.N.K. license: Poor Useless Newbie Kidcoding
so you're free to do what you want with it
http://punkcoders.free.fr
pukcoders@gmail.com
*/
"use strict";

function GL_Sheet()
{
    this.build();
}

// -----------------------------------------------------------------------------
// STATIC SPACE ----------------------------------------------------------------
// -----------------------------------------------------------------------------

GL_Sheet.INIT = false;
GL_Sheet.NUM_INSTANCES = 0;

// shaders and locations

GL_Sheet.VERTEX_SHADER = `

    attribute highp vec4 aVertexXY;
    attribute highp vec2 aVertexUV;

    varying highp vec2 UV;

    void main()
    {
        UV = aVertexUV;
        gl_Position =  aVertexXY;
    }
`;

GL_Sheet.FRAGMENT_SHADER = `

    varying highp vec2 UV;

    uniform sampler2D uSheetTexture;

    void main()
    {
        gl_FragColor = texture2D( uSheetTexture, UV ).rgba;
    }
`;

GL_Sheet.VERTEX_SHADER_ID=0; GL_Sheet.FRAGMENT_SHADER_ID=0; GL_Sheet.SHADER_PROGRAM_ID=0;

GL_Sheet.XY_ATTRIB_LOCATION=0, GL_Sheet.UV_ATTRIB_LOCATION=0;
GL_Sheet.TEXTURE_UNIFORM_LOCATION=null;

// vertices

GL_Sheet.XY = new Float32Array( [  -1.0, -1.0, 1.0, -1.0,  1.0, 1.0,  -1.0, 1.0 ] );
GL_Sheet.XY_BUFFER = null;
GL_Sheet.UV = new Float32Array( [  0, 0,  1, 0,  1, 1,  0, 1 ] );
GL_Sheet.UV_BUFFER = null;
GL_Sheet.IDS = new Uint16Array( [0,1,2,2,3,0] );
GL_Sheet.IDS_BUFFER = null;

// textures

GL_Sheet.NUM_TEXTURES=0;
GL_Sheet.TEXTURES=null;

// INIT / SHUTDOWN ----------------------------------------------------

GL_Sheet.Init = function( numTextures )
{   
    if ( numTextures === 0 )
    {
        console.log( "GL_Sheet ERROR, at least one texture required !" );
        return false;
    }
    
    const GL = GL_Entry.GL;
    
    // CREATE SHADER ------------------------------------------------------------

    let result = GL_Entry.MakeShader(GL_Sheet,GL_Sheet.VERTEX_SHADER,GL_Sheet.FRAGMENT_SHADER,"GL_Sheet");
    if ( ! result )
    {
        return false;
    }
 
    // get locations

    GL_Sheet.XY_ATTRIB_LOCATION = GL.getAttribLocation( GL_Sheet.SHADER_PROGRAM_ID, "aVertexXY" );
    GL_Sheet.UV_ATTRIB_LOCATION = GL.getAttribLocation( GL_Sheet.SHADER_PROGRAM_ID, "aVertexUV" );
    GL_Sheet.TEXTURE_UNIFORM_LOCATION = GL.getUniformLocation( GL_Sheet.SHADER_PROGRAM_ID, "uSheetTexture" );

    console.log( "GL_Sheet XY attr loc: " + GL_Sheet.XY_ATTRIB_LOCATION );
    console.log( "GL_Sheet UV attr loc: " + GL_Sheet.UV_ATTRIB_LOCATION );
    console.log( "GL_Sheet Tex unif loc: " + GL_Sheet.TEXTURE_UNIFORM_LOCATION );
    
    // create the vertices
    
    GL_Sheet.XY_BUFFER = GL.createBuffer();
    GL.bindBuffer( GL.ARRAY_BUFFER, GL_Sheet.XY_BUFFER );
    GL.bufferData( GL.ARRAY_BUFFER, GL_Sheet.XY, GL.STATIC_DRAW );
    
    GL_Sheet.UV_BUFFER = GL.createBuffer();
    GL.bindBuffer( GL.ARRAY_BUFFER, GL_Sheet.UV_BUFFER );
    GL.bufferData( GL.ARRAY_BUFFER, GL_Sheet.UV, GL.STATIC_DRAW );

    GL_Sheet.IDS_BUFFER = GL.createBuffer();
    GL.bindBuffer( GL.ELEMENT_ARRAY_BUFFER, GL_Sheet.IDS_BUFFER );
    GL.bufferData( GL.ELEMENT_ARRAY_BUFFER, GL_Sheet.IDS, GL.STATIC_DRAW );

    // create the textures table

    GL_Sheet.NUM_TEXTURES = numTextures;
    console.log("NUM TEXTURES: "+ GL_Sheet.NUM_TEXTURES);
    GL_Sheet.TEXTURES = [];

    for ( let i = 0; i < GL_Sheet.NUM_TEXTURES; i++ )
    {
        const texture = GL.createTexture();
        GL.bindTexture( GL.TEXTURE_2D, texture );
        GL.texParameteri( GL.TEXTURE_2D, GL.TEXTURE_MAG_FILTER, GL.NEAREST );
        GL.texParameteri( GL.TEXTURE_2D, GL.TEXTURE_MIN_FILTER, GL.NEAREST );

        GL_Sheet.TEXTURES[i] = texture;
    }

    console.log( "GL_Sheet " + GL_Sheet.NUM_TEXTURES + " textures created" );

    // if not return error
    GL_Sheet.INIT = true;
    
    return true;
};

GL_Sheet.ShutDown = function()
{
    if ( ! GL_Sheet.INIT )
    {
        return;
    }
    
    const GL = GL_Entry.GL;
    
    // delete the textures table

    for ( let i = 0; i < GL_Sheet.NUM_TEXTURES; i++ )
    {
        const texture = GL_Sheet.TEXTURES[i];
        GL.deleteTexture( texture );
    }
    GL_Sheet.TEXTURES = null;

    console.log( "GL_Sheet " + GL_Sheet.NUM_TEXTURES + " textures deleted" );
    
    // delete the vertices

    GL.deleteBuffer( GL_Sheet.IDS_BUFFER );
    GL.deleteBuffer( GL_Sheet.UV_BUFFER );
    GL.deleteBuffer( GL_Sheet.XY_BUFFER );

    console.log( "GL_Sheet vertices deleted" );
    
    // delete the shaders

    GL.detachShader( GL_Sheet.SHADER_PROGRAM_ID, GL_Sheet.VERTEX_SHADER_ID );
    GL.detachShader( GL_Sheet.SHADER_PROGRAM_ID, GL_Sheet.FRAGMENT_SHADER_ID );
    GL.deleteShader( GL_Sheet.VERTEX_SHADER_ID );
    GL.deleteShader( GL_Sheet.FRAGMENT_SHADER_ID );

    console.log("GL_Sheet shader deleted");
    
};

// textures setter / getter

GL_Sheet.UpdateTexture = function( indexTexture, data )
{
    const GL = GL_Entry.GL;
    
    if ( indexTexture >= GL_Sheet.TEXTURES.length )
    {
        indexTexture = GL_Sheet.TEXTURES.length - 1;
    }
    
    GL.bindTexture( GL.TEXTURE_2D, GL_Sheet.TEXTURES[indexTexture] );
    GL.texImage2D( GL.TEXTURE_2D, 0, GL.ALPHA, GL_Entry.GetTileSheetSize(), GL_Entry.GetTileSheetSize(), 0, GL.ALPHA, GL.UNSIGNED_BYTE, data );

    console.log( "GL_Sheet texture " + indexTexture + " updated !" );
};

GL_Sheet.GetTexture = function( indexTexture ) // used for debugging only
{
    if ( indexTexture >= GL_Sheet.TEXTURES.length )
    {
        console.log( "GL_Sheet::GetTexture INDEX OUT OF LIMITS !" );
        return null;
    }
    return GL_Sheet.TEXTURES[indexTexture];
};

// -----------------------------------------------------------------------------
// INSTANCE SPACE --------------------------------------------------------------
// -----------------------------------------------------------------------------

// getters

GL_Sheet.prototype.GetRenderTexture = function()
{
    return this.m_targetTexture;
};

// build and delete

GL_Sheet.prototype.build = function ()
{
    if (!GL_Sheet.INIT)
    {
        console.log( "   GL_Sheet not INIT, cannot instance !" );
        return;
    }
    
    const GL = GL_Entry.GL;
    
    // instance index

    this.m_instanceIndex = GL_Sheet.NUM_INSTANCES;
    GL_Sheet.NUM_INSTANCES++;
    
    // create the renderTarget framebuffer and its texture

    this.m_targetBuffer = GL.createFramebuffer();

    this.m_targetTexture = GL.createTexture();
    GL.bindTexture( GL.TEXTURE_2D, this.m_targetTexture );
    GL.texParameteri( GL.TEXTURE_2D, GL.TEXTURE_MAG_FILTER, GL.NEAREST);
    GL.texParameteri( GL.TEXTURE_2D, GL.TEXTURE_MIN_FILTER, GL.NEAREST);
    GL.texImage2D( GL.TEXTURE_2D, 0, GL.RGBA, GL_Entry.GetTileSheetSize(), GL_Entry.GetTileSheetSize(), 0, GL.RGBA, GL.UNSIGNED_BYTE, null );

    GL.bindFramebuffer( GL.FRAMEBUFFER, this.m_targetBuffer );
    GL.framebufferTexture2D( GL.FRAMEBUFFER, GL.COLOR_ATTACHMENT0, GL.TEXTURE_2D, this.m_targetTexture, 0 );   
    if ( GL.checkFramebufferStatus( GL.FRAMEBUFFER ) !== GL.FRAMEBUFFER_COMPLETE )
    {
        console.log( "   GL_Sheet instance " + this.m_instanceIndex + " RENDERTARGET FRAMEBUFFER CONFIGURATION ERROR" );
        return;
    }
    
    console.log( "   GL_Sheet instance " + this.m_instanceIndex + " frameBuffer " + this.m_targetBuffer + " created for texture " + this.m_targetTexture );
};

GL_Sheet.prototype.delete = function ()
{  
    const GL = GL_Entry.GL;
    
    // delete texture and buffer
    
    GL.deleteTexture( this.m_targetTexture );
    GL.deleteFramebuffer( this.m_targetBuffer );
    
    console.log( "   GL_Sheet instance " + this.m_instanceIndex + " deleted." );
};

// rendering

GL_Sheet.prototype.Draw = function( indexTexture, srcCol, srcRow, dstCol, dstRow, nCol, nRow )
{
    const GL = GL_Entry.GL;
    
    if ( indexTexture >= GL_Sheet.TEXTURES.length )
    {
        indexTexture = GL_Sheet.TEXTURES.length - 1;
    }
    
    // update vertices -------------------------------------------------------

    const sz = 1.0 / 16.0, W = nCol * sz, H = nRow * sz, x = 2 * sz * dstCol + W - 1, y = 2 * sz * dstRow + H - 1;
    const XY = GL_Sheet.XY, UV = GL_Sheet.UV;

    XY[0] = x - W;
    XY[1] = y - H;

    XY[2] = x + W;
    XY[3] = y - H;

    XY[4] = x + W;
    XY[5] = y + H;

    XY[6] = x - W;
    XY[7] = y + H;

    const u = srcCol * sz, v = srcRow * sz;

    UV[0] = u + 0;
    UV[1] = v + 0;

    UV[2] = u + W;
    UV[3] = v + 0;

    UV[4] = u + W;
    UV[5] = v + H;

    UV[6] = u + 0;
    UV[7] = v + H;
    
    
    // drawcall --------------------------------------------------------------

    // bind renderTarget frame buffer

    GL.bindFramebuffer( GL.FRAMEBUFFER, this.m_targetBuffer );
    GL.viewport( 0, 0, GL_Entry.GetTileSheetSize(), GL_Entry.GetTileSheetSize() );
    
    // no blend, alpha must erase alpha

    GL.disable( GL.BLEND );
    
    // select shader program

    GL.useProgram( GL_Sheet.SHADER_PROGRAM_ID );
    
    // bind texture

    GL.activeTexture( GL.TEXTURE0 );
    GL.uniform1i( GL_Sheet.TEXTURE_UNIFORM_LOCATION, 0 );
    GL.bindTexture( GL.TEXTURE_2D, GL_Sheet.TEXTURES[indexTexture] );
    
    // bind vertices & stream

    GL.bindBuffer( GL.ARRAY_BUFFER, GL_Sheet.XY_BUFFER );
    GL.bufferData( GL.ARRAY_BUFFER, GL_Sheet.XY, GL.DYNAMIC_DRAW );
    GL.vertexAttribPointer( GL_Sheet.XY_ATTRIB_LOCATION, 2, GL.FLOAT, GL.FALSE, 0, 0 );
    GL.enableVertexAttribArray( GL_Sheet.XY_ATTRIB_LOCATION );

    GL.bindBuffer( GL.ARRAY_BUFFER, GL_Sheet.UV_BUFFER );
    GL.bufferData( GL.ARRAY_BUFFER, GL_Sheet.UV, GL.DYNAMIC_DRAW );
    GL.vertexAttribPointer( GL_Sheet.UV_ATTRIB_LOCATION, 2, GL.FLOAT, GL.FALSE, 0, 0 );
    GL.enableVertexAttribArray( GL_Sheet.UV_ATTRIB_LOCATION );

    GL.bindBuffer( GL.ELEMENT_ARRAY_BUFFER, GL_Sheet.IDS_BUFFER );
    
    // draw

    GL.drawElements( GL.TRIANGLES, 6, GL.UNSIGNED_SHORT, 0 );
    
    // free attrib arrays (not sure it's usefule here)

    GL.disableVertexAttribArray( GL_Sheet.XY_ATTRIB_LOCATION );
    GL.disableVertexAttribArray( GL_Sheet.UV_ATTRIB_LOCATION );
    
};