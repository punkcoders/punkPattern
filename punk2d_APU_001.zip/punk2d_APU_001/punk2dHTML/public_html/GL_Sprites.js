/*
Code under P.U.N.K. license: Poor Useless Newbie Kidcoding
so you're free to do what you want with it
http://punkcoders.free.fr
pukcoders@gmail.com
*/
"use strict";

function GL_Sprites( numSprites, bufXY, bufUV, bufPX )
{
    this.build( numSprites, bufXY, bufUV, bufPX );
}

// -----------------------------------------------------------------------------
// STATIC SPACE ----------------------------------------------------------------
// -----------------------------------------------------------------------------

GL_Sprites.INIT = false;
GL_Sprites.NUM_INSTANCES = 0;

// dimensions

GL_Sprites.TILE_HW=0; GL_Sprites.TILE_HH=0; // half width/height

// shaders and locations

GL_Sprites.VERTEX_SHADER = `

    attribute vec4 aVertexXY;
    attribute vec2 aVertexUV, aVertexUVinfo;

    varying highp vec2 UV, UVinfo;

    void main()
    {
        UV = aVertexUV;
        UVinfo = aVertexUVinfo;
        gl_Position = aVertexXY;
    }
    
`;

GL_Sprites.FRAGMENT_SHADER = `

    varying highp vec2 UV, UVinfo;

    uniform sampler2D uSheetTexture;
    uniform sampler2D uPaletteTexture;
    uniform sampler2D uInfoTexture;

    const highp float a = 255.0/256.0, b = 1.0/32.0;

    highp float palU, palV;
    highp vec2 UVpal;

    void main()
    {
        palU = texture2D( uSheetTexture, UV ).a;
        palV = texture2D( uInfoTexture, UVinfo ).a;
        UVpal = a*vec2( palU, palV )+b;
        gl_FragColor = texture2D( uPaletteTexture, UVpal );
    }

`;

GL_Sprites.VERTEX_SHADER_ID=0; GL_Sprites.FRAGMENT_SHADER_ID=0; GL_Sprites.SHADER_PROGRAM_ID=0;

GL_Sprites.XY_ATTRIB_LOCATION=0; GL_Sprites.UV_SHEET_ATTRIB_LOCATION=0; GL_Sprites.UV_INFO_ATTRIB_LOCATION=0;
GL_Sprites.SHEET_TEXTURE_UNIFORM_LOCATION=null; GL_Sprites.PALETTE_TEXTURE_UNIFORM_LOCATION=null; GL_Sprites.INFO_TEXTURE_UNIFORM_LOCATION=null;


// init / shutdown

GL_Sprites.Init = function()
{
    const GL = GL_Entry.GL;
    
    // CREATE SHADER -----------------------------------------------------------

    let result = GL_Entry.MakeShader( GL_Sprites, GL_Sprites.VERTEX_SHADER, GL_Sprites.FRAGMENT_SHADER, "GL_Sprites" );
    if ( ! result )
    {
        console.log("GL_Sprites CANNOT COMPILE SHADER");
        return false;
    }
    
    // get locations
    
    GL_Sprites.XY_ATTRIB_LOCATION = GL.getAttribLocation(GL_Sprites.SHADER_PROGRAM_ID,"aVertexXY");
    GL_Sprites.UV_SHEET_ATTRIB_LOCATION = GL.getAttribLocation(GL_Sprites.SHADER_PROGRAM_ID,"aVertexUV");
    GL_Sprites.UV_INFO_ATTRIB_LOCATION = GL.getAttribLocation(GL_Sprites.SHADER_PROGRAM_ID,"aVertexUVinfo");
    
    console.log( "GL_Sprites XY attr loc: " + GL_Sprites.XY_ATTRIB_LOCATION );
    console.log( "GL_Sprites sheetUV attr loc : " + GL_Sprites.UV_SHEET_ATTRIB_LOCATION );
    console.log( "GL_Sprites infoUV attr loc: " + GL_Sprites.UV_INFO_ATTRIB_LOCATION );
    
    GL_Sprites.SHEET_TEXTURE_UNIFORM_LOCATION = GL.getUniformLocation(GL_Sprites.SHADER_PROGRAM_ID,"uSheetTexture");
    GL_Sprites.PALETTE_TEXTURE_UNIFORM_LOCATION = GL.getUniformLocation(GL_Sprites.SHADER_PROGRAM_ID,"uPaletteTexture");
    GL_Sprites.INFO_TEXTURE_UNIFORM_LOCATION = GL.getUniformLocation(GL_Sprites.SHADER_PROGRAM_ID,"uInfoTexture");
    
    console.log( "GL_Sprites Sheet Tex unif loc: " + GL_Sprites.SHEET_TEXTURE_UNIFORM_LOCATION );
    console.log( "GL_Sprites Info Tex unif loc:" + GL_Sprites.INFO_TEXTURE_UNIFORM_LOCATION );
    console.log( "GL_Sprites Palette Tex unif loc: " + GL_Sprites.PALETTE_TEXTURE_UNIFORM_LOCATION );
    
    // if not return error
    GL_Sprites.INIT = true;
    
    // dimensions

    GL_Sprites.TILE_HW = GL_Entry.GetTileSheetSize() * GL_Entry.GetScaleWidth() / 16.0 *.5; // pixel-perfect
    GL_Sprites.TILE_HH = GL_Entry.GetTileSheetSize() * GL_Entry.GetScaleHeight() / 16.0 *.5;
    
    return true;
};

GL_Sprites.ShutDown = function()
{
    if (!GL_Sprites.INIT)
    {
        return;
    }
    
    const GL = GL_Entry.GL;
    
    // delete the shaders

    GL.detachShader( GL_Sprites.SHADER_PROGRAM_ID, GL_Sprites.VERTEX_SHADER_ID );
    GL.detachShader( GL_Sprites.SHADER_PROGRAM_ID, GL_Sprites.FRAGMENT_SHADER_ID );
    GL.deleteShader( GL_Sprites.VERTEX_SHADER_ID );
    GL.deleteShader( GL_Sprites.FRAGMENT_SHADER_ID );

    console.log("GL_Sprites shader deleted");
};

// -----------------------------------------------------------------------------
// INSTANCE SPACE --------------------------------------------------------------
// -----------------------------------------------------------------------------

// constructor & destructor

GL_Sprites.prototype.build = function( numSprites, bufXY, bufUV, bufPX )
{
    const GL = GL_Entry.GL;
    
    if (!GL_Sprites.INIT)
    {
        console.log("   GL_Sprites not INIT, cannot instance !");
        return;
    }
    
    // instance index

    this.m_instanceIndex = GL_Sprites.NUM_INSTANCES;
    GL_Sprites.NUM_INSTANCES++;
    
    // round num sprites to next power 2

    this.m_numSprites = 1;
    while ( this.m_numSprites < numSprites )
    {
        this.m_numSprites <<= 1;
    }
    
    // create vertex buffers
    
    this.m_XY = bufXY;
    this.m_XYbuffer = GL.createBuffer();
    
    this.m_UVsheet = bufUV;
    this.m_UVsheetBuffer = GL.createBuffer();
    
    let UVinfo = new Float32Array( this.m_numSprites * 8 );
    const pixW = 1.0 / this.m_numSprites; // width of a pixel in u coord
    for ( let i = 0; i < this.m_numSprites; i++ )
    {
        for ( let j=0; j<4; j++ )
        {
            UVinfo[ i*8 + j*2 + 0 ] = pixW * ( .5 + i );
            UVinfo[ i*8 + j*2 + 1 ] = .5;
        }
    }
    this.m_UVinfoBuffer = GL.createBuffer();
    GL.bindBuffer( GL.ARRAY_BUFFER, this.m_UVinfoBuffer );
    GL.bufferData( GL.ARRAY_BUFFER, UVinfo, GL.STATIC_DRAW );
    UVinfo = null;
    
    let IDS = new Uint16Array( this.m_numSprites * 6 );
    for ( let i = 0; i < this.m_numSprites; i++ )
    {
        IDS[ i*6 + 0 ] = i*4 + 0;
        IDS[ i*6 + 1 ] = i*4 + 1;
        IDS[ i*6 + 2 ] = i*4 + 2;
        IDS[ i*6 + 3 ] = i*4 + 2;
        IDS[ i*6 + 4 ] = i*4 + 3;
        IDS[ i*6 + 5 ] = i*4 + 0;
    }
    this.m_IDSbuffer = GL.createBuffer();
    GL.bindBuffer( GL.ELEMENT_ARRAY_BUFFER, this.m_IDSbuffer );
    GL.bufferData( GL.ELEMENT_ARRAY_BUFFER, IDS, GL.STATIC_DRAW );
    IDS = null;
    
    // create info texture
    
    this.m_infoTable = bufPX ;
    this.m_infoTexture = GL.createTexture();
    GL.bindTexture( GL.TEXTURE_2D, this.m_infoTexture );
    GL.texParameteri( GL.TEXTURE_2D, GL.TEXTURE_MAG_FILTER, GL.NEAREST );
    GL.texParameteri( GL.TEXTURE_2D, GL.TEXTURE_MIN_FILTER, GL.NEAREST );

    //optimize later
    /*glBindTexture(GL_TEXTURE_1D,m_infoTextureId);
    glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);*/   
    
    console.log("   GL_Sprites instance "+ this.m_instanceIndex +" with "+ numSprites +" sprites created." );
};

GL_Sprites.prototype.delete = function ( )
{
    const GL = GL_Entry.GL;
    
    // delete info texture
    
    GL.deleteTexture( this.m_infoTexture );
    this.m_infoTable = null;
    
    // delete vertex buffers
        
    GL.deleteBuffer( this.m_XYbuffer );
    this.m_XY = null;

    GL.deleteBuffer( this.m_UVsheetBuffer );
    this.m_UVsheet = null;
    
    GL.deleteBuffer( this.m_UVinfoBuffer );
    
    GL.deleteBuffer( this.m_IDSbuffer );
    
    console.log("   GL_Sprites instance " + this.m_instanceIndex + " deleted." );
};

// video routine methods

GL_Sprites.prototype.Stream = function()
{
    const GL = GL_Entry.GL;
    
    // stream sprite info texture
    
    GL.bindTexture( GL.TEXTURE_2D, this.m_infoTexture );
    GL.texImage2D( GL.TEXTURE_2D, 0, GL.ALPHA, this.m_numSprites, 1, 0, GL.ALPHA, GL.UNSIGNED_BYTE, this.m_infoTable );
    // optimize later
    // glTexImage1D( GL_TEXTURE_1D, 0, GL_ALPHA, m_numSprites, 1, GL_ALPHA, GL_UNSIGNED_BYTE, m_infoTable );
    
    // stream vertexBuffers

    //console.log( this.m_XY );

    GL.bindBuffer( GL.ARRAY_BUFFER, this.m_XYbuffer );
    GL.bufferData( GL.ARRAY_BUFFER, this.m_XY, GL.DYNAMIC_DRAW );

    GL.bindBuffer( GL.ARRAY_BUFFER, this.m_UVsheetBuffer );
    GL.bufferData( GL.ARRAY_BUFFER, this.m_UVsheet, GL.DYNAMIC_DRAW );
    
};

GL_Sprites.prototype.Draw = function( texture )
{
    const GL = GL_Entry.GL;
        
    // draw in main buffer
    
    GL.bindFramebuffer( GL.FRAMEBUFFER, GL_Entry.GetMainTargetBuffer() );
    GL.viewport( 0, 0, GL_Entry.GetMainTargetWidth(), GL_Entry.GetMainTargetHeight() );
    
    GL.enable( GL.BLEND );
    GL.blendFunc( GL.SRC_ALPHA, GL.ONE_MINUS_SRC_ALPHA );
    
    // select shader

    GL.useProgram( GL_Sprites.SHADER_PROGRAM_ID );
    
    // select vertbuffers
    
    GL.bindBuffer( GL.ARRAY_BUFFER, this.m_XYbuffer );
    GL.vertexAttribPointer( GL_Sprites.XY_ATTRIB_LOCATION, 2, GL.FLOAT, GL.FALSE, 0, 0 );
    GL.enableVertexAttribArray( GL_Sprites.XY_ATTRIB_LOCATION );
 
    GL.bindBuffer( GL.ARRAY_BUFFER, this.m_UVsheetBuffer );
    GL.vertexAttribPointer( GL_Sprites.UV_SHEET_ATTRIB_LOCATION, 2, GL.FLOAT, GL.FALSE, 0, 0 );
    GL.enableVertexAttribArray( GL_Sprites.UV_SHEET_ATTRIB_LOCATION );
    
    GL.bindBuffer( GL.ARRAY_BUFFER, this.m_UVinfoBuffer );
    GL.vertexAttribPointer( GL_Sprites.UV_INFO_ATTRIB_LOCATION, 2, GL.FLOAT, GL.FALSE, 0, 0 );
    GL.enableVertexAttribArray( GL_Sprites.UV_INFO_ATTRIB_LOCATION );
    
    GL.bindBuffer( GL.ELEMENT_ARRAY_BUFFER, this.m_IDSbuffer );
    
    // select textures
    
    GL.activeTexture( GL.TEXTURE0 );
    GL.uniform1i( GL_Sprites.SHEET_TEXTURE_UNIFORM_LOCATION, 0 );
    GL.bindTexture( GL.TEXTURE_2D, texture );    
    
    GL.activeTexture( GL.TEXTURE1 );
    GL.uniform1i( GL_Sprites.INFO_TEXTURE_UNIFORM_LOCATION, 1 );
    GL.bindTexture( GL.TEXTURE_2D, this.m_infoTexture );
    // optimize later
    //glBindTexture( GL_TEXTURE_1D, m_infoTextureId );
    
    GL.activeTexture( GL.TEXTURE2 );
    GL.uniform1i( GL_Sprites.PALETTE_TEXTURE_UNIFORM_LOCATION, 2 );
    GL.bindTexture( GL.TEXTURE_2D, GL_Entry.GetPaletteTexture() );
    
    // draw

    GL.drawElements( GL.TRIANGLES, this.m_numSprites*6, GL.UNSIGNED_SHORT, 0 );
    
    // free attrib arrays (not sure it's useful here)

    GL.disableVertexAttribArray( this.XY_ATTRIB_LOCATION );
    GL.disableVertexAttribArray( this.UV_SHEET_ATTRIB_LOCATION );
    GL.disableVertexAttribArray( this.UV_INFO_ATTRIB_LOCATION );
    
};