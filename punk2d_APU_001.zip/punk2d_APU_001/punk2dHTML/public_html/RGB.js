// structs

function SheetTexture(){}
SheetTexture.prototype.update = false;
SheetTexture.prototype.pixels = null;

function SpriteBatch(){}
SpriteBatch.prototype.numSprites = 0;
SpriteBatch.prototype.XY = null;
SpriteBatch.prototype.UV = null;
SpriteBatch.prototype.PX = null;

function SheetDraw(){}
SheetDraw.prototype.srcTex = null;
SheetDraw.prototype.dstTarget = null;
SheetDraw.prototype.srcCol = null;
SheetDraw.prototype.srcRow = null;
SheetDraw.prototype.dstCol = null;
SheetDraw.prototype.dstRow = null;
SheetDraw.prototype.numCol = null;
SheetDraw.prototype.numRow = null;

function TileMap(){}
TileMap.prototype.numCol = 0;
TileMap.prototype.numRow = 0;
TileMap.prototype.xy = null;
TileMap.prototype.updateMap = 0;
TileMap.prototype.updateScanlines = 0;
TileMap.prototype.tiles = null;
TileMap.prototype.scanlines = null;

// static class

function RGB(){}

// INIT

RGB.InitPointers = function (b)
{
    console.log("RENDER GRAPHICS BUFFER CONVERT POINTERS TO JAVASCRIPT");

    // render buffer dimensions

    RGB.SCREEN_WIDTH = __Z14GetScreenWidthv(); // const
    RGB.SCREEN_HEIGHT = __Z15GetScreenHeightv(); // const

    // 16 * 16 pixels * 4 channels palette

    RGB.PALETTE = new Uint8ClampedArray(b, __Z17GetPaletteAddressv(), 16 * 16 * 4);
    
    // texture sheets

    RGB.TILESHEET_SIZE = __Z18GetSheetResolutionv(); // const
    const nt = __Z14GetNumTexturesv(); // const
    RGB.TEXTURES = [];
    let tAdd = __Z20GetSheetTexturesAddrv();
    for (let i = 0; i < nt; i++)
    {
        const arr = new Uint32Array(b, tAdd, 2);
        
        const st = RGB.TEXTURES[i] = new SheetTexture();
        st.update = new Uint8ClampedArray(b, tAdd, 1); // bool to update
        st.pixels = new Uint8ClampedArray(b, arr[1], RGB.TILESHEET_SIZE * RGB.TILESHEET_SIZE);
        
        tAdd += 2 * 4; // 2 props aligned on 32-bit
    }


    // render target sheets instructions buffer

    RGB.NUM_SHEETS = __Z18GetNumTargetSheetsv(); // const
    const max = __Z16GetMaxSheetDrawsv(); // const
    RGB.NUM_SHEET_DRAWS = new Uint8ClampedArray(b, __Z20GetNumSheetDrawsAddrv(), 1); // var pointer, one-cell array
    RGB.SHEET_DRAW_INFO = [];
    let dAdd = __Z20GetSheetDrawInfoAddrv();
    for (let i = 0; i < max; i++)
    {
        const inf = new SheetDraw();
        RGB.SHEET_DRAW_INFO[i] = inf;
        
        inf.srcTex =    new Uint8ClampedArray(b, dAdd + 0, 1);
        inf.dstTarget = new Uint8ClampedArray(b, dAdd + 1, 1);
        inf.srcCol =    new Uint8ClampedArray(b, dAdd + 2, 1);
        inf.srcRow =    new Uint8ClampedArray(b, dAdd + 3, 1);
        inf.dstCol =    new Uint8ClampedArray(b, dAdd + 4, 1);
        inf.dstRow =    new Uint8ClampedArray(b, dAdd + 5, 1);
        inf.numCol =    new Uint8ClampedArray(b, dAdd + 6, 1);
        inf.numRow =    new Uint8ClampedArray(b, dAdd + 7, 1);
        
        dAdd += 8;
    }


    // sprites batches

    const nSp = __Z20GetNumSpritesBatchesv();
    RGB.SPRITES_BATCHES = [];
    let bAdd = __Z21GetSpritesBatchesAddrv();
    for (let i = 0; i < nSp; i++)
    {
        const arr = new Uint32Array(b, bAdd, 4);
        
        const ns = arr[0];      
        let sb = RGB.SPRITES_BATCHES[i] = new SpriteBatch(); 
        sb.numSprites = ns;
        sb.XY = new Float32Array( b, arr[1], ns * 8 );
        sb.UV = new Float32Array( b, arr[2], ns * 8 );
        sb.PX = new Uint8ClampedArray( b, arr[3], ns );
        
        bAdd += 4 * 4;  // 4 props aligned on 32-bit
    }

    
    // tilemaps
    
    const nTm = __Z14GetNumTilemapsv();
    RGB.TILEMAPS = [];
    let mAdd = __Z15GetTilemapsAddrv();
    for (let i = 0; i < nTm; i++)
    {       
        let tm = RGB.TILEMAPS[i] = new TileMap();
        
        const arr8 = new Uint8ClampedArray(b, mAdd, 2); // bytes 0 and 1
        tm.numCol = arr8[0];
        tm.numRow = arr8[1];        
        tm.xy = new Int16Array(b, mAdd + 2, 2); // bytes 2 and 4
        tm.updateMap = new Uint8ClampedArray(b, mAdd + 6, 1); // byte 6
        tm.updateScanlines = new Uint8ClampedArray(b, mAdd + 7, 1); // byte 7
        const arr32 = new Uint32Array(b, mAdd + 8, 2); // bytes 8 and 12
        tm.tiles = new Uint8ClampedArray(b, arr32[0], tm.numRow * tm.numCol * 4 );
        tm.scanlines = new Uint8ClampedArray(b, arr32[1], RGB.TILESHEET_SIZE/16 * tm.numRow * 4 );  
                
        mAdd += 1+1+2+2+1+1+4+4;  // struct makes 16 bytes
    }

};

RGB.ShutdownPointers = function ()
{
    console.log("SHUTDOWN POINTERS");
    RGB.PALETTE = null;
    RGB.NUM_SHEET_DRAWS = null;  
    
    for ( i=0; i<RGB.TEXTURES.length; i++ )
    {
        RGB.TEXTURES[i].pixels = null;
    }
    
    for ( i=0; i<RGB.SPRITES_BATCHES.length; i++ )
    {
        RGB.SPRITES_BATCHES[i].XY = null;
        RGB.SPRITES_BATCHES[i].UV = null;
        RGB.SPRITES_BATCHES[i].PX = null;
    }

    console.log("RGB ARRAYS GARBAGED");
};

// ALL POINTERS ARE HERE

RGB.SCREEN_WIDTH = 0;
RGB.SCREEN_HEIGHT = 0;

RGB.PALETTE = null;

RGB.TILESHEET_SIZE = 0;
RGB.TEXTURES = null;

RGB.NUM_SHEETS = 0;
RGB.NUM_SHEET_DRAWS = null; // pointer get/set
RGB.SHEET_DRAW_INFO = null; // sourceTex, destTarget, sourceCol, sourceRow, destCol, destRow, numCol, numRow

RGB.SPRITES_BATCHES = null;

RGB.TILEMAPS = null;