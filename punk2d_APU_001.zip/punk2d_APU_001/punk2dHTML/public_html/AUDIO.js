"use strict";

// static class

function AUDIO(){}

AUDIO.CTX = null;
AUDIO.SRC_BUF = null;
AUDIO.SCRIPT_NODE = null;
AUDIO.LEFT = null;
AUDIO.RIGHT = null;
AUDIO.NOSND = null;

AUDIO.NUM_SAMPLES = 0;
AUDIO.MUTE = false;
AUDIO.STARTED = false;

AUDIO.Init = function( b )
{
    // AUDIO BUFFERS
    AUDIO.NUM_SAMPLES = __Z21GetNumSamplesByBufferv();
    AUDIO.LEFT = new Float32Array(b, __Z20GetLeftBufferAddressv(), AUDIO.NUM_SAMPLES);
    AUDIO.RIGHT = new Float32Array(b, __Z21GetRightBufferAddressv(), AUDIO.NUM_SAMPLES);
    AUDIO.NOSND = new Float32Array(AUDIO.NUM_SAMPLES); // empty buffer played when sound disabled
};

AUDIO.ShutDown = function ()
{
    AUDIO.LEFT = AUDIO.RIGHT = AUDIO.NOSND =  null;  
};

AUDIO.StartIfNot = function( b )
{
    if ( AUDIO.STARTED )
    {
        return;
    }
    AUDIO.STARTED = true;
    
    // CREATE AUDIO OBJECTS  
    
    AUDIO.CTX = new AudioContext();
    AUDIO.SRC_BUF = AUDIO.CTX.createBufferSource();
    AUDIO.SCRIPT_NODE = AUDIO.CTX.createScriptProcessor(AUDIO.NUM_SAMPLES, 0, 2);
    AUDIO.SCRIPT_NODE.onaudioprocess = AUDIO.Routine;
    
    // SET SAMPLERATE IN MODULE
        
    var arr = new Uint32Array(b, __Z20GetSampleRateAddressv(), 1);
    arr[0] = AUDIO.CTX.sampleRate;
    
    // START AUDIO ROUTINE
    
    AUDIO.SRC_BUF.connect(AUDIO.SCRIPT_NODE);
    AUDIO.SCRIPT_NODE.connect(AUDIO.CTX.destination);
    AUDIO.SRC_BUF.start();
};

AUDIO.Stop = function()
{
    if (AUDIO.STARTED)
    {
        AUDIO.SCRIPT_NODE.disconnect();
        AUDIO.SRC_BUF.disconnect();
        AUDIO.CTX.close();
        console.log("audio closed");
    }
    AUDIO.SCRIPT_NODE = AUDIO.SRC_BUF = AUDIO.CTX = null;
};

AUDIO.Routine = function (evt)
{
    var leftData = evt.outputBuffer.getChannelData(0);
    var rightData = evt.outputBuffer.getChannelData(1);
    
    if ( AUDIO.MUTE ) {
        leftData.set(AUDIO.NOSND);
        rightData.set(AUDIO.NOSND);
    } else {
        __Z12AudioRoutinev();
        leftData.set(AUDIO.LEFT);
        rightData.set(AUDIO.RIGHT);
    }    
};