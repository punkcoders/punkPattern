/*
 Code under P.U.N.K. license: Poor Useless Newbie Kidcoding
 so you're free to do what you want with it
 http://punkcoders.free.fr
 pukcoders@gmail.com
 */
"use strict";

// GLOBAL VARS

// MODULE BUFFER MEMORY
var B = null;

//GRAPHICS
var SW = 480, SH = 320, TW = 0, TH = 0, STRETCH = 1.5; // screen dimensions
var CONT = null, CAN = null, CTX = null; // canvas context 2d

//FILES
var FILE_NAME = null, FILE_BUFFER = null;
var MAX_FILE_SIZE = 1024;
var FILE_LOADER = new XMLHttpRequest();
var WAIT_FILE = false;

//CONTROL
var LAST_KEY = null, MOUSE_X = null, MOUSE_Y = null;


// GLOBAL FUNCTIONS

// focus events
window.onblur = function () {
    AUDIO.MUTE = 1;
};
window.onfocus = function () {
    AUDIO.MUTE = 0;
};

// ce qu'on va modifier LA,
// main() va juste afficher un bouton pour skipper la pub dans 1 2 3...
// une fois ce bouton cliqué on lance le programme
// on fera plus tard un joli preloadeur

function main()
{
    console.log("##################################");
    console.log("###       program start        ###");
    console.log("##################################");

    B = wasmMemory.buffer;

    // GRAPHICS

    RGB.InitPointers(B);

    SW = RGB.SCREEN_WIDTH;
    SH = RGB.SCREEN_HEIGHT;

    CAN = document.createElement('canvas');
    CAN.width = SW * STRETCH;
    CAN.height = SH * STRETCH;
    CAN.style.backgroundColor = '#000000';
    CAN.style.width = "100%";
    CAN.style.height = "100%";
    CAN.onmousedown = OnMouseDown;
    CAN.onmouseup = OnMouseUp;
    CAN.onmousemove = OnMouseMove;
    CONT = document.getElementById("container");
    CONT.innerHTML = "";
    CONT.appendChild(CAN);
    CONT.style.width = SW * STRETCH + "px";
    CONT.style.height = SH * STRETCH + "px";
    CONT.fillStyle = "#000000";

    CTX = CAN.getContext('webgl', {antialias: false, depth: false, alpha: false}); // 2d webgl   

    // init webgl stuff
    let result = GL_Entry.Init(CTX, SW, SH, null);
    if (!result)
    {
        alert("cannot initialize webGL objects");
        return 0;
    }

    // AUDIO BUFFERS   
    AUDIO.Init(B);

    // FILE BUFFERS    
    MAX_FILE_SIZE = __Z14GetMaxFileSizev();
    FILE_NAME = new Uint8Array(B, __Z18GetFileNameAddressv(), 256);
    FILE_BUFFER = new Uint8Array(B, __Z20GetFileBufferAddressv(), MAX_FILE_SIZE);

    // CONTROLS POINTERS
    LAST_KEY = new Uint8Array(B, __Z24GetLastKeyPressedAddressv());
    MOUSE_X = new Uint32Array(B, __Z16GetMouseXAddressv());
    MOUSE_Y = new Uint32Array(B, __Z16GetMouseYAddressv());

    // START VIDEO ROUTINE
    window.requestAnimationFrame(VideoRoutine);
}

function exitApp()
{
    GL_Entry.ShutDown();
    RGB.ShutdownPointers();

    AUDIO.Stop(B);
    AUDIO.ShutDown();

    document.onkeydown = null;
    document.onkeyup = null;
    CAN.onmousedown = null;
    CAN.onmouseup = null;
    CAN.onmousemove = null;
    CONT.parentNode.removeChild(CONT);
    
    console.log("close module");
    __Z7ExitAppv();
}
window.onunload = function ()
{
    console.log("EXIT APPLICATION, clear RAM & VRAM");
    exitApp();
    console.log("##################################");
    console.log("###  clear RAM & VRAM SUCCESS  ###");
    console.log("##################################");
    console.log("**********************************************************************************************************");
};

// VIDEO EVENTS

function makeFullScreen(element) {
    if (element.requestFullScreen) {
        element.requestFullScreen();
    } else if (element.webkitRequestFullScreen) {
        element.webkitRequestFullScreen();
    } else if (element.mozRequestFullScreen) {
        element.mozRequestFullScreen();
    } else if (element.msRequestFullScreen) {
        element.msRequestFullScreen();
    }
}
function GoFullScreen() {
    makeFullScreen(CONT);
}

function VideoRoutine(dt)
{
    if (!WAIT_FILE) {
        // set canvas size to client rect if needed   
        if (CAN.width !== CONT.getBoundingClientRect().width)
        {
            CAN.width = CONT.getBoundingClientRect().width;
        }
        if (CAN.height !== CONT.getBoundingClientRect().height)
        {
            CAN.height = CONT.getBoundingClientRect().height;
        }
        // video routines   
        __Z12VideoRoutinev();
        GL_Entry.VideoRoutine(CAN.width, CAN.height);
    }
    // attempt load file
    if (FILE_NAME[0]) {
        WAIT_FILE = true;
        LoadFile();
        FILE_NAME[0] = 0;
    }
    if (!__Z7GetExitv())
    {
        window.requestAnimationFrame(VideoRoutine);
    } else
    {
        exitApp();
    }
}

// audio events
function TestAudioStart() {
    AUDIO.Start(B);
}

// load file events
function LoadFile() {
    var str = "";
    for (var i = 0; FILE_NAME[i]; i++) {
        str += String.fromCharCode(FILE_NAME[i]);
    }
    console.log(str);
    FILE_LOADER.open("GET", str, true);
    FILE_LOADER.responseType = 'arraybuffer';
    FILE_LOADER.send(null);
}
FILE_LOADER.onreadystatechange = function () {
    console.log("e.readyState: " + this.readyState, "e.status: " + this.status);

    if (this.readyState === 4) {
        if (this.status === 200) {
            var buffer = new Uint8Array(this.response);
            FILE_BUFFER.set(buffer);
            __Z8OnLoadedv();
        } else {
            console.log("loadErrorEvent");
            __Z11OnLoadErrorv();
        }
        WAIT_FILE = false;
    }
};

// key events
// aller chercher la version moderne dans le test boris
document.onkeydown = function (e) {
    
    AUDIO.StartIfNot(B);
    
    LAST_KEY[0] = e.keyCode;
    __Z9OnKeyDownv();
    e.preventDefault();
};
document.onkeyup = function (e) {
    LAST_KEY[0] = e.keyCode;
    __Z7OnKeyUpv();
};

// mouse events
function getMouseX(e) {
    var rect = e.target.getBoundingClientRect();
    var x = (e.clientX - rect.left) / (rect.width / SW);
    if (x < 0)
        x = 0;
    if (x >= SW)
        x = SW - 1;
    return x;
}
function getMouseY(e) {
    var rect = e.target.getBoundingClientRect();
    var y = (e.clientY - rect.top) / (rect.height / SH);
    if (y < 0)
        y = 0;
    if (y >= SH)
        y = SH - 1;
    return y;
}
function OnMouseDown(e) {
    
    AUDIO.StartIfNot(B);
    
    MOUSE_X[0] = getMouseX(e);
    MOUSE_Y[0] = getMouseY(e);
    __Z11OnMouseDownv();
}
function OnMouseUp(e) {
    MOUSE_X[0] = getMouseX(e);
    MOUSE_Y[0] = getMouseY(e);
    __Z9OnMouseUpv();
}
function OnMouseMove(e) {
    MOUSE_X[0] = getMouseX(e);
    MOUSE_Y[0] = getMouseY(e);
}
