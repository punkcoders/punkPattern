/*
 Code under P.U.N.K. license: Poor Useless Newbie Kidcoding
 so you're free to do what you want with it
 http://punkcoders.free.fr
 pukcoders@gmail.com
 */
"use strict";

// static class, no instance props/methods
function GL_Entry() {}

// -----------------------------------------------------------------------------
// MAIN STATIC PROPS -----------------------------------------------------------
// -----------------------------------------------------------------------------

GL_Entry.GL = null; // reference to webGL context, used by all classes

// dimensions

GL_Entry.MAIN_TARGET_WIDTH = 1;
GL_Entry.MAIN_TARGET_HEIGHT = 1;
GL_Entry.TILESHEET_SIZE = 1;

// main target render frame buffer

GL_Entry.MAIN_TARGET_BUFFER = null;

// vertices

GL_Entry.MAIN_TARGET_XY = new Float32Array([-1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0]);
GL_Entry.MAIN_TARGET_XY_BUFFER;

GL_Entry.MAIN_TARGET_UV = new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]);
GL_Entry.MAIN_TARGET_UV_BUFFER;

GL_Entry.MAIN_TARGET_IDS = new Uint16Array([0, 1, 2, 2, 3, 0]);
GL_Entry.MAIN_TARGET_IDS_BUFFER;

// textures

GL_Entry.MAIN_TARGET_TEXTURE = null;

GL_Entry.PALETTE_TEXTURE = null;

// shaders and locations

GL_Entry.VERTEX_SHADER = `

    attribute highp vec4 aVertexXY;
    attribute highp vec2 aVertexUV;

    varying highp vec2 UV;

    void main()
    {
        UV = aVertexUV;
        gl_Position =  aVertexXY;
    }

`;

GL_Entry.FRAGMENT_SHADER = `

    varying highp vec2 UV;

    uniform sampler2D uScreenTexture;

    void main()
    {
        gl_FragColor = texture2D( uScreenTexture, UV ).rgba;
    }

`;

GL_Entry.VERTEX_SHADER_ID = 0, GL_Entry.FRAGMENT_SHADER_ID = 0, GL_Entry.SHADER_PROGRAM_ID = 0;

GL_Entry.XY_ATTRIB_LOCATION = 0;
GL_Entry.UV_ATTRIB_LOCATION = 0;
GL_Entry.TEXTURE_UNIFORM_LOCATION = null;


// -----------------------------------------------------------------------------
// MAIN STATIC METHODS ---------------------------------------------------------
// -----------------------------------------------------------------------------

// getters

GL_Entry.GetMainTargetWidth = function ()
{
    return GL_Entry.MAIN_TARGET_WIDTH;
};
GL_Entry.GetMainTargetHeight = function ()
{
    return GL_Entry.MAIN_TARGET_HEIGHT;
};

GL_Entry.GetScaleWidth = function ()
{
    return 2.0 / GL_Entry.MAIN_TARGET_WIDTH;
};
GL_Entry.GetScaleHeight = function ()
{
    return 2.0 / GL_Entry.MAIN_TARGET_HEIGHT;
};

GL_Entry.GetTileSheetSize = function ()
{
    return GL_Entry.TILESHEET_SIZE;
};

GL_Entry.GetMainTargetBuffer = function ()
{
    return GL_Entry.MAIN_TARGET_BUFFER;
};

GL_Entry.GetPaletteTexture = function ()
{
    return GL_Entry.PALETTE_TEXTURE;
};

// setters

GL_Entry.UpdatePalette = function (data)
{
    const GL = GL_Entry.GL;
    GL.bindTexture(GL.TEXTURE_2D, GL_Entry.PALETTE_TEXTURE);
    GL.texImage2D(GL.TEXTURE_2D, 0, GL.RGBA, 16, 16, 0, GL.RGBA, GL.UNSIGNED_BYTE, data);
};

// THE SHADER HELPER

GL_Entry.MakeShader = function (object, vertShader, fragShader, shaderName)
{
    const GL = GL_Entry.GL;

    // store ids in locals first

    let vSid, fSid, sPid;

    // create the vertex shader

    vSid = GL.createShader(GL.VERTEX_SHADER);
    GL.shaderSource(vSid, vertShader);
    GL.compileShader(vSid);
    let result = GL.getShaderParameter(vSid, GL.COMPILE_STATUS);
    if (result)
    {
        console.log(shaderName + " vertex shader compiled");
    } else
    {
        console.log(shaderName + " cannot compile vertex shader");
        GL.deleteShader(vSid);
        return false;
    }

    // create the fragment shader

    fSid = GL.createShader(GL.FRAGMENT_SHADER);
    GL.shaderSource(fSid, fragShader);
    GL.compileShader(fSid);
    result = GL.getShaderParameter(fSid, GL.COMPILE_STATUS);
    if (result)
    {
        console.log(shaderName + " fragment shader compiled");
    } else
    {
        console.log(shaderName + " cannot compile fragment shader");
        GL.deleteShader(fSid);
        return false;
    }

    // link the program shader

    sPid = GL.createProgram();
    GL.attachShader(sPid, vSid);
    GL.attachShader(sPid, fSid);
    GL.linkProgram(sPid);
    result = GL.getProgramParameter(sPid, GL.LINK_STATUS);
    if (result)
    {
        console.log(shaderName + " shaders program linked");
    } else
    {
        GL.detachShader(sPid, vSid);
        GL.detachShader(sPid, fSid);
        console.log(shaderName + " cannot link shaders program");
        return false;
    }

    // if ok, store locals in statics
    object.VERTEX_SHADER_ID = vSid;
    object.FRAGMENT_SHADER_ID = fSid;
    object.SHADER_PROGRAM_ID = sPid;

    return true;
};

// INIT / SHUTDOWN / VIDEO ROUTINE

GL_Entry.Init = function (GL, screenWidth, screenHeight, dataBuffer)
{
    console.log("GL_Entry Init");

    // context

    GL_Entry.GL = GL;

    // CREATE SHADER -----------------------------------------------------------

    let result = GL_Entry.MakeShader(GL_Entry, GL_Entry.VERTEX_SHADER, GL_Entry.FRAGMENT_SHADER, "Main RenderTarget");
    if (!result)
    {
        CRASHED = true;
        return false;
    }

    // get locations

    GL_Entry.XY_ATTRIB_LOCATION = GL.getAttribLocation(GL_Entry.SHADER_PROGRAM_ID, "aVertexXY");
    GL_Entry.UV_ATTRIB_LOCATION = GL.getAttribLocation(GL_Entry.SHADER_PROGRAM_ID, "aVertexUV");
    GL_Entry.TEXTURE_UNIFORM_LOCATION = GL.getUniformLocation(GL_Entry.SHADER_PROGRAM_ID, "uScreenTexture");

    console.log("main target XY attr loc: " + GL_Entry.XY_ATTRIB_LOCATION);
    console.log("main target UV attr loc: " + GL_Entry.UV_ATTRIB_LOCATION);
    console.log("main target Tex unif loc: " + GL_Entry.TEXTURE_UNIFORM_LOCATION);


    // CREATE DATA -------------------------------------------------------------

    // dimensions (we'll see later how to command sheet resolution from module)

    GL_Entry.MAIN_TARGET_WIDTH = screenWidth;
    GL_Entry.MAIN_TARGET_HEIGHT = screenHeight;
    GL_Entry.TILESHEET_SIZE = 256;


    // CREATE OPENGL OBJECTS ---------------------------------------------------

    // create the renderTarget framebuffer and its texture

    GL_Entry.MAIN_TARGET_BUFFER = GL.createFramebuffer();

    GL_Entry.MAIN_TARGET_TEXTURE = GL.createTexture();
    GL.bindTexture(GL.TEXTURE_2D, GL_Entry.MAIN_TARGET_TEXTURE);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_MAG_FILTER, GL.LINEAR);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_MIN_FILTER, GL.LINEAR);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_WRAP_S, GL.CLAMP_TO_EDGE);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_WRAP_T, GL.CLAMP_TO_EDGE);
    GL.texImage2D(GL.TEXTURE_2D, 0, GL.RGBA, GL_Entry.MAIN_TARGET_WIDTH, GL_Entry.MAIN_TARGET_HEIGHT, 0, GL.RGBA, GL.UNSIGNED_BYTE, null);

    GL.bindFramebuffer(GL.FRAMEBUFFER, GL_Entry.MAIN_TARGET_BUFFER);
    GL.framebufferTexture2D(GL.FRAMEBUFFER, GL.COLOR_ATTACHMENT0, GL.TEXTURE_2D, GL_Entry.MAIN_TARGET_TEXTURE, 0);

    if (GL.checkFramebufferStatus(GL.FRAMEBUFFER) !== GL.FRAMEBUFFER_COMPLETE)
    {
        console.log("main target RENDERTARGET FRAMEBUFFER CONFIGURATION ERROR");
        GL_Entry.CRASHED = true;
        return false;
    }

    // back to main buffer
    GL.bindFramebuffer(GL.FRAMEBUFFER, null);

    // create the vertices

    GL_Entry.MAIN_TARGET_XY_BUFFER = GL.createBuffer();
    GL.bindBuffer(GL.ARRAY_BUFFER, GL_Entry.MAIN_TARGET_XY_BUFFER);
    GL.bufferData(GL.ARRAY_BUFFER, GL_Entry.MAIN_TARGET_XY, GL.STATIC_DRAW);

    GL_Entry.MAIN_TARGET_UV_BUFFER = GL.createBuffer();
    GL.bindBuffer(GL.ARRAY_BUFFER, GL_Entry.MAIN_TARGET_UV_BUFFER);
    GL.bufferData(GL.ARRAY_BUFFER, GL_Entry.MAIN_TARGET_UV, GL.STATIC_DRAW);

    GL_Entry.MAIN_TARGET_IDS_BUFFER = GL.createBuffer();
    GL.bindBuffer(GL.ELEMENT_ARRAY_BUFFER, GL_Entry.MAIN_TARGET_IDS_BUFFER);
    GL.bufferData(GL.ELEMENT_ARRAY_BUFFER, GL_Entry.MAIN_TARGET_IDS, GL.STATIC_DRAW);

    // create the palette texture

    GL_Entry.PALETTE_TEXTURE = GL.createTexture();
    GL.bindTexture(GL.TEXTURE_2D, GL_Entry.PALETTE_TEXTURE);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_MAG_FILTER, GL.NEAREST);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_MIN_FILTER, GL.NEAREST);

    // create graphic objects

    let ok = GL_Entry.CreateObjects(dataBuffer);
    if (!ok)
    {
        return false;
    }

    return true;
};

GL_Entry.ShutDown = function ()
{
    console.log("GL_Entry Shutdown");
    if (GL_Entry.CRASHED)
    {
        return;
    }

    const GL = GL_Entry.GL;

    // delete graphic objects

    GL_Entry.DeleteObjects();

    // delete palette

    GL.deleteTexture(GL_Entry.PALETTE_TEXTURE);
    GL_Entry.PALETTE_TEXTURE = null;
    GL_Entry.PALETTE = null;
    console.log("GL_Entry palette texture deleted");

    // delete the vertices buffers

    GL.deleteBuffer(GL_Entry.MAIN_TARGET_IDS_BUFFER);
    GL.deleteBuffer(GL_Entry.MAIN_TARGET_UV_BUFFER);
    GL.deleteBuffer(GL_Entry.MAIN_TARGET_XY_BUFFER);
    console.log("main target vertices deleted");

    // delete the texture

    GL.deleteTexture(GL_Entry.MAIN_TARGET_TEXTURE);
    console.log("main target texture deleted");

    // delete rendertarget buffer

    GL.deleteFramebuffer(GL_Entry.MAIN_TARGET_BUFFER);
    console.log("main target renderTarget frame buffer deleted");

    // delete the shader

    GL.detachShader(GL_Entry.SHADER_PROGRAM_ID, GL_Entry.VERTEX_SHADER_ID);
    GL.detachShader(GL_Entry.SHADER_PROGRAM_ID, GL_Entry.FRAGMENT_SHADER_ID);
    GL.deleteShader(GL_Entry.VERTEX_SHADER_ID);
    GL.deleteShader(GL_Entry.FRAGMENT_SHADER_ID);
    console.log("main target shaders deleted");

};

GL_Entry.VideoRoutine = function (viewportWidth, viewportHeight)
{
    if (GL_Entry.CRASHED)
    {
        return;
    }

    const GL = GL_Entry.GL;

    // black clear window buffer

    GL.clearColor(0, 0, 0, 1);
    GL.clear(GL.COLOR_BUFFER_BIT);

    // STEP ONE: RENDER OBJECTS IN RENDERTARGET BUFFER -----------------------------------------------

    GL_Entry.ObjectsRoutine();

    // STEP TWO: RENDER IN MAIN BUFFER -------------------------------------------------------------------

    // back to main buffer

    GL.bindFramebuffer(GL.FRAMEBUFFER, null);
    GL.viewport(0, 0, viewportWidth, viewportHeight);

    GL.disable(GL.BLEND);

    // select shader program

    GL.useProgram(GL_Entry.SHADER_PROGRAM_ID);

    // select texture

    GL.activeTexture(GL.TEXTURE0);
    GL.uniform1i(GL_Entry.TEXTURE_UNIFORM_LOCATION, 0);
    GL.bindTexture(GL.TEXTURE_2D, GL_Entry.MAIN_TARGET_TEXTURE);

    // select vertbuffers

    GL.bindBuffer(GL.ARRAY_BUFFER, GL_Entry.MAIN_TARGET_XY_BUFFER);
    GL.vertexAttribPointer(GL_Entry.XY_ATTRIB_LOCATION, 2, GL.FLOAT, GL.FALSE, 0, 0);
    GL.enableVertexAttribArray(GL_Entry.XY_ATTRIB_LOCATION);

    GL.bindBuffer(GL.ARRAY_BUFFER, GL_Entry.MAIN_TARGET_UV_BUFFER);
    GL.vertexAttribPointer(GL_Entry.UV_ATTRIB_LOCATION, 2, GL.FLOAT, GL.FALSE, 0, 0);
    GL.enableVertexAttribArray(GL_Entry.UV_ATTRIB_LOCATION);

    GL.bindBuffer(GL.ELEMENT_ARRAY_BUFFER, GL_Entry.MAIN_TARGET_IDS_BUFFER);

    // draw

    GL.drawElements(GL.TRIANGLES, 6, GL.UNSIGNED_SHORT, 0);

    // free attrib arrays (not sure it's usefule here)

    GL.disableVertexAttribArray(GL_Entry.XY_ATTRIB_LOCATION);
    GL.disableVertexAttribArray(GL_Entry.UV_ATTRIB_LOCATION);

    // end
};


// -----------------------------------------------------------------------------
// OBJECTS STATIC PROPS --------------------------------------------------------
// -----------------------------------------------------------------------------

GL_Entry.TICK = 0; // frame counter
GL_Entry.SHEETS = null;
GL_Entry.SPRITES = null;
GL_Entry.TILEMAPS = null;

// -----------------------------------------------------------------------------
// OBJECTS STATIC METHODS ------------------------------------------------------
// -----------------------------------------------------------------------------

// create/delete/routine

GL_Entry.CreateObjects = function (dataBuffer)
{
    // init classes static space

    let ok = true;

    console.log("NUM TEXTURES: " + RGB.TEXTURES.length);

    ok = GL_Sheet.Init(RGB.TEXTURES.length);
    if (!ok)
    {
        console.log("CANNOT INIT GL_Sheet");
        return false;
    }

    ok = GL_Sprites.Init();
    if (!ok)
    {
        console.log("CANNOT INIT GL_Sprites");
        return false;
    }

    ok = GL_Tilemap.Init();
    if (!ok)
    {
        console.log("CANNOT INIT GL_Tilemap");
        return false;
    }

    const GL = GL_Entry.GL;

    // create instances

    GL_Entry.SHEETS = [];
    console.log("NUM SHEETS: "+RGB.NUM_SHEETS);
    for ( let i = 0; i < RGB.NUM_SHEETS; i++ )
    {
        GL_Entry.SHEETS[i] = new GL_Sheet();
    }

    GL_Entry.SPRITES = [];
    for ( let i = 0; i < RGB.SPRITES_BATCHES.length; i++ )
    {
        const sb = RGB.SPRITES_BATCHES[i];
        GL_Entry.SPRITES[i] = new GL_Sprites( sb.numSprites, sb.XY, sb.UV, sb.PX );
    }

    GL_Entry.TILEMAPS = [];
    for ( let i = 0; i < RGB.TILEMAPS.length; i++ )
    {
        const tm = RGB.TILEMAPS[i];
        GL_Entry.TILEMAPS[i] = new GL_Tilemap( tm.numCol, tm.numRow, tm.tiles, tm.scanlines );
    }

    // first render
    
    GL_Entry.ObjectsRoutine();

    return true;
};

GL_Entry.DeleteObjects = function ()
{
    // delete instances

    for ( let i=0; i < GL_Entry.TILEMAPS.length; i++ )
    {
        GL_Entry.TILEMAPS[i].delete();
        GL_Entry.TILEMAPS[i] = null;        
    }

    for ( let i=0; i < GL_Entry.SPRITES.length; i++ )
    {
        GL_Entry.SPRITES[i].delete();
        GL_Entry.SPRITES[i] = null;
    }
    GL_Entry.SPRITES = null;

    for ( let i = 0; i < GL_Entry.SHEETS.length; i++ )
    {
        GL_Entry.SHEETS[i].delete();
        GL_Entry.SHEETS[i] = null;
    }
    GL_Entry.SHEETS = null;

    // shutdown classes static space

    GL_Tilemap.ShutDown();
    GL_Sprites.ShutDown();
    GL_Sheet.ShutDown();

};

GL_Entry.ObjectsRoutine = function ()
{
    const GL = GL_Entry.GL;

    // stream phase

    GL_Entry.ObjectsStreamRoutine();
    GL_Entry.UpdatePalette(RGB.PALETTE); // palette will be stored in module

    // clear main target buffer (will be removed because background does not blend)

    GL.bindFramebuffer(GL.FRAMEBUFFER, null);
    GL.clearColor(0, 0, 0, 1);
    GL.clear(GL.COLOR_BUFFER_BIT);

    // render phase

    GL_Entry.ObjectsDrawRoutine();
};

GL_Entry.ObjectsStreamRoutine = function ()
{
    for ( let i = 0; i < RGB.TEXTURES.length; i++ )
    {
        const st = RGB.TEXTURES[i];
        if ( st.update[0] ) // wasm var pointer
        {
            console.log("STREAM SHEET TEXTURE " + i);
            GL_Sheet.UpdateTexture(i, st.pixels);
            st.update[0] = false;
        }
    }

    for ( let i = 0; i < GL_Entry.TILEMAPS.length; i++ )
    {
        const tm = RGB.TILEMAPS[i];
        GL_Entry.TILEMAPS[i].Stream( tm.updateMap[0], tm.updateScanlines[0] );
        tm.updateMap[0] = false;
        tm.updateScanlines[0] = false;
    }

    for ( let i in GL_Entry.SPRITES )
    {
        GL_Entry.SPRITES[i].Stream();
    }
};

GL_Entry.ObjectsDrawRoutine = function ()
{
    // pre-render target sheets ----------------------------------------------

    for ( let i=0; i< RGB.NUM_SHEET_DRAWS[0]; i++ )
    {
        const d = RGB.SHEET_DRAW_INFO[i];
        GL_Entry.SHEETS[ d.dstTarget[0] ].Draw( d.srcTex[0], d.srcCol[0], d.srcRow[0], d.dstCol[0], d.dstRow[0], d.numCol[0], d.numRow[0] );
    }

    // render maps and sprites -----------------------------------------------

    // background

    let tm = RGB.TILEMAPS[0];
    GL_Entry.TILEMAPS[0].Draw(GL_Entry.SHEETS[0].GetRenderTexture(), tm.xy[0], tm.xy[1], false);

    GL_Entry.SPRITES[0].Draw(GL_Entry.SHEETS[1].GetRenderTexture()); // background sprites
    
    // foreground
    
    tm = RGB.TILEMAPS[1];
    GL_Entry.TILEMAPS[1].Draw(GL_Entry.SHEETS[2].GetRenderTexture(), tm.xy[0], tm.xy[1], true);
    
    GL_Entry.SPRITES[1].Draw(GL_Entry.SHEETS[3].GetRenderTexture()); // should be used for player
    GL_Entry.SPRITES[2].Draw(GL_Entry.SHEETS[4].GetRenderTexture()); // should be used for non-player
    
    GL_Entry.SPRITES[3].Draw(GL_Entry.SHEETS[5].GetRenderTexture()); // lolypops, buttons

};