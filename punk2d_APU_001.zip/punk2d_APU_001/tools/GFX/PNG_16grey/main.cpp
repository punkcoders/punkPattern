#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

#include "LodePNG.h"

using namespace std;

bool convertPNG( const char* filename )
{
    vector<unsigned char> image; //the raw pixels
    unsigned width, height;

    //decode
    unsigned error = lodepng::decode(image, width, height, filename);

    //if there's an error, display it
    if(error)
    {
        cout << "decoder error " << error << ": " << lodepng_error_text(error) << std::endl;
        return false;
    }
    else
    {
        cout << "png loaded" << endl;
    }

    // the pixels are now in the vector "image", 4 bytes per pixel, ordered RGBARGBA..., use it as texture, draw it, ...

    if ( image.size() != 256*256*4 )
    {
        return false;
    }

    cout << "convert grayscale pixels to 16 color row long long table" << endl;

    // convert to 16 color index

    unsigned char indexTable[256*256];

    for ( int y = 0; y<256; y++ )
    {
        for ( int x = 0; x<256; x++ )
        {
            // red channel
            indexTable[ y*256 + x  ] = image[ ( y*256 + x ) * 4 ] >> 4;
        }
    }

    // compress to unsigned long 8 pixel row
    // so, 32 unsigned longs per sheet row

    unsigned long rowTable[ 32 * 256 ];

    for ( int y = 0; y < 256; y++ )
    {
        for ( int r = 0; r < 32; r++ )
        {
            unsigned long row = 0;
            int offset = 0;
            for ( int x = (r+0)*8; x < (r+1)*8; x++ )
            {
                row |= indexTable[ 256*y + x ] << offset;
                offset += 4;
            }
            rowTable[ y * 32 + r ] = row;
        }
    }

    // display hard-coded table

    cout << "{";
    for ( int i = 0; i < 256 * 32; i++ )
    {
        cout << rowTable[ i ];

        if ( i < 256 * 32 - 1 )
        {
            cout << ",";
        }
    }
    cout << "};" << endl;

    return true;
}

int main()
{
    cout << "::: PNG GRAYSCALE / PUNKPALETTE CONVERTER TO 16 COLOR :::" << endl;

    bool loop = true;

    string folder = "images/";
    string inputStr;
    string exit = "exit";

    ifstream file;

    while ( loop )
    {
        cout << endl;
        cout << "load file: type the name of file inside 'images' folder." << endl;
        cout << "exit: type 'exit'." << endl;

        getline( cin, inputStr );

        if ( inputStr.compare(exit) == 0 )
        {
            cout << "exit program" << endl;
            loop = false;
        }
        else
        {
            string pathStr = folder+inputStr;

            cout << "loading file: " << pathStr << endl;

            // check if file exists

            const char * path = pathStr.c_str();
            file.open( path );

            if ( file.is_open() )
            {
                // all happens here

                bool compatible = convertPNG( path );

                if (!compatible)
                {
                    cout << "UNCOMPATIBLE PNG FORMAT. 256x256px required." << endl;
                }

                file.close();
            }
            else
            {
                cout << "file doesn't exist !" << endl;
            }

        }
    }

    return 0;
}
