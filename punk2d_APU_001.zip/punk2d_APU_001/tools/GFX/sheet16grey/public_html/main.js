var IMG = new Image();
var CTX = null;

function convert()
{
    console.log("converting 4 bit colors 16px rows to long long");
    
    const imgData = CTX.getImageData(0,0,256,256);
    const pixTable = new Uint32Array( imgData.data.buffer );
    
    // convert grey red channel to palette 16 index;
    
    const indexTable = new Uint8ClampedArray(256*256);
    
    for ( let y = 0; y<256; y++ )
    {
        for ( let x = 0; x<256; x++ )
        {
            // red channel
            indexTable[ y*256 + x ] = ( (pixTable[y*256 + x]&0xff) >> 4 )&15;
        }
    }
    
    // compress in long 8px rows
    
    let compressed = new Uint32Array(256*32);
    
    for ( let y = 0; y < 256; y++ )
    {
        for ( let r=0; r < 32; r++ )
        {
            let row = 0, offset = 0;
            for ( let x = r * 8; x < (r+1) * 8; x++ )
            {
                row |= indexTable[ y*256 + x ] << offset;
                offset += 4;
            }
            compressed[ y*32 + r ] = row;
        }
    }
    
    document.getElementById('outStr').innerHTML = "{"+compressed+"};";
}

IMG.onload = function( e )
{
    console.log('image loaded');    
    CTX.drawImage(IMG,0,0,256,256);
    convert();
};

function load()
{
    console.log("loading pic");
    
    IMG.src = 'images/'+document.getElementById('fileName').value;
    console.log(IMG.src);    
}

function main ()
{
    console.log("init .png parser");
    
    CTX = document.getElementById('show').getContext('2d');
    console.log("context2d: "+CTX);
}