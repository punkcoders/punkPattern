#ifndef GAME__H
#define GAME__H


class GAME_
{
    public:
        GAME_();
        virtual ~GAME_();

    protected:

    private:
};

#endif // GAME__H
