#ifndef GAME_DATA_SHEETS_H
#define GAME_DATA_SHEETS_H

class GAME_DATA_Sheets
{
public:

    static unsigned long SHEET_1[ 256 * 32 ], SHEET_2[ 256 * 32 ];

};

#endif // GAME_DATA_SHEETS_H
