#ifndef AUDIO_H
#define AUDIO_H

#include <SDL2/SDL.h>

class AUDIO
{
    public:

        static bool Init();
        static void ShutDown();

    private:

        static unsigned int SAMPLE_RATE;

        // stream buffer

        static SDL_AudioSpec STREAM_SPEC;
        static void StreamRoutine( void* userdata, Uint8* stream, int length );

};

#endif // AUDIO_H
