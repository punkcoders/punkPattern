#ifndef ROOT_Heart_H
#define ROOT_Heart_H

#include "ROOT_EntryPoint.h" // � virer quand les constantes seront plac�es dans leurs managers respectifs
#include "RGB.h"

#include "ROOT_DeviceManager.h"

/*
INTERFACE FOR MODULE IMPLEMENTATION
You're not supposed to change anything in this class

You can note all these function are only getters and procedures
in order to simplify bindings in javascript, java, objective-c, etc
that's why there are no arguments in functions, pointer getters are used instead
*/

class ROOT_Heart
{
    public:

        // BOOLEAN FOR SMARTPHONE DETECTION ----------------
        static bool SMARTPHONE;

        // OPEN:CLOSE --------------------------------------
        static void Init();
        static bool Exit();
        static void ShutDown();

        // GRAPHICS -----------------------------------
        static unsigned char * GetRGBAddress();
        static int GetScreenWidth();
        static int GetScreenHeight();
        static int GetTextureWidth();
        static int GetTextureHeight();
        static void VideoRoutine();

        // AUDIO ---------------------------------------
        static int GetNumSamplesByBuffer();
        static long* GetSampleRateAddress();
        static long GetSampleRate();
        static float* GetLeftBufferAddress();
        static float* GetRightBufferAddress();
        static void AudioRoutine();

        // FILES -----------------------------------
        static int GetMaxFileSize();
        static char* GetFileNameAddress();
        static char* GetFileBufferAddress();
        static void OnLoaded();
        static void OnLoadError();

        // CONTROLS -----------------------------------
        static char* GetLastKeyPressedAddress();
        static void OnKeyDown();
        static void OnKeyUp();
        static long* GetMouseXAddress();
        static long* GetMouseYAddress();
        static void OnMouseDown();
        static void OnMouseUp();

    private:

        // buffers (� d�placer dans les classes de p�riph�riques) ------------------------------------------

        // audio
        static float LEFT[ROOT_EntryPoint::SAMPLES_BY_AUDIOBUFFER];
        static float RIGHT[ROOT_EntryPoint::SAMPLES_BY_AUDIOBUFFER];
        static long SAMPLE_RATE;

        // file
        static char FILE_NAME[256]; // must be replaced by a fileName buffer
        static char FILE_BUFFER[ROOT_EntryPoint::MAX_FILE_SIZE];

        // controls
        static char LAST_KEY;
        static long MOUSE_X, MOUSE_Y;

};

#endif // ROOT_Heart_H
