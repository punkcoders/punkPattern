#ifndef TEST_H
#define TEST_H

#include "ROOT_DeviceManager.h"
#include "ROOT_EntryPoint.h" // � virer plus tard quand les constantes seront dans leurs managers respectifs
#include "RGB.h"

/*
Simple test for punk framework
*/


class Test
{
    public:

        static void Init();

    private:

        // video test -------------------------------------------------------------------------------------

        static double GREY_PALETTE[16*4];
        static double ROSE_PALETTE[16*4];

        static int TICK;

        static int NUMCOL;
        static int NUMROW;
        static int NUMCELL;

        static void Write(const char* text, int tell);

        static int CURSOR;

        static void ClearText();

        static void TestVideoRoutine();

        // audio test -------------------------------------------------------------------------------------
        static int CUR_SAMPLE;
        static float VOL, FREQ, PAN;
        static void SFX(float freq, float vol, float pan);
        static void OnAudioRoutine();

        //controls test -----------------------------------------------------------------------------------
        static void OnKeyDown();
        static void OnKeyUp();
        static void OnClick();

        // load file test ---------------------------------------------------------------------------------
        static void OnFileError();
        static void OnFileLoaded();


};

#endif // TEST_H
