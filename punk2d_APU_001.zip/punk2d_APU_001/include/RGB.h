#ifndef RGB_H
#define RGB_H

// ------------------------------------------------------
// RENDER GRAPHICS BUFFERS
// ------------------------------------------------------

struct SheetTexture
{
    bool update;
    unsigned char * pixels;
};

struct SheetDraw
{
    unsigned char srcTex;
    unsigned char dstTarget;
    unsigned char srcCol;
    unsigned char srcRow;
    unsigned char dstCol;
    unsigned char dstRow;
    unsigned char numCol;
    unsigned char numRow;
};

struct SpriteBatch
{
    unsigned char numSprites;        // enough to compute buffers lengths
    float * XY;             // verts x/y
    float * UV;             // verts u/v
    unsigned char * PX;     // sprites info texture pixels
};

struct TileMap
{
    unsigned char numCol;
    unsigned char numRow;
    short x;
    short y;
    bool updateMap;
    bool updateScanlines;
    unsigned char * tiles;
    unsigned char * scanlines;
};

class RGB
{
public:

    // DIMENSION MEMORY HERE

    static void InitPointers();
    static void ClearRAM();

    // CONSTANTS AND POINTERS GETTERS

    static unsigned short GetScreenWidth();
    static unsigned short GetScreenHeight();

    static unsigned char * GetPaletteAddress();

    static unsigned short GetSheetResolution();
    static unsigned char GetNumTextures();
    static SheetTexture * GetSheetTexturesAddr();

    static unsigned char GetNumTargetSheets();
    static unsigned short GetMaxSheetDraws();
    static unsigned char * GetNumSheetDrawsAddr();
    static SheetDraw * GetSheetDrawInfoAddr();

    static unsigned char GetNumSpritesBatches();
    static SpriteBatch * GetSpritesBatchesAddr();

    static unsigned char GetNumTilemaps();
    static TileMap * GetTilemapsAddr();

private:

    // CONSTANTS

    static const int SCREEN_WIDTH, SCREEN_HEIGHT;

    static unsigned char T_PALETTE[ 16 * 16 * 4 ];

    static const unsigned short TILESHEET_SIZE;
    static const unsigned char NUM_TEXTURES;
    static SheetTexture TEXTURES[];

    static const unsigned char NUM_TARGET_SHEETS;
    static unsigned char NUM_SHEET_DRAWS;
    static const unsigned short MAX_TARGET_DRAWS;
    static SheetDraw SHEET_DRAWS[];

    static const unsigned char NUM_SPRITES_BATCHES;
    static unsigned char SPRITES_PER_BATCH[];
    static SpriteBatch SPRITES_BATCHES[];

    static const unsigned char NUM_TILE_MAPS;
    static TileMap TILE_MAPS[];

};

#endif // RGB_H
