#ifndef GL_SPRITES_H
#define GL_SPRITES_H

#include <GL/glew.h>

class GL_Sprites
{
public:

    // --------------------------------------------------------------------
    // STATIC SPACE -------------------------------------------------------
    // --------------------------------------------------------------------

    static bool Init();
    static void ShutDown();

    // --------------------------------------------------------------------
    // INSTANCE SPACE -----------------------------------------------------
    // --------------------------------------------------------------------

    GL_Sprites( unsigned short numSprites, float * bufXY, float * bufUV, unsigned char * bufPX );
    ~GL_Sprites();

    void Stream();
    void Draw( GLuint idTexture );

private:

    // --------------------------------------------------------------------
    // STATIC SPACE -------------------------------------------------------
    // --------------------------------------------------------------------

    static bool INIT;
    static unsigned int NUM_INSTANCES;

    // shader & locations

    static const char * VERTEX_SHADER[];
    static const char * FRAGMENT_SHADER[];

    static GLuint VERTEX_SHADER_ID, FRAGMENT_SHADER_ID, SHADER_PROGRAM_ID;

    static GLuint XY_ATTRIB_LOCATION, UV_SHEET_ATTRIB_LOCATION, UV_INFO_ATTRIB_LOCATION;
    static GLuint SHEET_TEXTURE_UNIFORM_LOCATION, PALETTE_TEXTURE_UNIFORM_LOCATION, INFO_TEXTURE_UNIFORM_LOCATION;


    // --------------------------------------------------------------------
    // INSTANCE SPACE -----------------------------------------------------
    // --------------------------------------------------------------------

    unsigned int m_instanceIndex;
    unsigned int m_numSprites;

    // vertex buffer

    float * m_XY;
    GLuint m_XYbufferId;

    float * m_UVsheet;
    GLuint m_UVsheetBufferId;

    GLuint m_UVinfoBufferId;

    GLuint m_IDSbufferId;

    // sprite info id texture

    unsigned char * m_infoTable;
    GLuint m_infoTextureId;

};

#endif // GL_SPRITES_H
