#ifndef GL_TILEMAP_H
#define GL_TILEMAP_H

#include <GL/glew.h>

class GL_Tilemap
{
public:

    // --------------------------------------------------------------------
    // STATIC SPACE -------------------------------------------------------
    // --------------------------------------------------------------------

    static bool Init();
    static void ShutDown();

    // --------------------------------------------------------------------
    // INSTANCE SPACE -----------------------------------------------------
    // --------------------------------------------------------------------

    GL_Tilemap( unsigned char numCol, unsigned char numRow, unsigned char * tiles, unsigned char * scanlines );
    virtual ~GL_Tilemap();

    void Stream( bool tilemap, bool scanlines );
    void Draw( GLuint idTexture, int x, int y, bool blend );

private:

    // --------------------------------------------------------------------
    // STATIC SPACE -------------------------------------------------------
    // --------------------------------------------------------------------

    static bool INIT;
    static unsigned int NUM_INSTANCES;

    // shader & locations

    static const char * VERTEX_SHADER[];
    static const char * FRAGMENT_SHADER[];

    static GLuint VERTEX_SHADER_ID, FRAGMENT_SHADER_ID, SHADER_PROGRAM_ID;

    static GLuint XY_ATTRIB_LOCATION, UV_MAP_ATTRIB_LOCATION;
    static GLuint UV_RATIO_UNIFORM_LOCATION;
    static GLuint SCANLINES_TEXTURE_UNIFORM_LOCATION, MAP_TEXTURE_UNIFORM_LOCATION, SHEET_TEXTURE_UNIFORM_LOCATION, PALETTE_TEXTURE_UNIFORM_LOCATION;

    // vertex buffers

    static float XY[];
    static GLuint XY_BUFFER_ID;

    static unsigned short IDS[];
    static GLuint IDS_BUFFER_ID;

    // --------------------------------------------------------------------
    // INSTANCE SPACE -----------------------------------------------------
    // --------------------------------------------------------------------

    unsigned int m_instanceIndex;

    // precomputed dimensions

    double m_mapHW, m_mapHH; // half with, half height

    // uv buffers

    float m_uvMap[8] = { 0, 2,  2, 2,  2, 0,  0, 0 };
    GLuint m_uvMapBufferId;

    // textures, scanlines and tilemap

    unsigned short m_numScanlines;
    unsigned char * m_scanlines; // infos coded on RGBA
    GLuint m_scanlinesTextureid;

    unsigned char m_numCol, m_numRow;
    unsigned char * m_map; // infos coded on RGBA
    GLuint m_mapTextureId;

};

#endif // GL_TILEMAP_H
