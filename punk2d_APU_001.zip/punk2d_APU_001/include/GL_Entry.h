#ifndef GL_ENTRY_H
#define GL_ENTRY_H

#include <GL/glew.h>

#include "GL_Sheet.h"
#include "GL_Sprites.h"
#include "GL_Tilemap.h"

class GL_Entry
{
public:

    static bool Init();
    static void ShutDown();
    static void VideoRoutine();

    static bool MakeShader( GLuint * vertShaderId, GLuint * fragShaderId, GLuint * shaderProgId, const char * const* vertShader, const char * const* fragShader, const char * shaderName );

    static void UpdatePalette( unsigned char * data );

    // getters

    static unsigned short GetMainTargetWidth();
    static unsigned short GetMainTargetHeight();

    static double GetScaleWidth();
    static double GetScaleHeight();

    static unsigned short GetTileSheetSize();

    static GLuint GetMainTargetBuffer();

    static GLuint GetPaletteTexture();

private:

    static bool CRASHED;

    static int TICK;

    // resolution ----------------------------------------------------------------------

    static unsigned int MAIN_TARGET_WIDTH, MAIN_TARGET_HEIGHT, TILESHEET_SIZE;

    // shader & locations --------------------------------------------------------------

    static const char * VERTEX_SHADER[];
    static const char * FRAGMENT_SHADER[];

    static GLuint VERTEX_SHADER_ID, FRAGMENT_SHADER_ID, SHADER_PROGRAM_ID;

    static GLuint XY_ATTRIB_LOCATION, UV_ATTRIB_LOCATION;
    static GLuint TEXTURE_UNIFORM_LOCATION;

    // GRAPHIC INFO BUFFER -------------------------------------------------------------

    static unsigned char * GFX_BUFFER;

    // MAIN RENDERTARGET ---------------------------------------------------------------

    static GLuint MAIN_TARGET_BUFFER_ID;
    static GLuint MAIN_TARGET_TEXTURE_ID;

    static float MAIN_TARGET_XY[];
    static GLuint MAIN_TARGET_XY_BUFFER_ID;
    static float MAIN_TARGET_UV[];
    static GLuint MAIN_TARGET_UV_BUFFER_ID;
    static unsigned short MAIN_TARGET_IDS[];
    static GLuint MAIN_TARGET_IDS_BUFFER_ID;

    // palette texture

    static GLuint PALETTE_TEXTURE_ID;


    // GRAPHIC OBJECTS -------------------------------------------------------------------

    static bool CreateObjects();
    static void DeleteObjects();
    static void ObjectsRoutine();
    static void ObjectsStreamRoutine();
    static void ObjectsDrawRoutine();

    // instances tables

    static GL_Sheet ** SHEETS;      // the render target tilesheets
    static GL_Sprites ** SPRITES;   // the sprites batches
    static GL_Tilemap ** TILEMAPS;  // the tilemaps

};

#endif // GL_ENTRY_H
