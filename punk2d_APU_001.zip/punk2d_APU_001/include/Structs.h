#ifndef STRUCTS_H_INCLUDED
#define STRUCTS_H_INCLUDED

struct SpriteBatch
{
    unsigned long numSprites;
    unsigned long firstFL; // first float for xy/uv
    unsigned long firstID; // first short for ids
    unsigned long firstPX; // first pixel for info
};

#endif // STRUCTS_H_INCLUDED
