#ifndef GL_SHEET_H
#define GL_SHEET_H

#include <GL/glew.h>

class GL_Sheet
{
public:

    // --------------------------------------------------------------------
    // STATIC SPACE -------------------------------------------------------
    // --------------------------------------------------------------------

    static bool Init( unsigned char numTextures );
    static void ShutDown();

    static void UpdateTexture( unsigned char indexTexture, void * data );
    static GLuint GetTexture( unsigned char indexTexture ); // this debug method will be removed later

    // --------------------------------------------------------------------
    // INSTANCE SPACE -----------------------------------------------------
    // --------------------------------------------------------------------

    GL_Sheet();
    virtual ~GL_Sheet();

    GLuint GetRenderTexture(); // getter used by sprites and tilemaps for render

    // rendering

    void Draw( unsigned char indexTexture, unsigned char srcCol, unsigned char srcRow, unsigned char dstCol, unsigned char dstRow, unsigned char nCol, unsigned char nRow );


private:

    // --------------------------------------------------------------------
    // STATIC SPACE -------------------------------------------------------
    // --------------------------------------------------------------------

    static bool INIT;
    static unsigned int NUM_INSTANCES;

    // shader & locations

    static const char * VERTEX_SHADER[];
    static const char * FRAGMENT_SHADER[];

    static GLuint VERTEX_SHADER_ID, FRAGMENT_SHADER_ID, SHADER_PROGRAM_ID;

    static GLuint XY_ATTRIB_LOCATION, UV_ATTRIB_LOCATION;
    static GLuint TEXTURE_UNIFORM_LOCATION;

    // same vertBuffers for all instances

    static float XY[];
    static GLuint XY_BUFFER_ID;
    static float UV[];
    static GLuint UV_BUFFER_ID;
    static unsigned short IDS[];
    static GLuint IDS_BUFFER_ID;

    // textures table pointer

    static unsigned char NUM_TEXTURES;
    static GLuint * TEXTURES;

    // --------------------------------------------------------------------
    // INSTANCE SPACE -----------------------------------------------------
    // --------------------------------------------------------------------

    unsigned int m_instanceIndex;

    // the renderTarget ---------------------------------------------------

    GLuint m_targetBufferId;
    GLuint m_targetTextureId;

};

#endif // GL_SHEET_H
