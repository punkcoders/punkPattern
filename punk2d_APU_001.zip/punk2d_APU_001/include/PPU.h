#ifndef PPU_H
#define PPU_H

#include "RGB.h"

// INTERFACE FOR GRAPHIC OPERATIONS

class PPU
{
    public:

        // PPU MACHINE EVENTS

        static void Init();
        static void ShutDown();

        static void StartVideoRoutine();
        static void EndVideoRoutine();

        // GRAPHIC INSTRUCTIONS

        static void SetPalette16x( unsigned char y, double * rgba );

        static void UncompressSheet( unsigned long * compressed, unsigned char indexTexture );
        static void DrawInTargetSheet( unsigned char srcTexture, unsigned char dstTarget, unsigned char srcCol, unsigned char srcRow, unsigned char dstCol, unsigned char dstRow, unsigned char numCol, unsigned char numRow );

        static void DrawSprite( unsigned char indexBatch, int x, int y, char nCol, char nRow, char col, char row, bool flipX, bool flipY, unsigned char paletteY );

        static void SetScanline( unsigned char indexTilemap, unsigned short indexScanline, unsigned char offsetX, unsigned char offsetY );
        static void SetTile( unsigned char indexTilemap, unsigned char mapCol, unsigned char mapRow, unsigned char sheetCol, unsigned char sheetRow, unsigned char paletteY, bool flipX );
        static void Scroll( unsigned char indexTilemap, short scrollX, short scrollY );

    private:

        // sprites data

        static unsigned char NUM_BATCHES;
        static unsigned short * NUM_SPRITES_OF_BATCH, * CUR_SPRITE_OF_BATCH;
        static SpriteBatch * SPRITES_BATCHES;
        static double SCALE_WIDTH, SCALE_HEIGHT, TILE_HALFWIDTH, TILE_HALFHEIGHT;

        // tilemaps data

        static unsigned char NUM_TILEMAPS;
        static TileMap * TILEMAPS;
        static unsigned short NUM_SCANLINES;
};

#endif // PPU_H
