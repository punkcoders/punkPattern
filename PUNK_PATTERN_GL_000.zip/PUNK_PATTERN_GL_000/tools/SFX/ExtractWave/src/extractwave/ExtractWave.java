/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package extractwave;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 *
 * @author jeanlouis
 */
public class ExtractWave {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        File file = new File("sounds/A.wav");
        
        System.out.println("file: "+ file);
        
        AudioInputStream str;
        try {
            str = AudioSystem.getAudioInputStream(file);
        } catch (UnsupportedAudioFileException ex) {
            Logger.getLogger(ExtractWave.class.getName()).log(Level.SEVERE, null, ex);
            return;
        } catch (IOException ex) {
            Logger.getLogger(ExtractWave.class.getName()).log(Level.SEVERE, null, ex);
            return;
        }
        
        AudioFormat frt = str.getFormat();
        
        System.out.println("stream: "+frt);
        System.out.println("framerate: "+frt.getFrameRate()+", samplerate: "+frt.getSampleRate());
        System.out.println("chans: "+frt.getChannels());
                
        System.out.println("numFrame: "+str.getFrameLength());
        
        //str.
        int bits = frt.getSampleSizeInBits();
        int bytes = frt.getFrameSize();
        int nFrames = (int)str.getFrameLength();
        
        System.out.println("nFrames & sampleSizeInBits & frameSizeBytes: "+nFrames+" "+bits+" "+bytes);
        
        System.out.println( "big endian: "+ frt.isBigEndian() );
        
        if ( bytes != 2 && frt.getChannels() != 1 )
        {
            System.out.println("only 16 bit mono wave allowed");
            return;
        }
        
        
        byte[] b = new byte[nFrames*bytes];
        try {
            System.out.println( "read: " + str.read(b) );
        } catch (IOException ex) {
            Logger.getLogger(ExtractWave.class.getName()).log(Level.SEVERE, null, ex);
            return;
        }
        
        // reinterpret through a byte buffer
        
        ByteBuffer bb = ByteBuffer.wrap(b);
        bb.order(ByteOrder.LITTLE_ENDIAN);
        ShortBuffer sb = bb.asShortBuffer();
        
        String cppTab = "{";
        
        for (int i = 0; i < nFrames; i++ )
        {
            cppTab += ""+sb.get(i);
            if ( i < nFrames-1 ) cppTab += ",";
        }
        
        cppTab += "};";
        
        
        System.out.println(cppTab);
        
        System.out.println("done");
        
    }
    
}
