/*
ENTRY POINT FOR ALL OPENGL OBJECTS
MUST BY PORTED MANUALLY TO ES & WEBGL
http://punkcoders.free.fr
pukcoders@gmail.com
Code under P.U.N.K. license: Poor Useless Newbie Kidcoding
*/

#include "GL_Entry.h"

#include "RGB.h"

#include <iostream>
using namespace std;

bool GL_Entry::CRASHED = false;

// textures

unsigned int GL_Entry::SCREEN_WIDTH = 1, GL_Entry::SCREEN_HEIGHT = 1;
unsigned int GL_Entry::SCREEN_TEXTURE_WIDTH = 1, GL_Entry::SCREEN_TEXTURE_HEIGHT = 1;
unsigned char * GL_Entry::SCREEN_BUFFER = nullptr, * GL_Entry::SCREEN_TEXTURE_BUFFER = nullptr;
GLuint GL_Entry::SCREEN_TEXTURE_ID;

// vertices

// bon, pour l'instant c'est n'importe quoi.

// faut que je reparte sur un test affichage GL con

float GL_Entry::SCREEN_XY[] = {  -1.0, -1.0, 1.0, -1.0,  1.0, 1.0,  -1.0, 1.0 };
GLuint GL_Entry::SCREEN_XY_BUFFER_ID;
float GL_Entry::SCREEN_UV[] = {   0,  1,  1,  1,  1, 0,   0, 0 };
GLuint GL_Entry::SCREEN_UV_BUFFER_ID;

unsigned short GL_Entry::SCREEN_VERTS_IDS[] = {0,1,2,2,3,0};
GLuint GL_Entry::SCREEN_VERTS_IDS_ID;

// shaders and locations

const char * GL_Entry::VERTEX_SHADER[] =
{
    "#version 330 core                                              \n"
    "                                                               \n"
    "in vec4 aVertexXY;                                             \n"
    "in vec2 aVertexUV;                                             \n"
    "                                                               \n"
    "out vec2 UV;                                                   \n"
    "                                                               \n"
    "void main()                                                    \n"
    "{                                                              \n"
    "   UV = aVertexUV;                                             \n"
    "   gl_Position = aVertexXY;                                    \n"
    "}                                                              \n"
};

const char * GL_Entry::FRAGMENT_SHADER[] =
{
    "#version 330 core                                              \n"
    "                                                               \n"
    "in vec2 UV;                                                    \n"
    "                                                               \n"
    "out vec4 color;                                                \n"
    "                                                               \n"
    "uniform sampler2D uScreenTexture;                              \n"
    "                                                               \n"
    "void main()                                                    \n"
    "{                                                              \n"
    "    color = texture( uScreenTexture, UV ).rgba;                \n"
    "}                                                              \n"
};

GLuint GL_Entry::VERTEX_SHADER_ID, GL_Entry::FRAGMENT_SHADER_ID, GL_Entry::SHADER_PROGRAM_ID;

GLuint GL_Entry::XY_ATTRIB_LOCATION, GL_Entry::UV_ATTRIB_LOCATION;
GLuint GL_Entry::TEXTURE_UNIFORM_LOCATION;


bool GL_Entry::Init()
{
    cout << "init GLEW" << endl;

    // init glew

    GLenum err = glewInit();


    if (GLEW_OK != err)
    {
        cout << "unable to init glew" << endl;
        return 0;
    }
    cout << "OpenGL Version: " << glGetString(GL_VERSION) << endl;

    // CREATE SHADERS FIRST ----------------------------------------------

    // create the vertex shader

    VERTEX_SHADER_ID = glCreateShader(GL_VERTEX_SHADER);
    cout << "compile vertex shader: " << endl;
    glShaderSource(VERTEX_SHADER_ID,1,VERTEX_SHADER,nullptr);
    glCompileShader(VERTEX_SHADER_ID);
    cout << "check vertex shader: " << endl;
    GLint result;
    glGetShaderiv(VERTEX_SHADER_ID, GL_COMPILE_STATUS, &result);
    if ( result )
    {
       cout << "vertex shader compiled" << endl;
    }
    else
    {
        cout << "cannot compile vertex shader" << endl;
        glDeleteShader(VERTEX_SHADER_ID);
        CRASHED = true;
        return false;
    }

    // create the fragment shader

    FRAGMENT_SHADER_ID = glCreateShader(GL_FRAGMENT_SHADER);
    cout << "compile fragment shader: " << endl;
    glShaderSource(FRAGMENT_SHADER_ID,1,FRAGMENT_SHADER,nullptr);
    glCompileShader(FRAGMENT_SHADER_ID);
    cout << "check fragment shader: " << endl;
    glGetShaderiv(FRAGMENT_SHADER_ID, GL_COMPILE_STATUS, &result);
    if ( result )
    {
       cout << "fragment shader compiled" << endl;
    }
    else
    {
        // FOUTRE ICI LE RENVOI D'ERREUR

        glDeleteShader(GL_FRAGMENT_SHADER);

        cout << "cannot compile fragment shader" << endl;
        CRASHED = true;
        return false;
    }

    // link the program shader

    cout << "link shaders program" << endl;
    SHADER_PROGRAM_ID = glCreateProgram();
    glAttachShader(SHADER_PROGRAM_ID,VERTEX_SHADER_ID);
    glAttachShader(SHADER_PROGRAM_ID,FRAGMENT_SHADER_ID);
    glLinkProgram(SHADER_PROGRAM_ID);
    cout << "check shaders program" << endl;
    glGetProgramiv(SHADER_PROGRAM_ID, GL_LINK_STATUS, &result);
    if ( result )
    {
       cout << "shaders program linked" << endl;
    }
    else
    {
        glDetachShader(SHADER_PROGRAM_ID,VERTEX_SHADER_ID);
        glDetachShader(SHADER_PROGRAM_ID,FRAGMENT_SHADER_ID);
        cout << "cannot link shaders program" << endl;
        CRASHED = true;
        return false;
    }

    // get locations

    XY_ATTRIB_LOCATION = glGetAttribLocation(SHADER_PROGRAM_ID,"aVertexXY");
    UV_ATTRIB_LOCATION = glGetAttribLocation(SHADER_PROGRAM_ID,"aVertexUV");
    TEXTURE_UNIFORM_LOCATION = glGetUniformLocation(SHADER_PROGRAM_ID,"uScreenTexture");

    cout << "XY attr loc: " << XY_ATTRIB_LOCATION << endl;
    cout << "UV attr loc: " << UV_ATTRIB_LOCATION << endl;



    // CREATE DATA NEXT ----------------------------------------------

    // checks
    GLint dims[4] = {0};
    glGetIntegerv(GL_VIEWPORT, dims);
    GLint fbWidth = dims[2];
    GLint fbHeight = dims[3];
    cout << "framebuffer ddimensions : " << fbWidth << "," << fbHeight << endl;

    // THE SCREEN RESOLUTION

    cout << "RGB SCREEN RESOLUTION: " << *RGB::SCREEN_WIDTH << " x " << *RGB::SCREEN_HEIGHT << endl;

    SCREEN_WIDTH = *RGB::SCREEN_WIDTH;
    SCREEN_HEIGHT = *RGB::SCREEN_HEIGHT;

    // get dimensions of tables

    while ( SCREEN_TEXTURE_WIDTH < SCREEN_WIDTH )
    {
        SCREEN_TEXTURE_WIDTH <<= 1;
    }
    cout << "screen texture width: " << SCREEN_TEXTURE_WIDTH << endl;

    while ( SCREEN_TEXTURE_HEIGHT < SCREEN_HEIGHT )
    {
        SCREEN_TEXTURE_HEIGHT <<= 1;
    }
    cout << "screen texture width: " << SCREEN_TEXTURE_HEIGHT << endl;

    // create tables

    SCREEN_BUFFER = (unsigned char *)RGB::SCREEN_PIXELS ;//(unsigned char *)dataBuffer;
    SCREEN_TEXTURE_BUFFER = new unsigned char[SCREEN_TEXTURE_WIDTH*SCREEN_TEXTURE_HEIGHT*4];

    // dimension UV on subImage

    float uW = (double)SCREEN_WIDTH / (double)SCREEN_TEXTURE_WIDTH;
    float uH = (double)SCREEN_HEIGHT / (double)SCREEN_TEXTURE_HEIGHT;
    SCREEN_UV[1]=uH;
    SCREEN_UV[2]=uW;
    SCREEN_UV[3]=uH;
    SCREEN_UV[4]=uW;

    // create the texture

    glCreateTextures(GL_TEXTURE_2D,1,&SCREEN_TEXTURE_ID);
    glBindTexture(GL_TEXTURE_2D, SCREEN_TEXTURE_ID);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, SCREEN_TEXTURE_WIDTH, SCREEN_TEXTURE_HEIGHT, 0, GL_RGBA, GL_UNSIGNED_BYTE, SCREEN_TEXTURE_BUFFER);

    // create the vertices

    glGenBuffers(1,&SCREEN_XY_BUFFER_ID);
    glGenBuffers(1,&SCREEN_UV_BUFFER_ID);
    glGenBuffers(1,&SCREEN_VERTS_IDS_ID);

    glBindBuffer(GL_ARRAY_BUFFER, SCREEN_XY_BUFFER_ID);
    glBufferData(GL_ARRAY_BUFFER, sizeof(SCREEN_XY), SCREEN_XY, GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, SCREEN_UV_BUFFER_ID);
    glBufferData(GL_ARRAY_BUFFER, sizeof(SCREEN_UV), SCREEN_UV, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, SCREEN_VERTS_IDS_ID);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(SCREEN_VERTS_IDS), SCREEN_VERTS_IDS, GL_STATIC_DRAW);


    return true;
}

void GL_Entry::ShutDown()
{
    // delete the shaders

    if (!CRASHED)
    {
        glDetachShader(SHADER_PROGRAM_ID,VERTEX_SHADER_ID);
        glDetachShader(SHADER_PROGRAM_ID,FRAGMENT_SHADER_ID);
        glDeleteShader(VERTEX_SHADER_ID);
        glDeleteShader(FRAGMENT_SHADER_ID);
        cout << "shaders deleted" << endl;
    }

    // delete the vertices

    glDeleteBuffers(1,&SCREEN_VERTS_IDS_ID);
    glDeleteBuffers(1,&SCREEN_XY_BUFFER_ID);

    cout << "vertices deleted" << endl;

    // delete the texture
    glDeleteTextures(1, &SCREEN_TEXTURE_ID);
    cout << "textures deleted" << endl;

    // delete table
    delete SCREEN_TEXTURE_BUFFER;
    SCREEN_TEXTURE_BUFFER = nullptr;
    cout << "textures data deleted" << endl;

}

void GL_Entry::VideoRoutine()
{
    if ( CRASHED )
    {
        return;
    }

    //glRenderMode(GL_1PASS_EXT);

    // clear screen

    glClearColor(0,0,1,1);
    glClear(GL_COLOR_BUFFER_BIT);

    // draw VGA-like screen

    // stream texture data to GPU

    glBindTexture(GL_TEXTURE_2D, SCREEN_TEXTURE_ID);
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, GL_RGBA, GL_UNSIGNED_BYTE, SCREEN_BUFFER );

    // bind textures and vertices

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D,SCREEN_TEXTURE_ID);
    glUniform1i(TEXTURE_UNIFORM_LOCATION,0);

    glBindBuffer(GL_ARRAY_BUFFER, SCREEN_XY_BUFFER_ID );
    glVertexAttribPointer(XY_ATTRIB_LOCATION,2,GL_FLOAT,GL_FALSE,0,(void*)0);
    glEnableVertexAttribArray(XY_ATTRIB_LOCATION);

    glBindBuffer(GL_ARRAY_BUFFER, SCREEN_UV_BUFFER_ID );
    glVertexAttribPointer(UV_ATTRIB_LOCATION,2,GL_FLOAT,GL_FALSE,0,(void*)0);
    glEnableVertexAttribArray(UV_ATTRIB_LOCATION);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,SCREEN_VERTS_IDS_ID);



    // ----------------------------------------------------------------
    // test where is the coords bug
    // ----------------------------------------------------------------

    glBindTexture(GL_TEXTURE_2D, SCREEN_TEXTURE_ID);
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, GL_RGBA, GL_UNSIGNED_BYTE, SCREEN_BUFFER );


    // select shader program and draw

    // cout << "draw ";

    glUseProgram(SHADER_PROGRAM_ID);
    glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0 );

    // free attrib arrays

    glDisableVertexAttribArray(XY_ATTRIB_LOCATION);
    glDisableVertexAttribArray(UV_ATTRIB_LOCATION);

    // end
}
