#include "Test.h"

#include "RGB.h"

#include <string.h>
#include <iostream>
using namespace std;

// build & delete ----------------------------------------------------------------

void Test::Init()
{
    // events callbacks

    ROOT_DeviceManager::SetVideoRoutine(TestVideoRoutine);
    ROOT_DeviceManager::SetAudioRoutine(OnAudioRoutine);
    ROOT_DeviceManager::SetKeyDownEvent(OnKeyDown);
    ROOT_DeviceManager::SetKeyUpEvent(OnKeyUp);
    ROOT_DeviceManager::SetMouseDownEvent(OnClick);
    ROOT_DeviceManager::SetMouseUpEvent(OnClick);
    ROOT_DeviceManager::SetFileErrorEvent(OnFileError);
    ROOT_DeviceManager::SetFileLoadedEvent(OnFileLoaded);

    // initialize data in Render Graphics Buffer

    *RGB::SCREEN_WIDTH = ROOT_EntryPoint::SCREEN_WIDTH;
    *RGB::SCREEN_HEIGHT = ROOT_EntryPoint::SCREEN_HEIGHT;

    // start tests

    const char* lowlevel = "Press 1/2/3 to load a file.";
    CURSOR = 19;
    Write((char*)lowlevel, 0);
    CUR_SAMPLE = 0;
    VOL = 0.0f;
    FREQ = 132.0f;
    PAN = 0.0f;
}

// TEST VIDEO -------------------------------------------------------------

int Test::TICK = 0;
unsigned char Test::TILESHEET[256*8] = {0,0,0,0,0,0,0,0,126,129,165,129,189,153,129,126,126,255,153,195,231,231,231,102,60,126,126,126,189,219,90,60,8,28,62,127,62,28,8,0,60,126,255,255,255,126,24,60,60,126,126,126,126,60,24,60,0,0,24,60,60,24,0,0,255,255,231,195,195,231,255,255,0,60,102,66,66,102,60,0,255,195,153,189,189,153,195,255,0,240,224,176,30,51,51,30,60,102,102,60,24,60,24,0,252,204,252,12,12,14,15,7,60,102,126,102,102,102,195,0,10,110,32,107,2,59,40,0,12,28,60,124,124,60,28,12,48,56,60,62,62,60,56,48,24,60,126,24,24,126,60,24,102,102,102,102,102,0,102,0,254,219,219,222,216,216,216,0,124,198,28,54,54,28,51,30,0,0,0,126,126,126,126,0,24,60,126,126,255,126,24,60,24,60,126,126,90,24,24,60,24,24,24,24,126,60,24,0,0,48,112,255,255,112,48,0,0,12,14,255,255,14,12,0,0,0,3,3,3,127,0,0,0,36,102,255,102,36,0,0,128,192,224,240,248,252,254,255,0,1,3,7,15,31,63,127,0,0,0,0,0,0,0,0,12,30,30,12,12,0,12,0,0,54,54,20,0,0,0,0,54,54,127,54,127,54,54,0,112,248,248,112,14,31,31,14,0,99,51,24,12,102,99,0,28,54,28,110,59,51,110,0,0,24,28,12,0,0,0,0,24,12,6,6,6,12,24,0,6,12,24,24,24,12,6,0,0,102,60,255,60,102,0,0,24,126,24,0,24,126,24,0,0,0,0,0,24,28,12,0,0,0,0,62,0,0,0,0,0,0,0,0,24,24,0,0,96,48,24,12,6,3,1,0,62,99,115,123,111,103,62,0,12,14,12,12,12,12,63,0,30,51,48,28,6,51,63,0,30,51,48,28,48,51,30,0,56,60,54,51,127,48,120,0,63,3,31,48,48,51,30,0,28,6,3,31,51,51,30,0,63,51,48,24,12,12,12,0,30,51,51,30,51,51,30,0,30,51,51,62,48,24,14,0,0,12,12,0,0,12,12,0,0,12,12,0,0,12,14,6,0,96,96,120,120,126,126,0,0,0,62,0,0,62,0,0,0,126,126,120,120,96,96,0,30,51,48,24,12,0,12,0,126,255,153,195,231,231,231,102,12,30,51,51,63,51,51,0,63,102,102,62,102,102,63,0,60,102,3,3,3,102,60,0,31,54,102,102,102,54,31,0,127,70,22,30,22,70,127,0,127,70,22,30,22,6,15,0,60,102,3,3,115,102,124,0,51,51,51,63,51,51,51,0,30,12,12,12,12,12,30,0,120,48,48,48,51,51,30,0,103,102,54,30,54,102,103,0,15,6,6,6,70,102,127,0,99,119,127,127,107,99,99,0,99,103,111,123,115,99,99,0,28,54,99,99,99,54,28,0,63,102,102,62,6,6,15,0,30,51,51,51,59,30,56,0,63,102,102,62,54,102,103,0,30,51,6,12,24,51,30,0,63,45,12,12,12,12,30,0,51,51,51,51,51,51,63,0,51,51,51,51,51,30,12,0,99,99,99,107,127,119,99,0,0,99,54,28,28,54,99,0,51,51,51,30,12,12,30,0,127,99,49,24,76,102,127,0,30,6,6,6,6,6,30,0,3,6,12,24,48,96,64,0,30,24,24,24,24,24,30,0,8,28,54,99,0,0,0,0,0,0,0,0,0,0,0,255,0,12,28,24,0,0,0,0,0,0,30,48,62,51,110,0,7,6,6,62,102,102,59,0,0,0,30,51,3,51,30,0,56,48,48,62,51,51,110,0,0,0,30,51,63,3,30,0,28,54,6,15,6,6,15,0,0,0,110,51,51,62,48,31,7,6,54,110,102,102,103,0,12,0,14,12,12,12,30,0,48,0,48,48,48,51,51,30,7,6,102,54,30,54,103,0,14,12,12,12,12,12,30,0,0,0,51,127,127,107,99,0,0,0,31,51,51,51,51,0,0,0,30,51,51,51,30,0,0,0,59,102,102,62,6,15,0,0,110,51,51,62,48,120,0,0,59,110,102,6,15,0,0,0,62,3,30,48,31,0,8,12,62,12,12,44,24,0,0,0,51,51,51,51,110,0,0,0,51,51,51,30,12,0,0,0,99,107,127,127,54,0,0,0,99,54,28,54,99,0,0,0,51,51,51,62,48,31,0,0,63,25,12,38,63,0,56,12,12,7,12,12,56,0,24,24,24,0,24,24,24,0,7,12,12,56,12,12,7,0,0,0,12,158,242,96,0,0,0,8,28,54,99,99,127,0,30,51,3,51,30,24,48,30,0,51,0,51,51,51,126,0,56,0,30,51,63,3,30,0,126,195,60,96,124,102,252,0,51,0,30,48,62,51,126,0,7,0,30,48,62,51,126,0,12,12,30,48,62,51,126,0,0,0,30,3,3,30,48,28,126,195,60,102,126,6,60,0,51,0,30,51,63,3,30,0,7,0,30,51,63,3,30,0,51,0,14,12,12,12,30,0,62,99,28,24,24,24,60,0,7,0,14,12,12,12,30,0,99,28,54,99,127,99,99,0,12,12,0,30,51,63,51,0,56,0,63,6,30,6,63,0,0,0,254,48,254,51,254,0,0,0,0,119,99,99,127,0,30,51,0,30,51,51,30,0,0,51,0,30,51,51,30,0,3,6,0,30,51,51,30,0,30,51,0,51,51,51,126,0,0,7,0,51,51,51,126,0,0,51,0,51,51,62,48,31,195,24,60,102,102,60,24,0,51,0,51,51,51,51,30,0,24,24,126,3,3,126,24,24,28,54,38,15,6,38,63,0,51,51,30,63,12,63,12,12,31,51,51,95,99,243,99,227,112,216,24,60,24,24,27,14,56,0,30,48,62,51,126,0,28,0,14,12,12,12,30,0,48,24,0,30,51,51,30,0,0,56,0,51,51,51,126,0,0,31,0,31,51,51,51,0,63,0,51,55,63,59,51,0,60,54,54,124,0,126,0,0,28,54,54,28,0,62,0,0,12,0,12,6,3,51,30,0,0,0,0,30,51,3,0,0,0,0,0,30,51,48,0,0,195,99,51,123,204,102,51,240,195,99,51,219,236,246,243,192,24,24,0,24,60,60,60,24,0,204,102,51,102,204,0,0,0,51,102,204,102,51,0,0,68,17,68,17,68,17,68,17,170,85,170,85,170,85,170,85,221,119,221,119,221,119,221,119,24,24,24,24,24,24,24,24,24,24,16,31,31,16,24,24,24,31,31,31,31,31,24,24,124,124,124,127,127,124,124,124,0,0,0,56,124,124,124,124,0,15,31,31,31,31,24,24,124,127,127,127,127,127,124,124,124,124,124,124,124,124,124,124,0,63,127,127,127,127,124,124,124,127,127,127,127,63,0,0,124,124,124,124,124,56,0,0,24,31,31,31,31,15,0,0,0,0,0,15,31,24,24,24,24,24,24,248,240,0,0,0,24,24,24,219,255,0,0,0,0,0,0,255,219,24,24,24,24,24,8,248,248,8,24,24,0,0,0,255,255,0,0,0,24,24,24,255,255,24,24,24,24,248,248,248,248,248,24,24,124,124,124,252,252,124,124,124,124,252,252,252,252,248,0,0,0,248,252,252,252,252,124,124,124,255,255,255,255,255,0,0,0,255,255,255,255,255,124,124,124,252,252,252,252,252,124,124,0,255,255,255,255,255,0,0,124,255,255,255,255,255,124,124,24,255,255,255,255,255,0,0,108,108,108,108,254,0,0,0,0,254,254,254,254,254,254,68,0,0,0,0,254,108,108,108,124,124,124,124,124,56,0,0,0,240,248,248,248,240,0,0,0,240,248,248,248,240,0,0,0,0,0,56,124,124,124,124,124,124,124,255,255,124,124,124,24,255,255,255,255,255,24,24,24,24,24,31,15,0,0,0,0,0,0,240,248,24,24,24,255,255,255,255,255,255,255,255,0,0,0,0,255,255,255,255,15,15,15,15,15,15,15,15,240,240,240,240,240,240,240,240,255,255,255,255,0,0,0,0,0,0,110,59,19,59,110,0,0,30,51,31,51,31,3,3,0,63,51,3,3,3,3,0,0,127,54,54,54,54,54,0,63,51,6,12,6,51,63,0,0,0,126,27,27,27,14,0,0,102,102,102,102,62,6,3,0,0,110,59,24,24,24,60,63,12,30,51,51,30,12,63,60,126,66,126,126,126,66,0,28,54,99,99,54,54,119,0,56,12,24,62,51,51,30,0,0,0,60,126,126,126,60,0,96,48,126,219,219,126,6,3,28,6,3,31,3,6,28,0,60,102,102,102,102,102,102,0,0,62,62,62,62,62,62,0,12,12,63,12,12,0,63,0,6,12,24,12,6,0,63,0,24,12,6,12,24,0,63,0,126,255,255,255,255,255,219,60,24,24,24,24,24,27,27,14,255,195,153,195,189,195,189,195,12,158,242,96,14,159,249,112,0,0,28,54,54,28,0,0,0,0,0,24,24,0,0,0,0,0,0,0,24,0,0,0,96,96,48,48,27,27,14,0,0,0,60,102,102,102,0,0,28,60,48,28,0,0,0,0,0,60,60,60,60,60,0,0,0,0,0,0,0,0,0,0};
unsigned long Test::PALETTE[2] = {0xff003300,0xffccffcc};
unsigned char Test::SCANLINE_BUFFER[512];
unsigned char Test::TEXT[Test::NUMCELL];
Test::Sprite Test::SPRITERAM[Test::NUM_SPRITES];
Test::ScanlineSprites Test::SCANLINE_SPRITES_TABLE[ROOT_EntryPoint::SCREEN_HEIGHT];
unsigned char Test::SCANLINE_NUM_SPRITES_TABLE[ROOT_EntryPoint::SCREEN_HEIGHT];
int Test::CURSOR = 0;

void Test::Write(const char* text, int cell)
{
    for (int i=0; text[i]; i++)
    {
        TEXT[(i + cell)%NUMCELL] = text[i];
    }
}
void Test::StoreSpritesInScanlines(int startY, int stopY)
{
    if (startY>stopY)
        return;
    // clear
    memset(SCANLINE_NUM_SPRITES_TABLE+startY,0,stopY-startY);
    // store
    ScanlineSprites* sl_sprites = SCANLINE_SPRITES_TABLE;
    unsigned char* sl_numSprites = SCANLINE_NUM_SPRITES_TABLE;
    int sp_max = MAX_SPRITE_PER_SCANLINE, nSprites = NUM_SPRITES, y1, y2, y;
    Sprite* s;
    unsigned char iSprite;
    for (iSprite=0; iSprite<nSprites; iSprite++)
    {
        s = SPRITERAM + iSprite;
        if (s->flags&1) // first bit flag: sprite is visible
        {
            // Y limits
            y1 = s->y;
            y2 = y1 + 8;
            if (y1<startY)
                y1 = startY;
            if (y2>stopY)
                y2 = stopY;
            for (y=y1; y<y2; y++)
            {
                if (sl_numSprites[y]<sp_max) // maximum sprite per scanline
                {
                    (sl_sprites+y)->sprites[ sl_numSprites[y] ] = iSprite;
                    sl_numSprites[y]++;
                }
            }
        }
    }
}
void Test::DrawScanLine(int y)
{
    // common for the 3 steps
    const int _1=1;
    int pixRow = 0;
    unsigned char * slb = SCANLINE_BUFFER + 8;
    {
        //common vars to tiles and sprites
        const int _0=0, _3=3, _8=8;
        unsigned char * tsh = TILESHEET, * stopSlb = NULL;

        // step1: draw tilemap
        {
            int localY = y & 7;
            const int nCol = NUMCOL;
            unsigned char tileIndex, * txt = TEXT + (y/_8*nCol);
            for(int c=_0; c<nCol; c++) // optimize this loop
            {
                tileIndex = txt[c]; // read character
                pixRow = tsh[(tileIndex<<_3)+localY]; // get pixel row
                stopSlb = slb + _8;
                while (slb<stopSlb)
                {
                    *slb = pixRow & _1;
                    slb += _1;
                    pixRow >>= _1;
                }
            }
        }
        // step 2: draw sprites
        {
            unsigned char numSprites = SCANLINE_NUM_SPRITES_TABLE[y], * spritesIndexes = SCANLINE_SPRITES_TABLE[y].sprites, * startSlb = SCANLINE_BUFFER + _8;
            Sprite* s;
            for(int i=_0; i<numSprites; i++) // optimize this loop
            {
                s = SPRITERAM + spritesIndexes[i];
                slb = startSlb + (s->x);
                stopSlb = slb + _8;
                pixRow = tsh[(s->tile<<_3)+(y - s->y)];
                while ( slb < stopSlb ) // render
                {
                    if (pixRow & _1)
                        *slb = _1;
                    slb += _1;
                    pixRow >>= _1;
                }
            }
        }

    }
    // step3: draw palette
    {
        const int sw = ROOT_EntryPoint::SCREEN_WIDTH;
        unsigned long * pal = PALETTE, * locScr = (unsigned long *)RGB::SCREEN_PIXELS + y*sw;
        slb = SCANLINE_BUFFER + 8;
        int i=0;
        while(i<sw) // optimize this loop
        {
            locScr[i] = pal[slb[i]];
            i+=_1;
        }
    }

}
void Test::TestVideoRoutine()
{
    // write if smartphone detected
    if ( ROOT_Heart::SMARTPHONE )
    {
        Write("smartphone detected",NUMCOL*2);
    }

    // text cursor sprite
    Sprite* sp = SPRITERAM + 0;
    sp->x = (CURSOR) % NUMCOL * 8;
    sp->y = (CURSOR) / NUMCOL * 8;
    sp->tile = 1;
    sp->flags = (TICK>>4)&1; // visible

    // mouse cursor sprite
    sp = SPRITERAM + 1;
    sp->x = ROOT_DeviceManager::GetMouseX()-4;
    sp->y = ROOT_DeviceManager::GetMouseY()-4;
    sp->tile = *"x";
    sp->flags = 1; // visible

    // draw subscreens
    StoreSpritesInScanlines(0,ROOT_EntryPoint::SCREEN_HEIGHT);
    for(int y=0; y<ROOT_EntryPoint::SCREEN_HEIGHT; y++)
    {
        DrawScanLine(y);
    }
    TICK++;
}

// TEST AUDIO -------------------------------------------------------------

int Test::CUR_SAMPLE = 0;
float Test::VOL, Test::PAN, Test::FREQ;

void Test::SFX(float freq, float vol, float pan)
{
    VOL = vol;
    FREQ = freq;
    PAN = pan;
}

void Test::OnAudioRoutine()
{
    // stereo buffers ponters
    float* leftBuffer = ROOT_DeviceManager::GetLeftBufferAddress();
    float* rightBuffer = ROOT_DeviceManager::GetRightBufferAddress();
    // compute frequency
    float halfPeriod = ROOT_DeviceManager::GetSampleRate()/FREQ/2;
    // compute panoramic
    float vol = VOL;
    float leftVol = 0.02f * (-.5f*PAN+.5f);
    float rightVol = 0.02f * (.5f*PAN+.5f);
    // square wav
    int nSamples = ROOT_EntryPoint::SAMPLES_BY_AUDIOBUFFER;
    int cs = CUR_SAMPLE;
    float curveY;
    for (int i = 0; i<nSamples; i++ )
    {
        // compute curve
        curveY = (((int)((i+cs)/halfPeriod)&1)*2+1)*vol;
        vol *= 0.9999f;
        // write in buffers
        leftBuffer[i] = curveY*leftVol;
        rightBuffer[i] = curveY*rightVol;
    }
    VOL = vol;
    CUR_SAMPLE += nSamples;
}

// TEST FILES -------------------------------------------------------------

void Test::OnFileError()
{
    Write("FILE ERROR !                    ",0);
}
void Test::OnFileLoaded()
{
    memset(TEXT,0,NUMCELL);
    char* buffer = (char *)( ROOT_DeviceManager::GetFileBufferAddress() );
    Write( buffer, 0 );
}

// TEST KEYBOARD AND MOUSE ------------------------------------------------

void Test::OnKeyDown()
{
    char c[2]; // make a null terminated string to copy in text buffer
    c[0] = ROOT_DeviceManager::GetLastKeyChanged();
    c[1] = 0;

    cout << (int)c[0] << endl;

    Write( c, CURSOR);
    CURSOR = (CURSOR + 1)% NUMCELL;
    SFX(132.0f,1,(float)(CURSOR%NUMCOL)/(float)NUMCOL*2.0-1.0); // play a C

    if (c[0]>=49 && c[0]<=51)
    {
        memset(TEXT,0,NUMCELL);
        Write("LOADING...",0);
    }
    switch (c[0])
    {
    case 49:
        ROOT_DeviceManager::LoadFile("files/Game1.txt");
        break;
    case 50:
        ROOT_DeviceManager::LoadFile("files/Game2.txt");
        break;
    case 51:
        ROOT_DeviceManager::LoadFile("files/Game3.txt");
        break;
    case 27:
        ROOT_DeviceManager::Exit();
        break;
    }
}
void Test::OnKeyUp()
{
    SFX(132.0f*2,1,(float)(CURSOR%NUMCOL)/(float)NUMCOL*2.0-1.0 ); // play a C
}
void Test::OnClick()
{
    int col = (ROOT_DeviceManager::GetMouseX() >> 3)%NUMCOL;
    int row = (ROOT_DeviceManager::GetMouseY() >> 3)%NUMROW;
    CURSOR = col + NUMCOL*row;
}

