#include <emscripten.h>
#include "ROOT_Heart.h"

#include <iostream>
using namespace std;

int main()
{
    ROOT_Heart::Init();
    EM_ASM( main() );
    return 0;
}
EMSCRIPTEN_KEEPALIVE bool GetExit(){return ROOT_Heart::Exit();}
EMSCRIPTEN_KEEPALIVE void ExitApp(){ROOT_Heart::ShutDown();}

// boolean for smartphone context ---------------------------------------------------------------
EMSCRIPTEN_KEEPALIVE bool * GetSmartphoneBoolAddress(){return &ROOT_Heart::SMARTPHONE;}

// video ----------------------------------------------------------------------------------------
EMSCRIPTEN_KEEPALIVE unsigned char * GetRGBAddress(){return ROOT_Heart::GetRGBAddress();}
EMSCRIPTEN_KEEPALIVE void VideoRoutine(){ROOT_Heart::VideoRoutine();}

// audio ----------------------------------------------------------------------------------------
EMSCRIPTEN_KEEPALIVE int GetNumSamplesByBuffer(){return ROOT_Heart::GetNumSamplesByBuffer();}
EMSCRIPTEN_KEEPALIVE long* GetSampleRateAddress(){return ROOT_Heart::GetSampleRateAddress();}
EMSCRIPTEN_KEEPALIVE long GetSampleRate(){return ROOT_Heart::GetSampleRate();}
EMSCRIPTEN_KEEPALIVE float* GetLeftBufferAddress(){return ROOT_Heart::GetLeftBufferAddress();}
EMSCRIPTEN_KEEPALIVE float* GetRightBufferAddress(){return ROOT_Heart::GetRightBufferAddress();}
EMSCRIPTEN_KEEPALIVE void AudioRoutine(){ROOT_Heart::AudioRoutine();}

// files ----------------------------------------------------------------------------------------
EMSCRIPTEN_KEEPALIVE int GetMaxFileSize(){return ROOT_Heart::GetMaxFileSize();}
EMSCRIPTEN_KEEPALIVE char* GetFileNameAddress(){return ROOT_Heart::GetFileNameAddress();}
EMSCRIPTEN_KEEPALIVE char* GetFileBufferAddress(){return ROOT_Heart::GetFileBufferAddress();}
EMSCRIPTEN_KEEPALIVE void OnLoaded(){return ROOT_Heart::OnLoaded();}
EMSCRIPTEN_KEEPALIVE void OnLoadError(){return ROOT_Heart::OnLoadError();}

// controls -------------------------------------------------------------------------------------
EMSCRIPTEN_KEEPALIVE char* GetLastKeyPressedAddress(){return ROOT_Heart::GetLastKeyPressedAddress();}
EMSCRIPTEN_KEEPALIVE void OnKeyDown(){ROOT_Heart::OnKeyDown();}
EMSCRIPTEN_KEEPALIVE void OnKeyUp(){ROOT_Heart::OnKeyUp();}
EMSCRIPTEN_KEEPALIVE long* GetMouseXAddress(){return ROOT_Heart::GetMouseXAddress();}
EMSCRIPTEN_KEEPALIVE long* GetMouseYAddress(){return ROOT_Heart::GetMouseYAddress();}
EMSCRIPTEN_KEEPALIVE void OnMouseDown(){ROOT_Heart::OnMouseDown();}
EMSCRIPTEN_KEEPALIVE void OnMouseUp(){ROOT_Heart::OnMouseUp();}
