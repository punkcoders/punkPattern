#include "RGB.h"

#include <iostream>
using namespace std;

// Render Graphics Buffer

// memory

unsigned char RGB::BUFFER[ BUFFER_SIZE ];

// init pointers

void RGB::InitPointers()
{
    cout << ":::: INIT RGB POINTERS ::::" << endl;

    unsigned char * a = BUFFER;

    SCREEN_WIDTH = (unsigned short *)a;
    a += 2;
    SCREEN_HEIGHT = (unsigned short *)a;
    a += 2;

    SCREEN_PIXELS = a;
    a += 4 * 240 * 160;
}

// all pointers here

unsigned short * RGB::SCREEN_WIDTH, * RGB::SCREEN_HEIGHT;

unsigned char * RGB::SCREEN_PIXELS;
