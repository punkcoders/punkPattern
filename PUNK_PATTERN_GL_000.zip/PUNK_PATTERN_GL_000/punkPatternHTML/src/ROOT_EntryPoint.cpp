#include "ROOT_EntryPoint.h"
#include "Test.h"

#include <iostream>
using namespace std;

void ROOT_EntryPoint::Main()
{
    // YOUR CODE STARTS HERE -------------------------------------------------------------

    Test::Init(); // class Testing the ROOT_DeviceManager. quote and replace by your app / game

    // see: /docs/ROOT_DeviceManager.html

    cout << "INIT PUNK PATTERN" << endl;
}

void ROOT_EntryPoint::Exit()
{
    // calls when program exits. deallocate here

    cout << "EXIT PUNK PATTERN" << endl;

}
