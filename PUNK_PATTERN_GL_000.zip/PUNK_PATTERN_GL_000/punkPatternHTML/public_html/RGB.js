// Render Graphics Buffer

function RGB()
{
    // static class
}

// init pointers

RGB.InitPointers = function( b )
{
    console.log( ":::: TRANSLATE RGB POINTERS TO JAVASCRIPT ::::" );

    let a = __Z13GetRGBAddressv();

    RGB.SCREEN_DIMENSIONS = new Uint16Array( b, a, 2 );
    a += 2;
    a += 2;

    RGB.SCREEN_PIXELS = new Uint8ClampedArray( b, a, 4 * 240 * 160 );
    a += 4 * 240 * 160;
};

RGB.ShutdownPointers = function()
{
    RGB.SCREEN_DIMENSIONS=null;  
    
    RGB.SCREEN_PIXELS=null;
};

// all pointers here

RGB.SCREEN_DIMENSIONS=null;

RGB.SCREEN_PIXELS=null;
