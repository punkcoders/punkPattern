/*
ENTRY POINT FOR ALL WEBGL OBJECTS
MUST BY PORTED MANUALLY TO ES & OPENGL
http://punkcoders.free.fr
pukcoders@gmail.com
Code under P.U.N.K. license: Poor Useless Newbie Kidcoding
*/

function GL_Entry()
{
    // static class, no constructor
}

GL_Entry.CRASHED = false;

// textures

GL_Entry.SCREEN_WIDTH = 1, GL_Entry.SCREEN_HEIGHT = 1;
GL_Entry.SCREEN_TEXTURE_WIDTH = 1, GL_Entry.SCREEN_TEXTURE_HEIGHT = 1;
GL_Entry.SCREEN_BUFFER = null, GL_Entry.SCREEN_TEXTURE_BUFFER = null;
GL_Entry.SCREEN_TEXTURE_ID = 0;

// vertices

GL_Entry.SCREEN_XY = new Float32Array([ -1, -1, 1, -1,  1, 1,  -1, 1  ]);
GL_Entry.SCREEN_XY_ID = 0; GL_Entry.SCREEN_XY_BUFFER_ID = 0;
GL_Entry.SCREEN_UV =  new Float32Array([  0,  1,  1,  1,  1, 0,   0, 0 ]);
GL_Entry.SCREEN_UV_ID = 0; GL_Entry.SCREEN_UV_BUFFER_ID = 0;

GL_Entry.SCREEN_VERTS_IDS = new Uint16Array([0,1,2,2,3,0]);
GL_Entry.SCREEN_VERTS_IDS_ID = 0;

// shaders and locations

GL_Entry.GLSL_VS = `

    attribute vec4 aVertexXY;
    attribute vec2 aVertexUV;   
    
    varying highp vec2 vUV;
        
    void main(void)
    { 
        vUV = aVertexUV;
        gl_Position = aVertexXY;
    }

`;

GL_Entry.GLSL_FS = `

    varying highp vec2 vUV;

    uniform sampler2D uScreenTexture;

    void main()
    {
        gl_FragColor = texture2D( uScreenTexture, vUV );
    }
`;

GL_Entry.VERTEX_SHADER_ID = 0; GL_Entry.FRAGMENT_SHADER_ID = 0; GL_Entry.SHADER_PROGRAM_ID = 0;

GL_Entry.XY_ATTRIB_LOCATION=0; GL_Entry.UV_ATTRIB_LOCATION=0;
GL_Entry.TEXTURE_UNIFORM_LOCATION = 0;


GL_Entry.Init = function( gl, screenWidth, screenHeight )
{

    // create the vertex shader�
    GL_Entry.VERTEX_SHADER_ID = gl.createShader(gl.VERTEX_SHADER);
    console.log("compile vertex shader: ");
    gl.shaderSource(GL_Entry.VERTEX_SHADER_ID,GL_Entry.GLSL_VS);
    gl.compileShader(GL_Entry.VERTEX_SHADER_ID);        
    // See if it compiled successfully
    if (!gl.getShaderParameter(GL_Entry.VERTEX_SHADER_ID, gl.COMPILE_STATUS)) {
        alert('An error occurred compiling vertex shader: ' + gl.getShaderInfoLog(GL_Entry.VERTEX_SHADER_ID));
        gl.deleteShader(GL_Entry.VERTEX_SHADER_ID); // AJOUTER CA DANS LE CPP !!!
        GL_Entry.CRASHED = true;
        return false;
    }
    else
    {
        console.log("vertex shader compiled");
    }

    // create the fragment shader
    GL_Entry.FRAGMENT_SHADER_ID = gl.createShader(gl.FRAGMENT_SHADER);
    console.log("compile fragment shader: ");
    gl.shaderSource(GL_Entry.FRAGMENT_SHADER_ID,GL_Entry.GLSL_FS);
    gl.compileShader(GL_Entry.FRAGMENT_SHADER_ID);
    // See if it compiled successfully
    if (!gl.getShaderParameter(GL_Entry.FRAGMENT_SHADER_ID, gl.COMPILE_STATUS)) {
        alert('An error occurred compiling fragment shader: ' + gl.getShaderInfoLog(GL_Entry.FRAGMENT_SHADER_ID));
        gl.deleteShader(GL_Entry.FRAGMENT_SHADER_ID); // AJOUTER CA DANS LE CPP !!!
        GL_Entry.CRASHED = true;
        return false;
    }
    else
    {
        console.log("fragment shader compiled");
    }

    // link the program shader

    console.log("link shaders program");
    GL_Entry.SHADER_PROGRAM_ID = gl.createProgram();
    gl.attachShader(GL_Entry.SHADER_PROGRAM_ID,GL_Entry.VERTEX_SHADER_ID);
    gl.attachShader(GL_Entry.SHADER_PROGRAM_ID,GL_Entry.FRAGMENT_SHADER_ID);
    gl.linkProgram(GL_Entry.SHADER_PROGRAM_ID);
    // If creating the shader program failed, alert
    if (!gl.getProgramParameter(GL_Entry.SHADER_PROGRAM_ID, gl.LINK_STATUS)) {
        alert('Unable to link the shader program: ' + gl.getProgramInfoLog(GL_Entry.SHADER_PROGRAM_ID));
        gl.deleteShader(GL_Entry.VERTEX_SHADER_ID); // AJOUTER CA DANS LE CPP !!!
        gl.deleteShader(GL_Entry.FRAGMENT_SHADER_ID); // AJOUTER CA DANS LE CPP !!!
        GL_Entry.CRASHED = true;
        return false;
    }
    else
    {
        console.log("programs linked");
    }

    // get locations

    GL_Entry.XY_ATTRIB_LOCATION = gl.getAttribLocation(GL_Entry.SHADER_PROGRAM_ID,"aVertexXY");
    GL_Entry.UV_ATTRIB_LOCATION = gl.getAttribLocation(GL_Entry.SHADER_PROGRAM_ID,"aVertexUV");
    GL_Entry.TEXTURE_UNIFORM_LOCATION = gl.getUniformLocation(GL_Entry.SHADER_PROGRAM_ID,"uScreenTexture");


    // create data
    
    GL_Entry.SCREEN_WIDTH = screenWidth;
    GL_Entry.SCREEN_HEIGHT = screenHeight;

    // get dimensions of tables

    while ( GL_Entry.SCREEN_TEXTURE_WIDTH < GL_Entry.SCREEN_WIDTH )
    {
        GL_Entry.SCREEN_TEXTURE_WIDTH <<= 1;
    }
    console.log("screen texture width: " + GL_Entry.SCREEN_TEXTURE_WIDTH );

    while ( GL_Entry.SCREEN_TEXTURE_HEIGHT < GL_Entry.SCREEN_HEIGHT )
    {
        GL_Entry.SCREEN_TEXTURE_HEIGHT <<= 1;
    }
    console.log("screen texture height: " + GL_Entry.SCREEN_TEXTURE_HEIGHT );

    // create tables

    GL_Entry.SCREEN_TEXTURE_BUFFER = new Uint8ClampedArray(GL_Entry.SCREEN_TEXTURE_WIDTH*GL_Entry.SCREEN_TEXTURE_HEIGHT*4);

    // dimension UV on subImage

    var uW = GL_Entry.SCREEN_WIDTH / GL_Entry.SCREEN_TEXTURE_WIDTH;
    var uH = GL_Entry.SCREEN_HEIGHT / GL_Entry.SCREEN_TEXTURE_HEIGHT;
    //SCREEN_UV[] = {   0, uH,  uW, uH,  uW, 0,   0, 0 };
    GL_Entry.SCREEN_UV[1]=uH;
    GL_Entry.SCREEN_UV[2]=uW;
    GL_Entry.SCREEN_UV[3]=uH;
    GL_Entry.SCREEN_UV[4]=uW;

    // create the texture

    GL_Entry.SCREEN_TEXTURE_ID = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, GL_Entry.SCREEN_TEXTURE_ID);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, GL_Entry.SCREEN_TEXTURE_WIDTH, GL_Entry.SCREEN_TEXTURE_HEIGHT, 0, gl.RGBA, gl.UNSIGNED_BYTE, GL_Entry.SCREEN_TEXTURE_BUFFER);

    // create the vertices
       
    GL_Entry.SCREEN_XY_BUFFER_ID = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, GL_Entry.SCREEN_XY_BUFFER_ID);
    gl.bufferData(gl.ARRAY_BUFFER, GL_Entry.SCREEN_XY, gl.STATIC_DRAW);

    GL_Entry.SCREEN_UV_BUFFER_ID = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, GL_Entry.SCREEN_UV_BUFFER_ID);
    gl.bufferData(gl.ARRAY_BUFFER, GL_Entry.SCREEN_UV, gl.STATIC_DRAW);

    GL_Entry.SCREEN_VERTS_IDS_ID = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, GL_Entry.SCREEN_VERTS_IDS_ID);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, GL_Entry.SCREEN_VERTS_IDS, gl.STATIC_DRAW);


    return true;
};

GL_Entry.ShutDown = function( gl )
{
    // delete the shaders

    if (!GL_Entry.CRASHED)
    {
        gl.detachShader(GL_Entry.SHADER_PROGRAM_ID,GL_Entry.VERTEX_SHADER_ID);
        gl.detachShader(GL_Entry.SHADER_PROGRAM_ID,GL_Entry.FRAGMENT_SHADER_ID);
        gl.deleteShader(GL_Entry.VERTEX_SHADER_ID);
        gl.deleteShader(GL_Entry.FRAGMENT_SHADER_ID);
        console.log("shaders deleted");
    }

    // delete the vertices

    gl.deleteBuffer(GL_Entry.SCREEN_VERTS_IDS_ID);
    gl.deleteBuffer(GL_Entry.SCREEN_XY_BUFFER_ID);
    console.log("vertices deleted");

    // delete the texture
    gl.deleteTexture(GL_Entry.SCREEN_TEXTURE_ID);
    console.log("texture deleted");

    // delete table
    GL_Entry.SCREEN_TEXTURE_BUFFER = null;
    console.log("textures data deleted");

};

GL_Entry.VideoRoutine = function( gl, screenDataBuffer )
{
    if ( GL_Entry.CRASHED )
    {
        return;
    }

    // clear screen

    gl.clearColor(0,0,1,1);
    gl.clear(gl.COLOR_BUFFER_BIT);

    // draw VGA-like screen

    // stream texture data to GPU

    gl.bindTexture(gl.TEXTURE_2D, GL_Entry.SCREEN_TEXTURE_ID);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, GL_Entry.SCREEN_WIDTH, GL_Entry.SCREEN_HEIGHT, gl.RGBA, gl.UNSIGNED_BYTE, screenDataBuffer );

    // select shader program
    
    gl.useProgram(GL_Entry.SHADER_PROGRAM_ID);

    // bind textures

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D,GL_Entry.SCREEN_TEXTURE_ID);
    gl.uniform1i(GL_Entry.TEXTURE_UNIFORM_LOCATION,0);

    // bind vertices

    gl.bindBuffer(gl.ARRAY_BUFFER, GL_Entry.SCREEN_XY_BUFFER_ID );
    gl.vertexAttribPointer(GL_Entry.XY_ATTRIB_LOCATION,2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(GL_Entry.XY_ATTRIB_LOCATION);

    gl.bindBuffer(gl.ARRAY_BUFFER, GL_Entry.SCREEN_UV_BUFFER_ID );
    gl.vertexAttribPointer(GL_Entry.UV_ATTRIB_LOCATION,2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(GL_Entry.UV_ATTRIB_LOCATION);

    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,GL_Entry.SCREEN_VERTS_IDS_ID); 
    
    // draw
    
    gl.disable(gl.BLEND);
    
    gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0);

    // free attrib arrays

    gl.disableVertexAttribArray(GL_Entry.XY_ATTRIB_LOCATION);
    gl.disableVertexAttribArray(GL_Entry.UV_ATTRIB_LOCATION);
    
    //console.log("drawn");
};
