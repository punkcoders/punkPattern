//RAM
var B = null;
//GRAPHICS
var SW = 0, SH = 0, TW = 0, TH = 0, STRETCH = 3; // screen dimensions
var CONT = null, CAN = null, CTX = null, SCREEN_PIXELS = null; // canvas context 2d
//AUDIO
var A_CTX = null, SRC_BUF = null, SCRIPT_NODE = null, LEFT = null, RIGHT = null, NOSND = null;
var NUM_SAMPLES = 0, MUTE = 0, AUDIO_STARTED = false;
//FILES
var FILE_NAME = null, FILE_BUFFER = null;
var MAX_FILE_SIZE = 1024;
var FILE_LOADER = new XMLHttpRequest();
var WAIT_FILE = false;
//CONTROL
var LAST_KEY = null, MOUSE_X = null, MOUSE_Y = null;

// focus events
window.onblur = function () {
    MUTE = 1;
};
window.onfocus = function () {
    MUTE = 0;
};

// entry point
function main() {

    // ALL MODULE MEMORY IS HERE

    B = wasmMemory.buffer;
    
    // SET SMARTPHONE BOOLEAN
    
    let boolARM = new Uint8ClampedArray( B, __Z24GetSmartphoneBoolAddressv(), 1 );
    boolARM[0] = ("ontouchmove" in document.documentElement);
    
    // INIT RENDER GRAPHIC BUFFER POINTERS COPIED TO JAVASCRIPT
    
    RGB.InitPointers( B );

    // GRAPHIC OBJECTS
    
    SW = RGB.SCREEN_DIMENSIONS[0] ;
    SH = RGB.SCREEN_DIMENSIONS[1] ;

    CAN = document.createElement('canvas');
    CAN.width = SW;
    CAN.height = SH;
    CAN.style.backgroundColor = '#000000';
    CAN.style.width = "100%";
    CAN.style.height = "100%";
    CAN.onmousedown = OnMouseDown;
    CAN.onmouseup = OnMouseUp;
    CAN.onmousemove = OnMouseMove;
    CONT = document.getElementById("container");
    CONT.appendChild(CAN);
    CONT.style.width = SW*STRETCH;
    CONT.style.height = SH*STRETCH;

    
    CTX = CAN.getContext('webgl',{ antialias: false,depth: false }); // 2d webgl 
    SCREEN_PIXELS = RGB.SCREEN_PIXELS;

    // init webgl stuff
    let result = GL_Entry.Init( CTX, SW, SH );
    if (result==="false")
    {
        alert("cannot initialize webGL objects");
        return 0;
    }

    // AUDIO BUFFERS
    NUM_SAMPLES = __Z21GetNumSamplesByBufferv();
    LEFT = new Float32Array(B, __Z20GetLeftBufferAddressv(), NUM_SAMPLES);
    RIGHT = new Float32Array(B, __Z21GetRightBufferAddressv(), NUM_SAMPLES);
    NOSND = new Float32Array(NUM_SAMPLES);
    
    // FILE BUFFERS    
    MAX_FILE_SIZE = __Z14GetMaxFileSizev();
    FILE_NAME = new Uint8Array(B, __Z18GetFileNameAddressv(), 256);
    FILE_BUFFER = new Uint8Array(B, __Z20GetFileBufferAddressv(), MAX_FILE_SIZE);

    // CONTROLS POINTERS
    LAST_KEY = new Uint8Array(B,__Z24GetLastKeyPressedAddressv());
    MOUSE_X = new Uint32Array(B,__Z16GetMouseXAddressv());
    MOUSE_Y = new Uint32Array(B,__Z16GetMouseYAddressv());

    //START VIDEO ROUTINE
    window.requestAnimationFrame(VideoRoutine);
}
function exitApp()
{
    RGB.ShutdownPointers();
    
    console.log("close module");
    __Z7ExitAppv();
    
    console.log("close GL");
    GL_Entry.ShutDown(CTX);
    
    if ( AUDIO_STARTED )
    {
        A_CTX.close();
        SCRIPT_NODE.disconnect();
        SRC_BUF.disconnect();
        console.log("audio closed");
    }
    
    document.onkeydown = null;
    document.onkeyup = null;
    CAN.onmousedown = null;
    CAN.onmouseup = null;
    CAN.onmousemove = null;
    CONT.parentNode.removeChild(CONT);
    
}

window.onunload = function()
{
    console.log("clear MEMORY");
    exitApp();
};

// video events
function makeFullScreen(element) {
    if (element.requestFullScreen) {
        element.requestFullScreen();
    } else if (element.webkitRequestFullScreen) {
        element.webkitRequestFullScreen();
    } else if (element.mozRequestFullScreen) {
        element.mozRequestFullScreen();
    } else if (element.msRequestFullScreen) {
        element.msRequestFullScreen();
    } 
}
function GoFullScreen() {
    makeFullScreen(CONT);
}
function VideoRoutine(dt) {
    if (!WAIT_FILE) {
        __Z12VideoRoutinev();
        GL_Entry.VideoRoutine( CTX, SCREEN_PIXELS );
    }
    // attempt load file
    if (FILE_NAME[0]) {
        WAIT_FILE = true;
        LoadFile();
        FILE_NAME[0] = 0;
    }   
    if ( ! __Z7GetExitv() ) 
    {
        window.requestAnimationFrame(VideoRoutine);
    }
    else
    {
        exitApp();
    }
}

// audio events
function TestAudioStart() {
    if (AUDIO_STARTED) return;
    AUDIO_STARTED = true;    
    // CREATE AUDIO OBJECTS  
    A_CTX = new AudioContext();
    SRC_BUF = A_CTX.createBufferSource();
    SCRIPT_NODE = A_CTX.createScriptProcessor(NUM_SAMPLES, 0, 2);
    SCRIPT_NODE.onaudioprocess = AudioRoutine;
    // SET SAMPLERATE IN MODULE
    var arr = new Uint32Array(B, __Z20GetSampleRateAddressv(), 1);
    arr[0] = A_CTX.sampleRate;
    // START AUDIO ROUTINE
    SRC_BUF.connect(SCRIPT_NODE);
    SCRIPT_NODE.connect(A_CTX.destination);
    SRC_BUF.start();
}
function AudioRoutine(evt) {
    var leftData = evt.outputBuffer.getChannelData(0);
    var rightData = evt.outputBuffer.getChannelData(1);
    if (MUTE || WAIT_FILE) {
        leftData.set(NOSND);
        rightData.set(NOSND);
    } else {
        __Z12AudioRoutinev();        
        leftData.set(LEFT);
        rightData.set(RIGHT);
    }
}

// load file events
function LoadFile() {
    var str = "";
    for (var i = 0; FILE_NAME[i]; i++) {
        str += String.fromCharCode(FILE_NAME[i]);
    }
    console.log(str);
    FILE_LOADER.open("GET", str, true);
    FILE_LOADER.responseType = 'arraybuffer';
    FILE_LOADER.send(null);
}
FILE_LOADER.onreadystatechange = function () {
    console.log("e.readyState: "+this.readyState,"e.status: "+this.status);
    
    if (this.readyState == 4) {
        if (this.status == 200) {
            var buffer = new Uint8Array(this.response);
            FILE_BUFFER.set(buffer);
            __Z8OnLoadedv();
        } else {
            console.log("loadErrorEvent");
            __Z11OnLoadErrorv();
        }
        WAIT_FILE = false;
    }
};

// key events
document.onkeydown = function(e) {
    if (!AUDIO_STARTED) TestAudioStart();
    LAST_KEY[0] = e.keyCode;
    __Z9OnKeyDownv();
    e.preventDefault();
};
document.onkeyup = function(e) {
    LAST_KEY[0] = e.keyCode;
    __Z7OnKeyUpv();
};

// mouse events
function getMouseX(e) {
    var rect = e.target.getBoundingClientRect();
    var x = (e.clientX-rect.left) / (rect.width/SW);
    if (x<0) x=0;
    if (x>=SW) x=SW-1;
    return x;
}
function getMouseY(e) {
    var rect = e.target.getBoundingClientRect();
    var y = (e.clientY-rect.top) / (rect.height/SH);
    if (y<0) y=0;
    if (y>=SH) y=SH-1;
    return y;
}
OnMouseDown = function(e) {
    if (!AUDIO_STARTED) TestAudioStart();
    MOUSE_X[0] = getMouseX(e);
    MOUSE_Y[0] = getMouseY(e);
    __Z11OnMouseDownv();
};
OnMouseUp = function(e) {
    MOUSE_X[0] = getMouseX(e);
    MOUSE_Y[0] = getMouseY(e);
    __Z9OnMouseUpv();
};
OnMouseMove = function(e) {
    MOUSE_X[0] = getMouseX(e);
    MOUSE_Y[0] = getMouseY(e);
};