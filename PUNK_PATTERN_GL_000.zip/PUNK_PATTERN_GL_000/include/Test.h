#ifndef TEST_H
#define TEST_H

#include "ROOT_DeviceManager.h"
#include "ROOT_EntryPoint.h"

/*
Simple test for punk framework
*/


class Test
{
    public:

        static void Init();

    private:

        // video test -------------------------------------------------------------------------------------
        static int TICK;
        static const int NUMCOL = ROOT_EntryPoint::SCREEN_WIDTH / 8;
        static const int NUMROW = ROOT_EntryPoint::SCREEN_HEIGHT / 8;
        static const int NUMCELL = NUMCOL * NUMROW;
        static unsigned char TILESHEET[256*8]; // 1 bit color, 1 char = 8 pixel row, 8 char = 1 tile
        static unsigned long PALETTE[2];
        static unsigned char TEXT[NUMCELL];
        static const int NUM_SPRITES = 4;
        struct Sprite{long x; long y; long tile; long flags;}; // flags: 0=visible,
        static Sprite SPRITERAM[NUM_SPRITES];  // sprite ram table
        static const int MAX_SPRITE_PER_SCANLINE = 8; // 8-bit scanline mask
        struct ScanlineSprites{unsigned char sprites[MAX_SPRITE_PER_SCANLINE];}; // store sprites in scanlines
        static ScanlineSprites SCANLINE_SPRITES_TABLE[ROOT_EntryPoint::SCREEN_HEIGHT];
        static unsigned char SCANLINE_NUM_SPRITES_TABLE[ROOT_EntryPoint::SCREEN_HEIGHT];
        static unsigned char SCANLINE_BUFFER[512];
        static void DrawScanLine(int y);
        static void Write(const char* text, int tell);
        static void StoreSpritesInScanlines(int startY, int stopY);
        static int CURSOR;
        static void TestVideoRoutine();

        // audio test -------------------------------------------------------------------------------------
        static int CUR_SAMPLE;
        static float VOL, FREQ, PAN;
        static void SFX(float freq, float vol, float pan);
        static void OnAudioRoutine();

        //controls test -----------------------------------------------------------------------------------
        static void OnKeyDown();
        static void OnKeyUp();
        static void OnClick();

        // load file test ---------------------------------------------------------------------------------
        static void OnFileError();
        static void OnFileLoaded();


};

#endif // TEST_H
