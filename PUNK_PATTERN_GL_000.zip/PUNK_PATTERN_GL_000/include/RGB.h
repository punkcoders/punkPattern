#ifndef RGB_H
#define RGB_H

// Render Graphics Buffer

class RGB
{
    public:

        static const unsigned long BUFFER_SIZE = 4*256*256;

        // all memory here

        static unsigned char BUFFER[ BUFFER_SIZE ];

        // init all pointers

        static void InitPointers();

        // pointers

        static unsigned short * SCREEN_WIDTH, * SCREEN_HEIGHT;

        static unsigned char * SCREEN_PIXELS;

    protected:

    private:
};

#endif // RGB_H
