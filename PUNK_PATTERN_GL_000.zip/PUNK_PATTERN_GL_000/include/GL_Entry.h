#ifndef GL_ENTRY_H
#define GL_ENTRY_H

#include <GL/glew.h>


class GL_Entry
{
    public:

        static bool Init();
        static void ShutDown();

        static void VideoRoutine();

    protected:

    private:

        static bool CRASHED;

        // textures

        static unsigned int SCREEN_WIDTH, SCREEN_HEIGHT;
        static unsigned int SCREEN_TEXTURE_WIDTH, SCREEN_TEXTURE_HEIGHT;
        static unsigned char * SCREEN_BUFFER, * SCREEN_TEXTURE_BUFFER;
        static GLuint SCREEN_TEXTURE_ID;

        // vertices

        static float SCREEN_XY[];
        static GLuint SCREEN_XY_BUFFER_ID;
        static float SCREEN_UV[];
        static GLuint SCREEN_UV_BUFFER_ID;

        static unsigned short SCREEN_VERTS_IDS[];
        static GLuint SCREEN_VERTS_IDS_ID;

        // shaders & locations

        static const char * VERTEX_SHADER[];
        static const char * FRAGMENT_SHADER[];

        static GLuint VERTEX_SHADER_ID, FRAGMENT_SHADER_ID, SHADER_PROGRAM_ID;

        static GLuint XY_ATTRIB_LOCATION, UV_ATTRIB_LOCATION;
        static GLuint TEXTURE_UNIFORM_LOCATION;

};

#endif // GL_ENTRY_H
