#ifndef ROOT_EntryPoint_H
#define ROOT_EntryPoint_H

/*
    ONLY THIS CLASS OF THE PATTERN SHOULD BE MODIFIED
    YOU'RE NOT SUPPOSED TO TOUCH OTHERS
*/

class ROOT_EntryPoint
{
    public:

        // CHANGE BUFFERS DIMENSIONS HERE ------------------------------------------------------

        // software video buffer
        static const int SCREEN_WIDTH = 240;
        static const int SCREEN_HEIGHT = 160;

        // file buffer size, no limits
        static const int MAX_FILE_SIZE = 1024*1024*1; // 1 Mo

        // audio stream buffer nSamples, minimum 4096
        static const int SAMPLES_BY_AUDIOBUFFER = 4096;

        // ENTRY POINT -------------------------------------------------------------------------

        static void Main();
        static void Exit();
};

#endif // ROOT_EntryPoint_H
