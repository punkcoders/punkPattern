/* 
 * memory adresses of the update graphics buffer
 */

function UGB () {
    /*static class*/
}


// array pointers


// texture data
// relative to 0x0

UGB.TEXTURES_ADDR =
{
    FIRST_ADRESS: 0x0,
    
    texSize : 0x4000,
    
    tex0: 0x00000,
    tex1: 0x04000,
    tex2: 0x08000,
    tex3: 0x0C000,
    tex4: 0x10000,
    tex5: 0x14000,
    tex6: 0x18000,
    tex7: 0x1C000   
};

// update info
// relative to 0x20000

UGB.INFO_ADDR =
{
    start:         0x20000,
    
    // 8 bools, true if texture update
    
    boolUpdateTextures :  0x0,
   
    // 8 chars: nCol, nRow, srcCol, dstCol
   
    bgMapSheetCopy :      0x10,
    bgSpriteSheetCopy :   0x14,
    fgMapSheetCopy :      0x18,
    fgSpriteSheetCopy :   0x1C 
};


// now create the pointers

// textures data

UGB.addrTex0 = new Uint8ClampedArray(Module.UGB, UGB.TEXTURES_ADDR.tex0, UGB.TEXTURES_ADDR.texSize);
UGB.addrTex1 = new Uint8ClampedArray(Module.UGB, UGB.TEXTURES_ADDR.tex1, UGB.TEXTURES_ADDR.texSize);
UGB.addrTex2 = new Uint8ClampedArray(Module.UGB, UGB.TEXTURES_ADDR.tex2, UGB.TEXTURES_ADDR.texSize);
UGB.addrTex3 = new Uint8ClampedArray(Module.UGB, UGB.TEXTURES_ADDR.tex3, UGB.TEXTURES_ADDR.texSize);
UGB.addrTex4 = new Uint8ClampedArray(Module.UGB, UGB.TEXTURES_ADDR.tex4, UGB.TEXTURES_ADDR.texSize);
UGB.addrTex5 = new Uint8ClampedArray(Module.UGB, UGB.TEXTURES_ADDR.tex5, UGB.TEXTURES_ADDR.texSize);
UGB.addrTex6 = new Uint8ClampedArray(Module.UGB, UGB.TEXTURES_ADDR.tex6, UGB.TEXTURES_ADDR.texSize);
UGB.addrTex7 = new Uint8ClampedArray(Module.UGB, UGB.TEXTURES_ADDR.tex7, UGB.TEXTURES_ADDR.texSize);

// 8 bools to update textures

UGB.addrTexUpdate = new Uint8ClampedArray(Module.UGB,UGB.INFO_ADDR.start+UGB.INFO_ADDR.boolUpdateTextures, 8);

// 4 char table for rendering in targets sheets

UGB.addrBgMapSheetCopy = new Uint8ClampedArray(Module.UGB, UGB.INFO_ADDR.start+UGB.INFO_ADDR.bgMapSheetCopy, 4);
UGB.addrBgSpriteSheetCopy = new Uint8ClampedArray(Module.UGB, UGB.INFO_ADDR.start+UGB.INFO_ADDR.bgSpriteSheetCopy, 4);
UGB.addrFgMapSheetCopy = new Uint8ClampedArray(Module.UGB, UGB.INFO_ADDR.start+UGB.INFO_ADDR.bgMapSheetCopy, 4);
UGB.addrBgSpriteSheetCopy = new Uint8ClampedArray(Module.UGB, UGB.INFO_ADDR.start+UGB.INFO_ADDR.addrBgSpriteSheetCopy, 4);

