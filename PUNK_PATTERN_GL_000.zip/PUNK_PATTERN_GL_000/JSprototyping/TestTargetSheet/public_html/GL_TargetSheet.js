/* 
 * Instanciable class
 */

function GL_TargetSheet(gl, numTextures, buffersTable, name)
{
    this.compiled = this.Init(gl, numTextures, buffersTable, name);
    return this;
}

GL_TargetSheet.prototype.compiled = false;

// les objets openGL ne s'occupent pas de la nomenclature de pointeurs, c'est le boulot de la classe statique GL_Entry

GL_TargetSheet.prototype.m_crashed = 0;
GL_TargetSheet.prototype.m_name = "";


// shaders and locations --------------------------------------------------

GL_TargetSheet.GLSL_VS = `

    attribute vec4 aVertexXY;
    attribute vec2 aVertexUV;   
    
    varying highp vec2 vUV;
        
    void main(void)
    { 
        vUV = aVertexUV;
        gl_Position = aVertexXY;
    }

`;

GL_TargetSheet.GLSL_FS = `

    varying highp vec2 vUV;

    uniform sampler2D uScreenTexture;

    void main()
    {
        gl_FragColor.a = texture2D( uScreenTexture, vUV ).a ;
    }
`;

GL_TargetSheet.prototype.m_vertShader_ID = 0;
GL_TargetSheet.prototype.m_fragShader_ID = 0;
GL_TargetSheet.prototype.m_shaderProg_ID = 0;

GL_TargetSheet.prototype.m_XYattrLoc = 0;
GL_TargetSheet.prototype.m_UVattrLoc=0;
GL_TargetSheet.prototype.m_TexUnifLoc = 0;


// vertices ---------------------------------------------------------------

GL_TargetSheet.prototype.m_rectXY = new Float32Array([ -1, -1, 1, -1,  1, 1,  -1, 1  ]);
GL_TargetSheet.prototype.m_rectXY_ID = 0; GL_TargetSheet.prototype.m_screenXYbuffer_ID = 0;
GL_TargetSheet.prototype.m_rectUV =  new Float32Array([  0,  0,  1,  0,  1, 1,   0, 1 ]);
GL_TargetSheet.prototype.m_rectUV_ID = 0; GL_TargetSheet.prototype.m_rectUVbuffer_ID = 0;

GL_TargetSheet.prototype.m_rectVerts_IDS = new Uint16Array([0,1,2,2,3,0]); // same for all classes
GL_TargetSheet.prototype.m_rectVerts_IDS_ID = 0;


// textures ---------------------------------------------------------------

// static members

GL_TargetSheet.TEXTURE_WIDTH = 128;
GL_TargetSheet.TEXTURE_HEIGHT = 128;

// instance members

GL_TargetSheet.prototype.m_texturesID = [];
GL_TargetSheet.prototype.m_texturesBuffer = [];
GL_TargetSheet.prototype.m_renderTargetID = null;

GL_TargetSheet.prototype.m_frameBufferID = null;
GL_TargetSheet.prototype.m_attachmentPoint = null;

// ---------------------------------------------------------------
// constructor
// ---------------------------------------------------------------

GL_TargetSheet.prototype.Init = function ( gl, numTextures, buffersTable, name )
{
    this.m_name = name;
    
    // ---------------------------------------------------------------
    // create the shaders
    // ---------------------------------------------------------------
    
    // create the vertex shader
    this.m_vertShader_ID  = gl.createShader(gl.VERTEX_SHADER);
    console.log("   compile vertex shader: ");
    gl.shaderSource(this.m_vertShader_ID,GL_TargetSheet.GLSL_VS);
    gl.compileShader(this.m_vertShader_ID); 
    // See if it compiled successfully
    if (!gl.getShaderParameter(this.m_vertShader_ID, gl.COMPILE_STATUS)) {
        alert(' An error occurred compiling vertex shader: ' + gl.getShaderInfoLog(this.m_vertShader_ID));
        gl.deleteShader(this.m_vertShader_ID);
        this.m_crashed = true;
        return false;
    }
    else
    {
        console.log("   vertex shader compiled");
    }

    // create the fragment shader
    this.m_fragShader_ID = gl.createShader(gl.FRAGMENT_SHADER);
    console.log("   compile fragment shader: ");
    gl.shaderSource(this.m_fragShader_ID,GL_TargetSheet.GLSL_FS);
    gl.compileShader(this.m_fragShader_ID);
    // See if it compiled successfully
    if (!gl.getShaderParameter(this.m_fragShader_ID, gl.COMPILE_STATUS)) {
        alert(' An error occurred compiling fragment shader: ' + gl.getShaderInfoLog(this.m_fragShader_ID));
        gl.deleteShader(this.m_fragShader_ID); // AJOUTER CA DANS LE CPP !!!
        this.m_crashed = true;
        return false;
    }
    else
    {
        console.log("   fragment shader compiled");
    }

    // link the program shader

    this.m_shaderProg_ID = gl.createProgram();
    gl.attachShader(this.m_shaderProg_ID,this.m_vertShader_ID);
    gl.attachShader(this.m_shaderProg_ID,this.m_fragShader_ID);
    gl.linkProgram(this.m_shaderProg_ID);
    // If creating the shader program failed, alert
    if (!gl.getProgramParameter(this.m_shaderProg_ID, gl.LINK_STATUS)) {
        alert(' Unable to link the shader program: ' + gl.getProgramInfoLog(this.m_shaderProg_ID));
        gl.deleteShader(this.m_vertShader_ID); // AJOUTER CA DANS LE CPP !!!
        gl.deleteShader(this.m_fragShader_ID); // AJOUTER CA DANS LE CPP !!!
        this.m_crashed = true;
        return false;
    }
    else
    {
        console.log("   programs linked");
    }
    
    this.m_XYattrLoc = gl.getAttribLocation(this.m_shaderProg_ID,"aVertexXY");
    this.m_UVattrLoc = gl.getAttribLocation(this.m_shaderProg_ID,"aVertexUV");
    this.m_TexUnifLoc = gl.getUniformLocation(this.m_shaderProg_ID,"uScreenTexture");


    // ---------------------------------------------------------------
    // create the vertices
    // ---------------------------------------------------------------
    
    this.m_rectXYbuffer_ID = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.m_rectXYbuffer_ID);
    gl.bufferData(gl.ARRAY_BUFFER, this.m_rectXY, gl.STATIC_DRAW);

    this.m_rectUVbuffer_ID = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.m_rectUVbuffer_ID);
    gl.bufferData(gl.ARRAY_BUFFER, this.m_rectUV, gl.STATIC_DRAW);

    this.m_rectVerts_IDS_ID = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.m_rectVerts_IDS_ID);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.m_rectVerts_IDS, gl.STATIC_DRAW);
    
    
    // ---------------------------------------------------------------
    // create the static textures
    // ---------------------------------------------------------------
    
    this.m_texturesBuffer = buffersTable;
    
    for ( var iTex=0; iTex < numTextures; iTex++ )
    {
        this.m_texturesID[iTex] = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, this.m_texturesID[iTex]);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.ALPHA,
            GL_TargetSheet.TEXTURE_WIDTH, GL_TargetSheet.TEXTURE_HEIGHT, 0,
            gl.ALPHA, gl.UNSIGNED_BYTE, this.m_texturesBuffer[iTex] ); 

    }
    console.log("   textures created");
    
    
    // ---------------------------------------------------------------
    // create the copy framebuffers
    // ---------------------------------------------------------------

    this.m_renderTargetID = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.m_renderTargetID);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA,
        GL_TargetSheet.TEXTURE_WIDTH, GL_TargetSheet.TEXTURE_HEIGHT, 0,
        gl.RGBA, gl.UNSIGNED_BYTE, null );

    // renderTarget frameBuffer
    
   // this.m_renderBuffer = gl.createRenderbuffer();
    this.m_frameBufferID = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.m_frameBufferID);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.m_renderTargetID, 0);
  
    // go back to screen frame buffer
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
 
 
 
    console.log("   "+this.m_name+" created");
 
    return true;
};

// ---------------------------------------------------------------
// destructor
// ---------------------------------------------------------------

GL_TargetSheet.prototype.Delete = function ( gl )
{
    // delete textures
    
    gl.deleteFramebuffer(this.m_frameBufferID);
    gl.deleteTexture(this.m_renderTargetID);
    console.log("   renderTarget deleted");
    
    for ( let iTex = 0; iTex > this.numTextures; iTex++ )
    {
        gl.deleteTexture(this.TexturesID[iTex]);
    }
    console.log("   textures deleted");
    
    // delete vertices
    
    gl.deleteBuffer(this.m_rectXYbuffer_ID);
    gl.deleteBuffer(this.m_rectUVbuffer_ID);
    gl.deleteBuffer(this.m_rectVerts_IDS_ID);
    
    console.log("   "+this.m_name+" deleted");
    
};

// ---------------------------------------------------------------
// texture update
// ---------------------------------------------------------------

GL_TargetSheet.prototype.UpdateTexture = function ( gl, iTex )
{  
    gl.bindTexture(gl.TEXTURE_2D, this.m_texturesID[iTex]);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, GL_TargetSheet.TEXTURE_WIDTH, GL_TargetSheet.TEXTURE_HEIGHT, gl.ALPHA, gl.UNSIGNED_BYTE, this.m_texturesBuffer[iTex] );
    console.log("   "+this.m_name+" texture "+iTex+" pixels updated");
};

// ---------------------------------------------------------------
// draw texture in renderTarget sheet
// ---------------------------------------------------------------


GL_TargetSheet.prototype.DrawTilesInSheet = function( gl, indexTexture, nCol, nRow, srcRow, dstRow )
{

    // on va refaire des calculs crétins
    // avec des bêtes xy uv
    // parce que là je suis largué dans mes maths

    // console.log("draw in render target");

    // set CopyRect dimensions
    
    const uWidth = nCol / 16.0 ;
    const vHeight = nRow / 16.0 ;
    const uStart = 0 ;
    const vStart = srcRow / 16.0 ;
    
    const xWidth = nCol / 8.0;
    const yHeight = nRow / 8.0; 
    const xStart = 0 - 1 ;
    const yStart = dstRow / 8.0 - 1 ;
    
    let uv = this.m_rectUV;
    let xy = this.m_rectXY;
    
    // uv src
    
    uv[0] = uStart;
    uv[1] = vStart;
    
    uv[2] = uStart+uWidth;
    uv[3] = vStart;
    
    uv[4] = uStart+uWidth;
    uv[5] = vStart+vHeight;
    
    uv[6] = uStart;
    uv[7] = vStart+vHeight;
    
    // xy dest
    
    xy[0] = xStart;
    xy[1] = yStart;
    
    xy[2] = xStart+xWidth;
    xy[3] = yStart;
    
    xy[4] = xStart+xWidth;
    xy[5] = yStart+yHeight;
    
    xy[6] = xStart;
    xy[7] = yStart+yHeight;
  
  
  
    // bind renderTarget
  
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.m_frameBufferID);
    gl.viewport(0, 0, GL_TargetSheet.TEXTURE_WIDTH, GL_TargetSheet.TEXTURE_WIDTH);
    gl.disable(gl.BLEND); // alpha must erase alpha

    // select shader program
    
    gl.useProgram(this.m_shaderProg_ID);  

    // bind texture

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D,this.m_texturesID[indexTexture]);
    gl.uniform1i(this.m_TexUnifLoc,0);

    // bind vertices

    gl.bindBuffer(gl.ARRAY_BUFFER, this.m_rectXYbuffer_ID );
    gl.bufferData(gl.ARRAY_BUFFER, this.m_rectXY, gl.DYNAMIC_DRAW);
    gl.vertexAttribPointer(this.m_XYattrLoc,2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(this.m_XYattrLoc);

    gl.bindBuffer(gl.ARRAY_BUFFER, this.m_rectUVbuffer_ID );
    gl.bufferData(gl.ARRAY_BUFFER, this.m_rectUV, gl.DYNAMIC_DRAW);
    gl.vertexAttribPointer(this.m_UVattrLoc,2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(this.m_UVattrLoc);

    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,this.m_rectVerts_IDS_ID);   
    
    // draw
    
    gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0);

    // free attrib arrays

    gl.disableVertexAttribArray(this.m_XYattrLoc);
    gl.disableVertexAttribArray(this.m_XYattrLoc);
    
    // unbind renderTarget
    
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
};

// ---------------------------------------------------------------
// Get Sheet ID
// ---------------------------------------------------------------

GL_TargetSheet.prototype.GetSheetID = function()
{
    return this.m_renderTargetID;
};