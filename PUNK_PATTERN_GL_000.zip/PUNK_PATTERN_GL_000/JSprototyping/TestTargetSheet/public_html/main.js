/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


var CTX3D = null;

function main_init()
{
    console.log("init -----------------------------"); 
    
    var ctx2d = document.getElementById('canvasTest').getContext('2d');
    console.log('context 2d:'+ctx2d);
    
    CTX3D = document.getElementById('canvas3d').getContext('webgl');
    console.log('context 3d:'+CTX3D);
    
    if ( ! GL_Entry.init( CTX3D ) )
    {
        console.log("error GL_Entry.init(gl)");
        return 0; // crashed
    }
    Module.init();
    
    // decode compressed table
   
    var palette = [0x000000,0x666666,0xCCCCCC,0xFFFFFF, 0xFF0000,0xFF6666,0xFF9999,0xFFCCCC, 0x00FF00,0x66FF66,0x99FF99,0xCCFFCC, 0x0000FF,0x6666FF,0x9999FF,0xCCCCFF];
    var data8 = new Uint8ClampedArray( 128*128*4 );
    var imgData = new ImageData(data8,128,128);   
    var uncompressedIndexes = UGB.addrTex0;
                   
    var iPix = 0;
    for ( var iPix = 0; iPix < 128*128; iPix++ )
    {
        var color = palette[ uncompressedIndexes[iPix] ] ;
        // modèle ARGB. r est sur les bits hauts, b sur les bits bas, a sur le bit le + haut
        data8[ iPix * 4 + 0 ] = (color >> 16 ) & 0xff;
        data8[ iPix * 4 + 1 ] = (color >> 8  ) & 0xff;
        data8[ iPix * 4 + 2 ] = (color >> 0  ) & 0xff;
        data8[ iPix * 4 + 3 ] = 0xff;
    }
    
    ctx2d.putImageData(imgData,0,0);
    
    console.log("end init -------------------------");
    
    window.requestAnimationFrame(main_videoRoutine);
}

function main_shutDown()
{
    console.log("shutDown -------------------------");
    Module.shutDown();
    GL_Entry.shutDown(CTX3D);
    console.log("end shutDown ---------------------");
}

function main_videoRoutine()
{
    Module.videoRoutine();
    GL_Entry.videoRoutine(CTX3D);
    
    window.requestAnimationFrame(main_videoRoutine);
}